"""Starts Raveena: checks your setup, picks a free port, launches the app and opens your browser.

    python start.py            start Raveena
    python start.py --check    just print what's wrong, if anything (handy for asking for help)

You normally don't run this directly: run.bat (Windows) or run.sh (Mac/Linux) set things up and call it.
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIN_PYTHON = (3, 10)
FIRST_PORT = 8501


def say(text: str = "") -> None:
    print(text, flush=True)


def python_ok(version: tuple[int, ...] | None = None) -> bool:
    return tuple((version or sys.version_info)[:2]) >= MIN_PYTHON


def missing_packages() -> list[str]:
    """Packages Raveena needs that aren't installed (google-genai is optional: without it she runs in Lite mode)."""
    missing = []
    for module, package in (("streamlit", "streamlit"), ("PIL", "Pillow")):
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    return missing


def find_free_port(start: int = FIRST_PORT, tries: int = 30) -> int | None:
    for port in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    return None


def diagnose() -> list[str]:
    """Plain-language problems, empty if all is well."""
    problems = []
    if not python_ok():
        problems.append(f"This is Python {sys.version.split()[0]}. Raveena needs Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or "
                        "newer. Install the latest from https://www.python.org/downloads/ and try again.")
    if not (ROOT / "app.py").exists():
        problems.append("I can't find app.py next to this file. If you opened this from inside the zip, extract the whole "
                        "folder first (right-click the zip, then Extract All).")
    missing = missing_packages()
    if missing:
        problems.append("These packages aren't installed yet: " + ", ".join(missing) + ". Run:  "
                        f"{Path(sys.executable).name} -m pip install -r requirements.txt")
    if find_free_port() is None:
        problems.append("Every network port from 8501 upward is busy, which is unusual. Restart your computer and try again.")
    return problems


def wait_for_server(proc: subprocess.Popen, port: int, timeout: float = 120.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc.poll() is not None:
            return False
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                return True
        except OSError:
            time.sleep(0.4)
    return False


def main(argv: list[str]) -> int:
    problems = diagnose()
    if "--check" in argv:
        say(f"Python:   {sys.version.split()[0]} ({sys.executable})")
        say(f"Folder:   {ROOT}")
        say(f"Packages: {'all there' if not missing_packages() else 'missing ' + ', '.join(missing_packages())}")
        try:
            from google import genai  # noqa: F401
            say("Gemini:   the 'google-genai' package is installed")
        except ImportError:
            say("Gemini:   the 'google-genai' package is NOT installed (Raveena will run in Lite mode)")
        say("API key:  " + ("found" if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or _key_in_env_file() else "not set yet (Lite mode)"))
        say("")
        say("Everything looks fine." if not problems else "Problems:\n- " + "\n- ".join(problems))
        return 0 if not problems else 1
    if problems:
        say("")
        say("Raveena can't start yet:")
        for p in problems:
            say(f"  - {p}")
        return 1

    port = find_free_port()
    url = f"http://localhost:{port}"
    say("")
    say("  Starting Raveena...")
    cmd = [sys.executable, "-m", "streamlit", "run", "app.py", "--server.port", str(port),
           "--server.headless", "true", "--browser.gatherUsageStats", "false"]
    proc = subprocess.Popen(cmd, cwd=str(ROOT), env={**os.environ, "PYTHONUNBUFFERED": "1"})
    try:
        if not wait_for_server(proc, port):
            say("")
            say("  Raveena stopped before she was ready. The message just above this one says why.")
            say("  If you can't tell, run  python start.py --check  and send me what it prints.")
            return 1
        say("")
        say(f"  Raveena is ready:  {url}")
        say("  Your browser should open by itself. If it doesn't, copy that address into it.")
        say("  Keep this window open while you use her. Close it (or press Ctrl+C) to stop.")
        say("")
        try:
            webbrowser.open(url)
        except Exception:                                   # noqa: BLE001 - opening a browser is a nicety
            pass
        return proc.wait()
    except KeyboardInterrupt:
        say("")
        say("  Stopping Raveena. See you soon.")
        return 0
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                proc.kill()


def _key_in_env_file() -> bool:
    env = ROOT / ".env"
    try:
        return any(line.startswith("GEMINI_API_KEY=") and line.strip().split("=", 1)[1].strip()
                   for line in env.read_text(encoding="utf-8").splitlines())
    except OSError:
        return False


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
