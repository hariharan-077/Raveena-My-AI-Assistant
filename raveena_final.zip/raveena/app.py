"""Raveena: a personal assistant that lives on your computer.

Run with:  streamlit run app.py
"""
from __future__ import annotations

import hmac
import logging

import streamlit as st
from PIL import Image

from raveena import actions, automations, brain, clock, config, db, fmt, settings
from raveena.ui import avatar, chat, common, habits, insights_page, memory_page, onboarding, settings_page, tasks_page, theme, today
from raveena.ui.components import esc

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

db.init()
settings.apply_runtime()

st.set_page_config(page_title="Raveena", page_icon=Image.open(avatar.orb_png(clock.now().hour, 64)),
                   layout="wide", initial_sidebar_state="expanded")
theme.inject()


def gate() -> None:
    """Optional passcode (RAVEENA_PASSCODE). Only needed if you ever host this somewhere others can reach."""
    if not config.PASSCODE or st.session_state.get("authed"):
        return
    _, mid, _ = st.columns([1, 1, 1])
    with mid:
        st.html(f'<div class="hello" style="padding-top:5rem">{avatar.orb_html(clock.now().hour, 64)}<h2>Welcome back.</h2></div>')
        with st.form("gate"):
            pw = st.text_input("Passcode", type="password")
            ok = st.form_submit_button("Unlock", type="primary", use_container_width=True)
        if ok:
            if hmac.compare_digest(pw.encode(), config.PASSCODE.encode()):
                st.session_state["authed"] = True
                st.rerun()
            st.error("That's not it.")
    st.stop()


gate()

if not settings.get("onboarded"):
    onboarding.render()
    st.stop()

today_iso = clock.today().isoformat()
if st.session_state.get("opened_on") != today_iso:
    st.session_state["opened_on"] = today_iso
    try:
        automations.on_open()
    except Exception:                                   # noqa: BLE001 - a hiccup here must never block the app
        logging.getLogger("raveena").exception("on-open automations failed")

NAV = [
    ("chat", "Chat", ":material/chat_bubble:", chat.render, True),
    ("today", "My day", ":material/today:", today.render, False),
    ("tasks", "Tasks", ":material/checklist:", tasks_page.render, False),
    ("habits", "Habits", ":material/self_improvement:", habits.render, False),
    ("insights", "Insights", ":material/lightbulb:", insights_page.render, False),
    ("memory", "Memory", ":material/neurology:", memory_page.render, False),
    ("settings", "Settings", ":material/tune:", settings_page.render, False),
]
pages = {key: st.Page(fn, title=title, icon=icon, url_path=key, default=default) for key, title, icon, fn, default in NAV}
common.PAGES.update(pages)
current = st.navigation(list(pages.values()), position="hidden")

with st.sidebar:
    st.html(f'<div class="brand">{avatar.orb_html(clock.now().hour, 40)}<div><div class="name">Raveena</div>'
            f'<div class="sub">Your assistant</div></div></div>')
    for key, page in pages.items():
        st.page_link(page)
    status = brain.status()
    pending = len(actions.pending())
    line = (f'<span class="dot"></span>Connected to <b>{esc(status["model"])}</b>' if status["mode"] == "ai"
            else f'<span class="dot off"></span><b>Lite mode</b>. {esc(status["reason"])}')
    wait = (f'<div style="margin-top:.55rem"><span class="chip now">{pending} waiting for your OK</span></div>' if pending else "")
    st.html(f'<div class="side-foot">{line}{wait}<div style="margin-top:.7rem">{esc(fmt.long_date(clock.today()))}</div></div>')

if current.title != "Chat":          # the chat page is locked to the viewport, so it uses toasts instead
    common.undo_banner()
current.run()
