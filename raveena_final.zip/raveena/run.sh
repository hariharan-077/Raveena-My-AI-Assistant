#!/usr/bin/env bash
# Starts Raveena on Mac or Linux. The first run sets things up (needs internet, about a minute).
cd "$(dirname "$0")" || exit 1
echo
echo "  Raveena is starting. The first time takes a minute or two."
echo

if [ ! -f app.py ]; then
  echo "  I can't find app.py. Unzip raveena.zip first, then run this from inside the raveena folder."
  exit 1
fi

# Find a Python that is 3.10 or newer.
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
    PY="$c"
    break
  fi
done
if [ -z "$PY" ]; then
  echo "  Raveena needs Python 3.10 or newer, and I couldn't find it on this computer."
  echo
  echo "    Mac:    download the newest Python from https://www.python.org/downloads/"
  echo "            (or, if you use Homebrew:  brew install python)"
  echo "    Linux:  sudo apt install python3 python3-venv     (or your distro's equivalent)"
  echo
  echo "  Then run this again."
  exit 1
fi

if [ ! -x .venv/bin/python ]; then
  echo "  Setting up a private Python environment for Raveena..."
  if ! "$PY" -m venv .venv; then
    echo
    echo "  I couldn't create the environment. On Ubuntu/Debian try:  sudo apt install python3-venv"
    exit 1
  fi
fi

echo "  Checking Raveena's packages (the first time this needs internet)..."
if ! .venv/bin/python -m pip install -q --disable-pip-version-check -r requirements.txt; then
  echo
  echo "  Installing the packages failed. Check your internet connection and try again."
  echo "  If it keeps failing, send me the error text above."
  exit 1
fi

exec .venv/bin/python start.py
