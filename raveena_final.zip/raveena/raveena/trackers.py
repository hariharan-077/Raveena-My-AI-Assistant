"""Habit and activity trackers: water, study, exercise, sleep, or anything you choose to track."""
from __future__ import annotations

import math
import re
from datetime import date, datetime, timedelta
from typing import Any

from . import clock, db, tasks
from .tasks import UserError

KINDS = {
    "sum": "Adds up through the day (water, study minutes)",
    "once": "One value per day (sleep hours, weight)",
    "check": "Done or not done (meditate, vitamins)",
}
ICONS = ["drop", "book", "pulse", "moon", "leaf", "spark", "heart", "sun", "pen", "dumbbell", "pill", "coffee"]
COLORS = ["#2F8FBF", "#5667D9", "#2F9E6E", "#7B6BC9", "#D9822B", "#C0508A", "#0F7C8C", "#7A869E"]

_ALIASES = {
    "water": ["water", "hydrate", "hydrated", "hydration", "drink", "drank", "drinking", "glass", "glasses", "bottle"],
    "study": ["study", "studied", "studying", "revise", "revised", "revising", "revision", "homework", "learn",
              "learned", "learning"],
    "exercise": ["exercise", "exercised", "workout", "work out", "worked out", "gym", "run", "ran", "running", "walk",
                 "walked", "walking", "yoga", "swim", "swam", "swimming", "cycling", "cycled", "training", "trained"],
    "sleep": ["sleep", "slept", "sleeping", "nap", "napped"],
    "meditate": ["meditate", "meditated", "meditation", "mindful", "mindfulness", "breathing"],
}


def list_trackers(active_only: bool = True) -> list[dict]:
    sql = "SELECT * FROM trackers" + (" WHERE active=1" if active_only else "") + " ORDER BY position, id"
    return db.rows(sql)


def get_tracker(tracker_id: int) -> dict | None:
    return db.get("trackers", tracker_id)


def _word(s: str, w: str) -> bool:
    return re.search(rf"\b{re.escape(w)}\b", s) is not None


def find_tracker(ref: Any) -> dict:
    """Resolve an id, a tracker name, or a loose word like 'drank' / 'workout'.

    Matching is by whole words, so 'underwater basket weaving' never lands on Water.
    """
    if isinstance(ref, dict):
        return ref
    s = str(ref if ref is not None else "").strip().lower()
    if not s:
        raise UserError("Which tracker? For example water, study or sleep.")
    pool = list_trackers(active_only=False)
    if re.fullmatch(r"#?\d+", s):
        t = get_tracker(int(s.lstrip("#")))
        if t:
            return t
    for t in pool:
        if t["name"].lower() == s:
            return t
    for t in pool:                                   # typed a prefix ("wat") or used the name in a phrase
        n = t["name"].lower()
        if (len(s) >= 3 and n.startswith(s)) or re.search(rf"\b{re.escape(n)}\b", s):
            return t
    for key, words in _ALIASES.items():
        if s == key or any(_word(s, w) for w in words):
            for t in pool:
                if key in t["name"].lower():
                    return t
    names = ", ".join(t["name"] for t in pool) or "none yet"
    raise UserError(f"I don't have a tracker called '{ref}'. Your trackers: {names}.")


def add_tracker(name: str, kind: str = "sum", unit: str = "", target: Any = 1, step: Any = None,
                icon: str = "spark", color: str | None = None,
                source_category: str | None = None) -> tuple[dict, bool]:
    name = re.sub(r"\s+", " ", (name or "")).strip()
    if not name:
        raise UserError("A tracker needs a name.")
    for t in list_trackers(active_only=False):
        if t["name"].lower() == name.lower():
            return t, False
    if kind not in KINDS:
        kind = "sum"
    try:
        target_f = float(target)
    except (TypeError, ValueError):
        raise UserError("The daily target should be a number.")
    if not math.isfinite(target_f) or target_f <= 0:
        raise UserError("The daily target should be more than zero.")
    try:
        step_f = float(step) if step not in (None, "") else (1.0 if kind != "sum" else max(1.0, round(target_f / 8)))
    except (TypeError, ValueError):
        step_f = 1.0
    pos = int(db.scalar("SELECT COALESCE(MAX(position),0)+1 FROM trackers", default=0))
    tid = db.insert("trackers", dict(
        name=name[:40], kind=kind, unit=(unit or "")[:12], target=target_f, step=step_f,
        icon=icon if icon in ICONS else "spark", color=color or COLORS[pos % len(COLORS)],
        source_category=tasks.normalize_category(source_category) if source_category else None, position=pos))
    return db.get("trackers", tid), True  # type: ignore[return-value]


def update_tracker(tracker_id: int, **fields: Any) -> dict:
    allowed = {"name", "kind", "unit", "target", "step", "icon", "color", "source_category", "active"}
    values = {k: v for k, v in fields.items() if k in allowed}
    if values:
        db.update("trackers", tracker_id, values)
    return db.get("trackers", tracker_id)  # type: ignore[return-value]


def delete_tracker(tracker_id: int) -> bool:
    db.delete_where("tracker_logs", "tracker_id=?", (tracker_id,))
    return db.delete("trackers", tracker_id)


# --------------------------------------------------------------------------- logging
def log(ref: Any, value: Any = None, note: str = "", when: datetime | None = None) -> dict:
    t = find_tracker(ref)
    when = when or clock.now()
    if value in (None, ""):
        value = t["step"] if t["kind"] == "sum" else (1 if t["kind"] == "check" else None)
    if value is None:
        raise UserError(f"How much {t['name'].lower()}? Give a number in {t['unit'] or 'units'}.")
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise UserError(f"I couldn't read '{value}' as a number.")
    if not math.isfinite(v) or v < 0 or v > 100000:
        raise UserError("That number looks off. Try again?")
    d = when.date().isoformat()
    if t["kind"] == "once":
        db.delete_where("tracker_logs", "tracker_id=? AND date=?", (t["id"], d))
    elif t["kind"] == "check":
        existing = db.row("SELECT * FROM tracker_logs WHERE tracker_id=? AND date=?", (t["id"], d))
        if existing:
            return existing
        v = 1.0
    db.insert("tracker_logs", dict(tracker_id=t["id"], ts=clock.iso(when), date=d, value=v, note=(note or "")[:200]))
    return {"tracker": t, "value": v, "total": total(t, when.date())}


def toggle_check(ref: Any, d: date | None = None) -> bool:
    """For done/not-done habits. Returns the new state."""
    t = find_tracker(ref)
    d = d or clock.today()
    existing = db.rows("SELECT id FROM tracker_logs WHERE tracker_id=? AND date=?", (t["id"], d.isoformat()))
    if existing:
        for r in existing:
            db.delete("tracker_logs", r["id"])
        return False
    db.insert("tracker_logs", dict(tracker_id=t["id"], ts=clock.iso(), date=d.isoformat(), value=1.0, note=""))
    return True


def undo_last(ref: Any, d: date | None = None) -> bool:
    t = find_tracker(ref)
    d = d or clock.today()
    r = db.row("SELECT id FROM tracker_logs WHERE tracker_id=? AND date=? ORDER BY id DESC LIMIT 1",
               (t["id"], d.isoformat()))
    return bool(r and db.delete("tracker_logs", r["id"]))


# --------------------------------------------------------------------------- totals
def _auto_minutes(t: dict, by_date: dict[str, int]) -> dict[str, float]:
    unit = (t["unit"] or "").lower()
    if not t["source_category"] or unit not in {"min", "mins", "minutes", "m", "h", "hr", "hrs", "hours"}:
        return {}
    scale = 1 / 60 if unit.startswith("h") else 1
    return {d: m * scale for d, m in by_date.items()}


def totals_between(t: dict, start: date, end: date) -> dict[date, float]:
    s, e = start.isoformat(), end.isoformat()
    out: dict[str, float] = {}
    if t["kind"] == "sum":
        for r in db.rows("SELECT date, SUM(value) v FROM tracker_logs WHERE tracker_id=? AND date>=? AND date<=? "
                         "GROUP BY date", (t["id"], s, e)):
            out[r["date"]] = r["v"]
        if t["source_category"]:
            by = {r["date"]: r["m"] for r in db.rows(
                "SELECT l.date, SUM(l.minutes) m FROM time_logs l JOIN tasks k ON k.id=l.task_id "
                "WHERE k.category=? AND l.date>=? AND l.date<=? GROUP BY l.date", (t["source_category"], s, e))}
            for d, v in _auto_minutes(t, by).items():
                out[d] = out.get(d, 0) + v
    elif t["kind"] == "once":
        for r in db.rows("SELECT date, value FROM tracker_logs WHERE id IN (SELECT MAX(id) FROM tracker_logs "
                         "WHERE tracker_id=? AND date>=? AND date<=? GROUP BY date)", (t["id"], s, e)):
            out[r["date"]] = r["value"]
    else:
        for r in db.rows("SELECT DISTINCT date FROM tracker_logs WHERE tracker_id=? AND date>=? AND date<=? AND value>0",
                         (t["id"], s, e)):
            out[r["date"]] = 1.0
    return {date.fromisoformat(k): v for k, v in out.items()}


def total(t: dict | int, d: date | None = None) -> float:
    t = find_tracker(t)
    d = d or clock.today()
    return totals_between(t, d, d).get(d, 0.0)


def met(t: dict, value: float) -> bool:
    return value >= (t["target"] or 1) - 1e-9


def progress(t: dict, d: date | None = None) -> dict:
    d = d or clock.today()
    v = total(t, d)
    target = t["target"] or 1
    return {"total": v, "target": target, "pct": min(1.0, v / target) if target else 0.0, "met": met(t, v)}


def history(t: dict, days: int = 14, end: date | None = None) -> list[tuple[date, float]]:
    end = end or clock.today()
    start = end - timedelta(days=days - 1)
    totals = totals_between(t, start, end)
    return [(start + timedelta(days=i), totals.get(start + timedelta(days=i), 0.0)) for i in range(days)]


def streak(t: dict, today: date | None = None) -> int:
    """Consecutive days meeting the target, ending today (or yesterday if today isn't done yet)."""
    today = today or clock.today()
    totals = totals_between(t, today - timedelta(days=120), today)
    d = today if met(t, totals.get(today, 0.0)) else today - timedelta(days=1)
    n = 0
    while met(t, totals.get(d, 0.0)):
        n += 1
        d -= timedelta(days=1)
    return n


def consistency(t: dict, days: int = 14) -> float:
    """Share of the last N days on which the target was met."""
    hist = history(t, days)
    return sum(1 for _, v in hist if met(t, v)) / max(1, len(hist))


def format_value(t: dict, value: float) -> str:
    unit = t["unit"] or ""
    if t["kind"] == "check":
        return "done" if value >= 1 else "not yet"
    if unit == "ml" and value >= 1000:
        return f"{value / 1000:.1f} L".replace(".0 L", " L")
    shown = f"{value:.1f}".rstrip("0").rstrip(".") if value % 1 else f"{int(value)}"
    return f"{shown} {unit}".strip()
