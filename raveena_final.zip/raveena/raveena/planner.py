"""The planner.

Turns open tasks + your routines + your rhythm into a day-by-day schedule, and adapts it
when life happens: missed blocks, tasks that run over, low-energy days.

How a day is built
------------------
1. Free time = your planning window minus routines, events and blocks you've locked.
   (For today, nothing is placed before *now*.)
2. Each open task gets a score: priority + deadline pressure (overdue > today > tomorrow ...)
   + a nudge for tasks that keep slipping + a small bonus for tasks tied to a goal.
3. Free windows are filled in time order. Deep-focus tasks are matched to your peak window and
   lighter ones to the rest of the day. Long tasks are split into sessions.
4. Estimates are scaled by how long things *actually* take you (see tasks.estimation_factors).
5. Anything that can't fit before its deadline is reported as "at risk" instead of silently dropped.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from . import clock, db, mood, settings
from . import tasks as T
from .tasks import UserError

MIN_SLOT = 10
STEP = 5
HORIZON_DAYS = 7
PRIORITY_WEIGHT = {1: 100, 2: 70, 3: 40, 4: 15}

_DEEP_WORDS = {"write", "essay", "study", "revise", "revision", "research", "design", "code", "coding",
               "program", "solve", "problem", "thesis", "paper", "report", "read", "chapter", "learn",
               "practice", "draft", "analyse", "analyze", "assignment", "project", "proposal",
               "presentation", "exam", "model", "prepare", "lab"}
_LIGHT_WORDS = {"email", "mail", "call", "text", "message", "reply", "buy", "order", "pay", "bill", "book",
                "schedule", "clean", "laundry", "tidy", "organize", "organise", "errand", "pick", "drop",
                "submit", "print", "fill", "form", "cook", "shop", "renew", "return"}


# --------------------------------------------------------------------------- small helpers
def _m(hm: str) -> int:
    return clock.hm_to_min(hm)


def _hm(minutes: int) -> str:
    return clock.min_to_hm(minutes)


def _ceil_to(n: float, step: int = STEP) -> int:
    return int(math.ceil(n / step) * step)


def _floor_to(n: float, step: int = STEP) -> int:
    return int(n // step * step)


def _at(d: str, hm: str) -> datetime:
    return datetime.fromisoformat(f"{d}T{hm}:00")


def is_deep(task: dict) -> bool:
    """Does this task want your best focus? Explicit setting wins, then keywords, then size."""
    if task.get("energy") == "deep":
        return True
    if task.get("energy") == "light":
        return False
    words = set(T._norm(task["title"]).split())
    if words & _LIGHT_WORDS:
        return False
    if words & _DEEP_WORDS:
        return True
    return task.get("category") in ("Study", "Creative") or (task.get("est_minutes") or 0) >= 60


# --------------------------------------------------------------------------- planning state
@dataclass
class _Item:
    task: dict
    rem: int
    due: date | None
    due_min: int | None
    deep: bool

    @property
    def id(self) -> int:
        return self.task["id"]

    def eligible(self, d: date, today: date) -> bool:
        return self.due is None or self.due < today or d <= self.due

    def urgent(self, d: date, today: date) -> bool:
        return self.due is not None and (self.due < today or self.due <= d)

    def score(self, d: date, today: date) -> float:
        t = self.task
        s = float(PRIORITY_WEIGHT.get(t["priority"], 40))
        if self.due is not None:
            if self.due < today:
                s += 200 + min(10, (today - self.due).days) * 5
            else:
                left = (self.due - d).days
                s += 150 if left <= 0 else 110 if left == 1 else 80 if left <= 3 else 45 if left <= 7 else 15
        s += min(5, t.get("postponed") or 0) * 6
        if t.get("goal_id"):
            s += 8
        if t["status"] == "doing":
            s += 5
        return s


@dataclass
class PlanResult:
    days: list[date]
    placed: list[dict] = field(default_factory=list)
    at_risk: list[dict] = field(default_factory=list)      # {"task", "short"}
    backlog: list[dict] = field(default_factory=list)      # {"task", "short"}: open, just not scheduled yet
    cleared: int = 0
    missed: int = 0
    load: float = 1.0
    load_reason: str | None = None

    @property
    def minutes_placed(self) -> int:
        return sum(_m(b["end"]) - _m(b["start"]) for b in self.placed)

    def text(self, limit: int = 14) -> str:
        """A compact, model- and human-readable description of what was planned."""
        from . import fmt
        lines = []
        by_day: dict[str, list[dict]] = {}
        for b in self.placed:
            by_day.setdefault(b["date"], []).append(b)
        for d in sorted(by_day)[:limit]:
            lines.append(f"{fmt.day(d)}:")
            for b in by_day[d]:
                lines.append(f"  {b['start']}-{b['end']} {b['title']} (task #{b['task_id']}, block #{b['id']})")
        if not self.placed:
            lines.append("Nothing new was placed.")
        if self.missed:
            lines.append(f"{self.missed} earlier block(s) were marked missed and rescheduled.")
        if self.load < 1:
            lines.append(f"I kept today lighter ({int(self.load * 100)}% load)" + (f" because {self.load_reason}." if self.load_reason else "."))
        for r in self.at_risk:
            lines.append(f"AT RISK: '{r['task']['title']}' (task #{r['task']['id']}) due "
                         f"{fmt.day(r['task']['due_date'])} still needs {fmt.duration(r['short'])} with no room.")
        if self.backlog:
            lines.append(f"{len(self.backlog)} other open task(s) have no slot yet in this window.")
        return "\n".join(lines)


# --------------------------------------------------------------------------- free time
def _busy(d: date) -> list[tuple[int, int]]:
    out = [(_m(r["start"]), _m(r["end"])) for r in T.routines_on(d)]
    out += [(_m(e["start"]), _m(e["end"])) for e in T.events_on(d)]
    out += [(_m(b["start"]), _m(b["end"])) for b in
            db.rows("SELECT start,end FROM blocks WHERE date=? AND status IN ('planned','done')", (d.isoformat(),))]
    return out


def _free(d: date, floor: int | None, cfg: dict) -> list[tuple[int, int]]:
    ws, we = _m(cfg["day_start"]), _m(cfg["day_end"])
    if floor is not None:
        ws = max(ws, floor)
    busy = sorted((max(s, ws), min(e, we)) for s, e in _busy(d) if e > ws and s < we)
    free, cur = [], ws
    for s, e in busy:
        if s > cur:
            free.append((cur, s))
        cur = max(cur, e)
    if cur < we:
        free.append((cur, we))
    return [(a, b) for a, b in free if b - a >= MIN_SLOT]


def _preserved_minutes(d: date) -> int:
    return sum(_m(r["end"]) - _m(r["start"]) for r in
               db.rows("SELECT start,end FROM blocks WHERE date=? AND status IN ('planned','done')", (d.isoformat(),)))


def day_capacity(d: date, cfg: dict | None = None, load: float = 1.0) -> int:
    cfg = cfg or settings.all()
    base = cfg["max_focus_minutes"] * (cfg["weekend_load"] if d.weekday() >= 5 else 1.0)
    return int(base * load)


# --------------------------------------------------------------------------- building items
def _planned_ahead(now: datetime) -> dict[int, int]:
    out: dict[int, int] = {}
    for b in db.rows("SELECT task_id,date,start,end FROM blocks WHERE status='planned'"):
        if _at(b["date"], b["end"]) > now:
            out[b["task_id"]] = out.get(b["task_id"], 0) + _m(b["end"]) - _m(b["start"])
    return out


def _build_items(now: datetime) -> dict[int, _Item]:
    factors = T.estimation_factors()
    ahead = _planned_ahead(now)
    items: dict[int, _Item] = {}
    for t in T.list_tasks(status=["todo", "doing"]):
        est = T.effective_estimate(t, factors)
        spent = t["actual_minutes"] or 0
        planned = ahead.get(t["id"], 0)
        rem = est - spent - planned
        if t["status"] == "doing" and spent >= est and planned == 0:
            rem = max(rem, 30)                      # running over: set aside time to finish
        if rem <= 0:
            continue
        due = date.fromisoformat(t["due_date"]) if t["due_date"] else None
        due_min = _m(t["due_time"]) if t["due_time"] else None
        items[t["id"]] = _Item(t, _ceil_to(rem), due, due_min, is_deep(t))
    return items


def _pick(items: list[_Item], d: date, today: date, cur: int, slot_end: int, peak: bool,
          bmin: int, skip: set[int], *, wait_for_peak: int | None = None) -> _Item | None:
    """Best task for the window starting at ``cur``.

    ``wait_for_peak`` is the start of a peak window still ahead today (when there is enough of it
    left): deep tasks are held back for it and light tasks may not run into it.
    """
    best, best_score = None, -1.0
    for it in items:
        if it.rem <= 0 or it.id in skip or not it.eligible(d, today):
            continue
        end = slot_end
        if wait_for_peak is not None and not it.urgent(d, today):
            if it.deep:
                continue
            end = min(end, wait_for_peak)
        if it.due == d and it.due_min is not None:
            end = min(end, it.due_min)
        eff = end - cur
        if eff < min(it.rem, bmin):
            continue
        s = it.score(d, today) + (25 if it.deep == peak else 0) + (6 if it.rem <= eff else 0)
        if s > best_score:
            best, best_score = it, s
    return best


def _chunk(it: _Item, eff: int, allowed: int, bmax: int, bmin: int) -> int:
    length = _floor_to(min(it.rem, bmax, eff, allowed))
    leftover = it.rem - length
    if 0 < leftover < bmin:
        absorb = length + leftover
        if absorb <= min(eff, allowed, bmax + 20):
            length = _floor_to(absorb)
        elif length - (bmin - leftover) >= bmin:
            length -= _ceil_to(bmin - leftover)
    return max(0, length)


def _plan_day(d: date, items: list[_Item], today: date, floor: int | None, cfg: dict,
              load: float) -> list[dict]:
    placed: list[dict] = []
    cap = day_capacity(d, cfg, load)
    preserved = _preserved_minutes(d)
    cap_left = max(0, cap - preserved)
    hard_left = max(0, int(cap * 1.5) - preserved)
    bmax, bmin = int(cfg["block_max"]), int(cfg["block_min"])
    ps, pe = _m(cfg["peak_start"]), _m(cfg["peak_end"])
    free = _free(d, floor, cfg)
    peak_left = sum(max(0, min(b, pe) - max(a, ps)) for a, b in free)
    for a, b in free:
        cur, skip = a, set()
        while b - cur >= MIN_SLOT:
            peak = ps <= cur < pe
            waiting = ps if (cur < ps and peak_left >= bmin) else None
            it = _pick(items, d, today, cur, b, peak, bmin, skip, wait_for_peak=waiting)
            if it is None:
                if waiting is not None and waiting < b:
                    cur = waiting                    # nothing light to do: jump to the peak window
                    continue
                break
            end_limit = b
            if waiting is not None and not it.deep and not it.urgent(d, today):
                end_limit = min(end_limit, waiting)
            if it.due == d and it.due_min is not None:
                end_limit = min(end_limit, it.due_min)
            allowed = hard_left if it.urgent(d, today) else cap_left
            length = _chunk(it, end_limit - cur, allowed, bmax, bmin)
            if length < min(it.rem, MIN_SLOT) or length <= 0:
                skip.add(it.id)
                continue
            placed.append(dict(date=d.isoformat(), start=_hm(cur), end=_hm(cur + length), task_id=it.id,
                               title=it.task["title"], status="planned", locked=0, source="auto"))
            it.rem -= length
            cap_left -= length
            hard_left -= length
            peak_left -= max(0, min(cur + length, pe) - max(cur, ps))
            cur += length + (int(cfg["break_minutes"]) if length >= 45 else 5)
    return placed


# --------------------------------------------------------------------------- public planning API
def mark_missed(now: datetime | None = None) -> list[dict]:
    """Planned blocks whose time has passed without a check-in become 'missed'; their tasks slip a notch."""
    now = now or clock.now()
    out, bumped = [], set()
    for b in db.rows("SELECT * FROM blocks WHERE status='planned' ORDER BY date,start"):
        if _at(b["date"], b["end"]) <= now:
            db.update("blocks", b["id"], {"status": "missed"})
            if b["task_id"] not in bumped:
                T.bump_postponed(b["task_id"])
                bumped.add(b["task_id"])
            out.append(b)
    return out


def rollover(now: datetime | None = None) -> int:
    """Sessions planned for earlier *days* that nobody confirmed count as missed (today's stay as check-ins)."""
    now = now or clock.now()
    n, bumped = 0, set()
    for b in db.rows("SELECT * FROM blocks WHERE status='planned' AND date<? ORDER BY date,start",
                     (now.date().isoformat(),)):
        db.update("blocks", b["id"], {"status": "missed"})
        if b["task_id"] not in bumped:
            T.bump_postponed(b["task_id"])
            bumped.add(b["task_id"])
        n += 1
    return n


def deadline_watch(now: datetime | None = None, days: int = 3) -> list[dict]:
    """Open tasks due within a few days that don't have enough time planned yet."""
    now = now or clock.now()
    horizon = now.date() + timedelta(days=days)
    out = []
    for it in _build_items(now).values():
        if it.due is not None and it.due <= horizon:
            out.append({"task": it.task, "short": it.rem})
    out.sort(key=lambda r: (r["task"]["due_date"], r["task"]["priority"]))
    return out


def unscheduled(now: datetime | None = None) -> list[dict]:
    """Open work that has no time planned yet: [{"task", "short"}] (short = minutes still unplanned)."""
    now = now or clock.now()
    rows = [{"task": it.task, "short": it.rem} for it in _build_items(now).values() if it.rem > 0]
    rows.sort(key=lambda r: (r["task"]["due_date"] or "9999", r["task"]["priority"]))
    return rows


def pending_checkins(now: datetime | None = None) -> list[dict]:
    """Blocks that ended but haven't been confirmed done or missed, with task info."""
    now = now or clock.now()
    out = []
    for b in db.rows("SELECT b.*, t.title, t.category, t.status AS task_status FROM blocks b "
                     "JOIN tasks t ON t.id=b.task_id WHERE b.status='planned' ORDER BY b.date, b.start"):
        if _at(b["date"], b["end"]) <= now and b["task_status"] in ("todo", "doing"):
            out.append(b)
    return out


def _clear(days: list[date], now: datetime) -> int:
    """Remove auto-planned blocks that haven't started yet in these days (locked and running blocks stay)."""
    n = 0
    for d in days:
        for b in db.rows("SELECT * FROM blocks WHERE date=? AND status='planned' AND locked=0", (d.isoformat(),)):
            if _at(b["date"], b["start"]) >= now:          # not started yet (running blocks stay)
                n += int(db.delete("blocks", b["id"]))
    return n


def plan(days: list[date], *, spill: list[date] | None = None, clear: bool = True,
         now: datetime | None = None, load: float | None = None) -> PlanResult:
    """Plan ``days`` (clearing their auto blocks first) and fill free time on ``spill`` days."""
    now = now or clock.now()
    today = now.date()
    cfg = settings.all()
    reason = None
    if load is None:
        load, reason = mood.load_factor()
    elif load < 1:
        reason = "you asked for a lighter day"
    days = [d for d in days if d >= today]
    spill = [d for d in (spill or []) if d >= today and d not in days]
    result = PlanResult(days=days + spill, load=load, load_reason=reason)
    with db.transaction():
        if clear:
            result.cleared = _clear(days, now)
        items = _build_items(now)
        listing = list(items.values())
        for d in days + spill:
            floor = _ceil_to(clock.minutes_of(now)) if d == today else None
            lf = load if d == today else 1.0
            for b in _plan_day(d, listing, today, floor, cfg, lf):
                title = b.pop("title")
                b["created_at"] = db.stamp()
                b["id"] = db.insert("blocks", b)
                b["title"] = title
                result.placed.append(b)
        last = max(result.days) if result.days else today
        for it in listing:
            if it.rem <= 0:
                continue
            row = {"task": it.task, "short": it.rem}
            if it.due is not None and (it.due < today or it.due <= last):
                result.at_risk.append(row)
            else:
                result.backlog.append(row)
    result.at_risk.sort(key=lambda r: (r["task"]["due_date"] or "9999", r["task"]["priority"]))
    return result


def plan_today(*, spill: bool = True, now: datetime | None = None, mark: bool = True,
               load: float | None = None) -> PlanResult:
    """(Re)plan from now to the end of today (overflow goes to the coming days).

    With ``mark=True`` (an explicit "replan"), earlier blocks nobody confirmed count as missed.
    Pass ``mark=False`` when reacting to a single block so other check-ins stay open.
    """
    now = now or clock.now()
    today = now.date()
    with db.transaction():
        missed = mark_missed(now) if mark else []
        res = plan([today], spill=[today + timedelta(days=i) for i in range(1, HORIZON_DAYS)] if spill else [],
                   now=now, load=load)
    res.missed = len(missed)
    return res


def plan_day(d: date, *, now: datetime | None = None, load: float | None = None) -> PlanResult:
    now = now or clock.now()
    if d <= now.date():
        return plan_today(now=now, load=load)
    return plan([d], spill=[], now=now, load=load)


def plan_week(start: date | None = None, *, now: datetime | None = None, load: float | None = None) -> PlanResult:
    """Rebuild the next seven days from scratch (locked blocks stay where you put them)."""
    now = now or clock.now()
    start = max(start or now.date(), now.date())
    with db.transaction():
        missed = mark_missed(now)
        res = plan([start + timedelta(days=i) for i in range(HORIZON_DAYS)], now=now, load=load)
    res.missed = len(missed)
    return res


def ensure_today_plan(now: datetime | None = None) -> PlanResult | None:
    """First open of the day: if there are open tasks but no plan yet, make one."""
    now = now or clock.now()
    today = now.date().isoformat()
    if db.scalar("SELECT COUNT(*) FROM blocks WHERE date=? AND status IN ('planned','done')", (today,), 0):
        return None
    if not T.list_tasks(status=["todo", "doing"], limit=1):
        return None
    return plan_today(now=now)


# --------------------------------------------------------------------------- agenda for the UI
def agenda(d: date, now: datetime | None = None) -> list[dict]:
    """Everything on one day in time order: routines, events and task blocks."""
    items: list[dict] = []
    for r in T.routines_on(d):
        items.append(dict(kind="routine", id=r["id"], title=r["title"], start=r["start"], end=r["end"],
                          category=r["category"], status="fixed"))
    for e in T.events_on(d):
        items.append(dict(kind="event", id=e["id"], title=e["title"], start=e["start"], end=e["end"],
                          category=e["category"], status="fixed"))
    for b in db.rows("SELECT b.*, t.title, t.category, t.priority, t.status AS task_status, t.est_minutes, "
                     "t.due_date, t.actual_minutes FROM blocks b JOIN tasks t ON t.id=b.task_id WHERE b.date=?",
                     (d.isoformat(),)):
        items.append(dict(kind="task", id=b["id"], task_id=b["task_id"], title=b["title"], start=b["start"],
                          end=b["end"], category=b["category"], status=b["status"], locked=b["locked"],
                          priority=b["priority"], task_status=b["task_status"], due_date=b["due_date"],
                          est_minutes=b["est_minutes"], source=b["source"]))
    items.sort(key=lambda x: (_m(x["start"]), _m(x["end"])))
    return items


def day_gaps(d: date, items: list[dict], now: datetime | None = None, min_minutes: int = 25) -> list[dict]:
    """Free windows between items, for showing 'free for 40 min'."""
    cfg = settings.all()
    now = now or clock.now()
    ws, we = _m(cfg["day_start"]), _m(cfg["day_end"])
    if d == now.date():
        ws = max(ws, _ceil_to(clock.minutes_of(now)))
    busy = sorted((_m(i["start"]), _m(i["end"])) for i in items if i["status"] not in ("missed", "skipped"))
    gaps, cur = [], ws
    for s, e in busy:
        if s - cur >= min_minutes:
            gaps.append(dict(kind="gap", start=_hm(cur), end=_hm(s), minutes=s - cur))
        cur = max(cur, e)
    if we - cur >= min_minutes:
        gaps.append(dict(kind="gap", start=_hm(cur), end=_hm(we), minutes=we - cur))
    return gaps


def day_summary(d: date) -> dict:
    """Counts for one day. Sessions that were missed or skipped are not part of the plan any more."""
    blocks = [i for i in agenda(d) if i["kind"] == "task"]
    live = [b for b in blocks if b["status"] in ("planned", "done")]
    mins = lambda bs: sum(_m(b["end"]) - _m(b["start"]) for b in bs)       # noqa: E731
    return dict(blocks=len(live), planned=mins(live), done=mins([b for b in live if b["status"] == "done"]),
                remaining=sum(1 for b in live if b["status"] == "planned"),
                missed=sum(1 for b in blocks if b["status"] in ("missed", "skipped")))


def current_and_next(now: datetime | None = None) -> tuple[dict | None, dict | None]:
    """(block happening now, next planned block today)."""
    now = now or clock.now()
    cur, nxt = None, None
    for i in agenda(now.date()):
        if i["kind"] != "task" or i["status"] != "planned":
            continue
        s, e = _at(now.date().isoformat(), i["start"]), _at(now.date().isoformat(), i["end"])
        if s <= now < e and cur is None:
            cur = i
        elif s > now and nxt is None:
            nxt = i
    return cur, nxt


# --------------------------------------------------------------------------- block operations
def get_block(block_id: int) -> dict:
    b = db.get("blocks", block_id)
    if not b:
        raise UserError(f"There's no scheduled block with id {block_id}.")
    return b


def block_for_task(task_id: int, d: date | None = None) -> dict | None:
    d = d or clock.today()
    return db.row("SELECT * FROM blocks WHERE task_id=? AND date=? AND status='planned' ORDER BY start LIMIT 1",
                  (task_id, d.isoformat()))


def complete_block(block_id: int, actual_minutes=None, finished: bool | None = None,
                   now: datetime | None = None) -> dict:
    """Mark a session done. Logs the time, finishes the task when it's truly done, and re-plans
    the rest of today if the session ran over."""
    now = now or clock.now()
    b = get_block(block_id)
    t = db.get("tasks", b["task_id"])
    if b["status"] == "done" or not t:
        return dict(block=b, task=t, overrun=0, replanned=None, finished=False, left=0)
    planned = _m(b["end"]) - _m(b["start"])
    mins = planned
    if actual_minutes not in (None, ""):
        try:
            mins = max(1, int(round(float(actual_minutes))))
        except (TypeError, ValueError):
            raise UserError(f"I couldn't read '{actual_minutes}' as minutes.")
    with db.transaction():
        db.update("blocks", block_id, {"status": "done"})
        T.log_time(t["id"], mins, start=b["start"], on=date.fromisoformat(b["date"]), source="block")
        t = db.get("tasks", t["id"])
        later = db.scalar("SELECT COUNT(*) FROM blocks WHERE task_id=? AND status='planned'", (t["id"],), 0)
        left = max(0, T.effective_estimate(t) - (t["actual_minutes"] or 0))
        if finished is None:
            finished = later == 0 and left <= 15
        if finished:
            T.complete_task(t["id"])
        overrun = mins - planned
        replanned = None
        if overrun >= 10:
            # blocks this session ran straight through didn't happen: free their tasks for replanning
            actual_end = _m(b["start"]) + mins
            for o in db.rows("SELECT * FROM blocks WHERE date=? AND status='planned' AND locked=0 AND id!=?",
                             (b["date"], block_id)):
                if _m(b["end"]) <= _m(o["start"]) < actual_end:
                    db.update("blocks", o["id"], {"status": "skipped"})
        if (overrun >= 10 or (not finished and left > 15 and later == 0)) and b["date"] == now.date().isoformat():
            replanned = plan_today(now=now, mark=False)
    return dict(block=db.get("blocks", block_id), task=db.get("tasks", t["id"]), overrun=overrun,
                replanned=replanned, finished=bool(finished), left=0 if finished else left)


def miss_block(block_id: int, *, status: str = "missed", replan: bool = True,
               now: datetime | None = None) -> dict:
    """The session didn't happen. Mark it and find new time for the task."""
    now = now or clock.now()
    b = get_block(block_id)
    with db.transaction():
        if b["status"] == "planned":
            db.update("blocks", block_id, {"status": status if status in ("missed", "skipped") else "missed"})
            if status != "skipped":
                T.bump_postponed(b["task_id"])
        res = plan_today(now=now, mark=False) if replan else None
    return dict(block=db.get("blocks", block_id), replanned=res)


def _overlap_name(d: date, start: int, end: int, ignore_block: int | None = None) -> str | None:
    for r in T.routines_on(d):
        if start < _m(r["end"]) and _m(r["start"]) < end:
            return r["title"]
    for e in T.events_on(d):
        if start < _m(e["end"]) and _m(e["start"]) < end:
            return e["title"]
    for b in db.rows("SELECT b.id,b.start,b.end,t.title FROM blocks b JOIN tasks t ON t.id=b.task_id "
                     "WHERE b.date=? AND b.status IN ('planned','done')", (d.isoformat(),)):
        if b["id"] != ignore_block and start < _m(b["end"]) and _m(b["start"]) < end:
            return b["title"]
    return None


def schedule_task(task_id: int, on, start, minutes=None) -> dict:
    """Put a task at a specific time (locked: replanning won't move it)."""
    t = db.get("tasks", task_id)
    if not t:
        raise UserError(f"There's no task with id {task_id}.")
    d, s = T.to_date(on, "date"), T.to_time(start, "start time")
    if d is None or s is None:
        raise UserError("I need a date and a start time.")
    if d < clock.today():
        raise UserError("That date has already passed.")
    dur = int(minutes) if minutes else T.effective_estimate(t)
    end = _m(s) + dur
    if end > 24 * 60:
        raise UserError("That would run past midnight.")
    clash = _overlap_name(d, _m(s), end)
    if clash:
        raise UserError(f"That time overlaps '{clash}'. Pick another time.")
    bid = db.insert("blocks", dict(date=d.isoformat(), start=s, end=_hm(end), task_id=task_id,
                                   status="planned", locked=1, source="manual", created_at=db.stamp()))
    return db.get("blocks", bid)  # type: ignore[return-value]


def move_block(block_id: int, on, start) -> dict:
    b = get_block(block_id)
    d, s = T.to_date(on, "date"), T.to_time(start, "start time")
    if d is None or s is None:
        raise UserError("I need a date and a start time.")
    dur = _m(b["end"]) - _m(b["start"])
    end = _m(s) + dur
    if end > 24 * 60:
        raise UserError("That would run past midnight.")
    clash = _overlap_name(d, _m(s), end, ignore_block=block_id)
    if clash:
        raise UserError(f"That time overlaps '{clash}'. Pick another time.")
    db.update("blocks", block_id, {"date": d.isoformat(), "start": s, "end": _hm(end), "locked": 1,
                                   "source": "manual", "status": "planned"})
    return db.get("blocks", block_id)  # type: ignore[return-value]


def unlock_block(block_id: int) -> None:
    db.update("blocks", block_id, {"locked": 0, "source": "auto"})
