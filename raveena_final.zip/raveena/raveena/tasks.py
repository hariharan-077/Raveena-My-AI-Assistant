"""Tasks, goals, routines, events, time logs and estimate learning."""
from __future__ import annotations

import difflib
import math
import re
from collections import defaultdict
from datetime import date, datetime
from typing import Any

from . import clock, db
from . import timeparse as tp


class UserError(Exception):
    """A problem the person (or the model) can fix: bad input, unknown id, ambiguity."""


CATEGORIES = ["Study", "Work", "Health", "Personal", "Creative", "General"]
PRIORITIES = {1: "Urgent", 2: "High", 3: "Normal", 4: "Low"}
_ALIASES = {
    "Study": {"school", "college", "exam", "exams", "homework", "learning", "university", "class", "course", "revision"},
    "Work": {"job", "office", "career", "business", "client", "meeting", "meetings", "admin"},
    "Health": {"fitness", "exercise", "gym", "wellness", "workout", "medical", "wellbeing", "sport", "sports"},
    "Personal": {"home", "errand", "errands", "life", "family", "social", "finance", "money", "chores", "friends"},
    "Creative": {"art", "writing", "music", "hobby", "design", "side project", "craft"},
}


# --------------------------------------------------------------------------- normalisers
def normalize_category(value: str | None) -> str:
    v = (value or "").strip()
    if not v:
        return "General"
    low = v.lower()
    for c in CATEGORIES:
        if low == c.lower():
            return c
    for c, words in _ALIASES.items():
        if low in words:
            return c
    return v[:24].title()


def normalize_priority(value: Any, default: int = 3) -> int:
    if value is None or value == "":
        return default
    if isinstance(value, str):
        v = value.strip().lower().lstrip("p")
        names = {"urgent": 1, "critical": 1, "high": 2, "important": 2, "normal": 3, "medium": 3, "low": 4}
        if v in names:
            return names[v]
        if v.isdigit():
            value = int(v)
        else:
            return default
    try:
        return min(4, max(1, int(value)))
    except (TypeError, ValueError):
        return default


def to_date(value: Any, field: str = "date") -> date | None:
    """Accept date, datetime, ISO string or plain English ('friday'); None/'' means no date."""
    if value in (None, "", "none", "null"):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    s = str(value).strip()
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        parsed = tp.parse_date(s)
        if parsed:
            return parsed
    raise UserError(f"I couldn't read {field} '{value}'. Use YYYY-MM-DD.")


def to_time(value: Any, field: str = "time") -> str | None:
    if value in (None, "", "none", "null"):
        return None
    hm = tp.normalize_time(str(value))
    if not hm:
        raise UserError(f"I couldn't read {field} '{value}'. Use HH:MM (24-hour).")
    return hm


def _ceil5(n: float) -> int:
    return int(math.ceil(n / 5.0) * 5)


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", s.lower()).strip()


# --------------------------------------------------------------------------- tasks
def default_estimate(category: str) -> int:
    rows = db.rows("SELECT actual_minutes FROM tasks WHERE status='done' AND category=? AND actual_minutes>0 "
                   "ORDER BY completed_at DESC LIMIT 12", (category,))
    vals = sorted(r["actual_minutes"] for r in rows)
    if len(vals) >= 3:
        return max(10, _ceil5(vals[len(vals) // 2]))
    return 30


def add_task(title: str, *, due_date: Any = None, due_time: Any = None, est_minutes: Any = None,
             priority: Any = None, category: str | None = None, energy: str = "auto",
             notes: str = "", goal_id: int | None = None) -> tuple[dict, bool]:
    """Create a task. Returns (task, created). A near-identical open task is reused, not duplicated."""
    title = re.sub(r"\s+", " ", (title or "")).strip(" .")
    if not title:
        raise UserError("A task needs a title.")
    due = to_date(due_date, "due date")
    category = normalize_category(category)
    for t in db.rows("SELECT * FROM tasks WHERE status IN ('todo','doing')"):
        if _norm(t["title"]) == _norm(title) and t["due_date"] == (due.isoformat() if due else None):
            return t, False
    if est_minutes in (None, "", 0):
        est = default_estimate(category)
    else:
        try:
            est = min(600, max(5, _ceil5(float(est_minutes))))
        except (TypeError, ValueError):
            raise UserError(f"I couldn't read the time estimate '{est_minutes}'. Use minutes.")
    energy = energy if energy in ("auto", "deep", "light") else "auto"
    if goal_id is not None and not db.get("goals", goal_id):
        goal_id = None
    tid = db.insert("tasks", dict(
        title=title[:200], notes=(notes or "")[:2000], category=category,
        priority=normalize_priority(priority), due_date=due.isoformat() if due else None,
        due_time=to_time(due_time, "due time"), est_minutes=est, energy=energy, status="todo",
        goal_id=goal_id, created_at=db.stamp()))
    return db.get("tasks", tid), True


def get_task(task_id: int) -> dict | None:
    return db.get("tasks", task_id)


def list_tasks(status: str | list[str] | tuple | None = None, *, category: str | None = None,
               goal_id: int | None = None, search: str | None = None, due_before: date | None = None,
               limit: int | None = None) -> list[dict]:
    where, params = [], []
    if status:
        statuses = [status] if isinstance(status, str) else list(status)
        where.append(f"status IN ({','.join('?' * len(statuses))})")
        params += statuses
    if category:
        where.append("category=?")
        params.append(normalize_category(category))
    if goal_id is not None:
        where.append("goal_id=?")
        params.append(goal_id)
    if search:
        where.append("(title LIKE ? OR notes LIKE ?)")
        params += [f"%{search}%"] * 2
    if due_before:
        where.append("due_date IS NOT NULL AND due_date<=?")
        params.append(due_before.isoformat())
    sql = "SELECT * FROM tasks"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY CASE WHEN due_date IS NULL THEN 1 ELSE 0 END, due_date, priority, id"
    if limit:
        sql += f" LIMIT {int(limit)}"
    return db.rows(sql, params)


def find_task(ref: Any, statuses: tuple[str, ...] | None = ("todo", "doing")) -> dict:
    """Resolve an id ('12', '#12') or a distinctive piece of a title to exactly one task."""
    s = str(ref if ref is not None else "").strip()
    if not s:
        raise UserError("Which task? Give an id or part of its title.")
    m = re.fullmatch(r"#?(\d+)", s)
    if m:
        t = db.get("tasks", int(m[1]))
        if not t:
            raise UserError(f"There's no task with id {m[1]}.")
        return t
    pool = list_tasks(status=list(statuses)) if statuses else list_tasks()
    q = _norm(s)
    exact = [t for t in pool if _norm(t["title"]) == q]
    if len(exact) == 1:
        return exact[0]
    contains = [t for t in pool if q and q in _norm(t["title"])]
    if len(contains) == 1:
        return contains[0]
    if len(contains) > 1:
        raise UserError("More than one task matches '%s': %s. Ask which one, or use the id."
                        % (s, "; ".join(f"#{t['id']} {t['title']}" for t in contains[:5])))
    qtokens = set(q.split())
    scored = []
    for t in pool:
        tt = set(_norm(t["title"]).split())
        overlap = len(qtokens & tt) / max(1, len(qtokens))
        ratio = difflib.SequenceMatcher(None, q, _norm(t["title"])).ratio()
        scored.append((max(overlap, ratio), t))
    scored.sort(key=lambda x: -x[0])
    if scored and scored[0][0] >= 0.6 and (len(scored) == 1 or scored[0][0] - scored[1][0] >= 0.1):
        return scored[0][1]
    hint = ""
    if scored:
        hint = " Closest: " + "; ".join(f"#{t['id']} {t['title']}" for _, t in scored[:3]) + "."
    raise UserError(f"I couldn't find a task matching '{s}'.{hint}")


_EDITABLE = {"title", "notes", "category", "priority", "due_date", "due_time", "est_minutes",
             "energy", "status", "goal_id"}


def update_task(task_id: int, **fields: Any) -> dict:
    t = db.get("tasks", task_id)
    if not t:
        raise UserError(f"There's no task with id {task_id}.")
    values: dict[str, Any] = {}
    for k, v in fields.items():
        if k not in _EDITABLE:
            continue
        if k == "title":
            v = re.sub(r"\s+", " ", str(v or "")).strip()
            if not v:
                raise UserError("A task needs a title.")
        elif k == "category":
            v = normalize_category(v)
        elif k == "priority":
            v = normalize_priority(v, t["priority"])
        elif k == "due_date":
            d = to_date(v, "due date")
            v = d.isoformat() if d else None
        elif k == "due_time":
            v = to_time(v, "due time")
        elif k == "est_minutes":
            try:
                v = min(600, max(5, _ceil5(float(v))))
            except (TypeError, ValueError):
                raise UserError(f"I couldn't read the time estimate '{v}'.")
        elif k == "energy" and v not in ("auto", "deep", "light"):
            v = "auto"
        elif k == "status" and v not in ("todo", "doing", "done", "dropped"):
            raise UserError("Status must be todo, doing, done or dropped.")
        values[k] = v
    if values.get("status") == "done":
        return complete_task(task_id)
    if "status" in values:
        values["completed_at"] = None
    if values:
        db.update("tasks", task_id, values)
    if values.get("status") == "dropped":
        _clear_future_blocks(task_id)
    return db.get("tasks", task_id)  # type: ignore[return-value]


def _clear_future_blocks(task_id: int) -> None:
    """Remove planned blocks that haven't ended; mark the ones already past as done."""
    now = clock.now()
    for b in db.rows("SELECT * FROM blocks WHERE task_id=? AND status='planned'", (task_id,)):
        end = datetime.fromisoformat(f"{b['date']}T{b['end']}:00")
        if end <= now:
            db.update("blocks", b["id"], {"status": "done"})
        else:
            db.delete("blocks", b["id"])


def complete_task(task_id: int, actual_minutes: Any = None) -> dict:
    t = db.get("tasks", task_id)
    if not t:
        raise UserError(f"There's no task with id {task_id}.")
    if t["status"] == "done":
        return t
    if actual_minutes not in (None, ""):
        try:
            total = int(round(float(actual_minutes)))
        except (TypeError, ValueError):
            raise UserError(f"I couldn't read the time '{actual_minutes}'. Use minutes.")
        if total > t["actual_minutes"]:
            log_time(task_id, total - t["actual_minutes"], source="complete")
        elif total != t["actual_minutes"] and total >= 0:
            db.update("tasks", task_id, {"actual_minutes": total})
    db.update("tasks", task_id, {"status": "done", "completed_at": db.stamp()})
    _clear_future_blocks(task_id)
    return db.get("tasks", task_id)  # type: ignore[return-value]


def reopen_task(task_id: int) -> dict:
    db.update("tasks", task_id, {"status": "todo", "completed_at": None})
    return db.get("tasks", task_id)  # type: ignore[return-value]


def delete_task(task_id: int) -> bool:
    if not db.get("tasks", task_id):
        return False
    db.delete_where("blocks", "task_id=?", (task_id,))
    db.delete_where("time_logs", "task_id=?", (task_id,))
    return db.delete("tasks", task_id)


def bump_postponed(task_id: int) -> None:
    t = db.get("tasks", task_id)
    if t:
        db.update("tasks", task_id, {"postponed": (t["postponed"] or 0) + 1})


# --------------------------------------------------------------------------- time tracking
def log_time(task_id: int, minutes: Any, *, start: str | None = None, on: date | None = None,
             source: str = "manual") -> dict:
    t = db.get("tasks", task_id)
    if not t:
        raise UserError(f"There's no task with id {task_id}.")
    try:
        mins = int(round(float(minutes)))
    except (TypeError, ValueError):
        raise UserError(f"I couldn't read '{minutes}' as minutes.")
    if not 1 <= mins <= 720:
        raise UserError("Time spent should be between 1 minute and 12 hours.")
    when = clock.now()
    db.insert("time_logs", dict(task_id=task_id, date=(on or when.date()).isoformat(),
                                start=start or when.strftime("%H:%M"), minutes=mins, source=source))
    values: dict[str, Any] = {"actual_minutes": (t["actual_minutes"] or 0) + mins}
    if t["status"] == "todo":
        values["status"] = "doing"
    db.update("tasks", task_id, values)
    return db.get("tasks", task_id)  # type: ignore[return-value]


def minutes_logged(on: date, category: str | None = None) -> int:
    if category:
        return int(db.scalar(
            "SELECT COALESCE(SUM(l.minutes),0) FROM time_logs l JOIN tasks t ON t.id=l.task_id "
            "WHERE l.date=? AND t.category=?", (on.isoformat(), category), 0))
    return int(db.scalar("SELECT COALESCE(SUM(minutes),0) FROM time_logs WHERE date=?", (on.isoformat(),), 0))


# --------------------------------------------------------------------------- learning your pace
def estimation_factors() -> dict[str, float]:
    """How long things *really* take you vs. your estimate, per category ('*' = overall).

    Uses the last few finished tasks with logged time, trims outliers and shrinks toward 1.0
    until there's enough evidence. Raveena multiplies your estimates by this when planning.
    """
    rows = db.rows("SELECT category, est_minutes, actual_minutes FROM tasks WHERE status='done' "
                   "AND est_minutes>0 AND actual_minutes>0 ORDER BY completed_at DESC LIMIT 80")
    by: dict[str, list[float]] = defaultdict(list)
    for r in rows:
        by[r["category"]].append(r["actual_minutes"] / r["est_minutes"])

    def factor(vals: list[float]) -> float | None:
        vals = vals[:10]
        n = len(vals)
        if n < 3:
            return None
        ordered = sorted(vals)
        if n >= 5:
            ordered = ordered[1:-1]
        mean = sum(ordered) / len(ordered)
        f = 1 + (mean - 1) * min(1.0, n / 8)
        return round(min(2.0, max(0.8, f)), 2)

    allr = [x for v in by.values() for x in v]
    out = {"*": factor(allr) or 1.0}
    for cat, vals in by.items():
        f = factor(vals)
        if f is not None:
            out[cat] = f
    return out


def effective_estimate(task: dict, factors: dict[str, float] | None = None) -> int:
    factors = factors if factors is not None else estimation_factors()
    f = factors.get(task["category"], factors.get("*", 1.0))
    return max(5, _ceil5((task["est_minutes"] or 30) * f))


# --------------------------------------------------------------------------- goals
def add_goal(title: str, *, why: str = "", target_date: Any = None, category: str | None = None) -> tuple[dict, bool]:
    title = re.sub(r"\s+", " ", (title or "")).strip()
    if not title:
        raise UserError("A goal needs a title.")
    for g in db.rows("SELECT * FROM goals WHERE status='active'"):
        if _norm(g["title"]) == _norm(title):
            return g, False
    td = to_date(target_date, "target date")
    gid = db.insert("goals", dict(title=title[:200], why=(why or "")[:1000], category=normalize_category(category),
                                  target_date=td.isoformat() if td else None, created_at=db.stamp()))
    return db.get("goals", gid), True


def list_goals(status: str | None = "active") -> list[dict]:
    if status:
        return db.rows("SELECT * FROM goals WHERE status=? ORDER BY CASE WHEN target_date IS NULL THEN 1 ELSE 0 END, "
                       "target_date, id", (status,))
    return db.rows("SELECT * FROM goals ORDER BY id")


def find_goal(ref: Any) -> dict:
    s = str(ref if ref is not None else "").strip()
    if not s:
        raise UserError("Which goal? Give an id or part of its title.")
    m = re.fullmatch(r"#?(\d+)", s)
    if m:
        g = db.get("goals", int(m[1]))
        if g:
            return g
        raise UserError(f"There's no goal with id {m[1]}.")
    q = _norm(s)
    pool = list_goals(None)
    hits = [g for g in pool if q and q in _norm(g["title"])]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1:
        raise UserError("More than one goal matches: " + "; ".join(f"#{g['id']} {g['title']}" for g in hits[:5]))
    raise UserError(f"I couldn't find a goal matching '{s}'.")


def goal_progress(goal: dict) -> tuple[int, int, int]:
    """(percent, tasks_done, tasks_total). Falls back to the manual progress if no tasks are linked."""
    linked = db.rows("SELECT status FROM tasks WHERE goal_id=? AND status!='dropped'", (goal["id"],))
    if not linked:
        return int(goal.get("progress") or 0), 0, 0
    done = sum(1 for t in linked if t["status"] == "done")
    return int(round(100 * done / len(linked))), done, len(linked)


def update_goal(goal_id: int, **fields: Any) -> dict:
    g = db.get("goals", goal_id)
    if not g:
        raise UserError(f"There's no goal with id {goal_id}.")
    values: dict[str, Any] = {}
    for k, v in fields.items():
        if k == "target_date":
            d = to_date(v, "target date")
            values[k] = d.isoformat() if d else None
        elif k == "progress":
            values[k] = min(100, max(0, int(v)))
        elif k == "status" and v in ("active", "done", "paused"):
            values[k] = v
        elif k in ("title", "why"):
            values[k] = str(v).strip()
        elif k == "category":
            values[k] = normalize_category(v)
    if values:
        db.update("goals", goal_id, values)
    return db.get("goals", goal_id)  # type: ignore[return-value]


def delete_goal(goal_id: int) -> bool:
    for t in db.rows("SELECT id FROM tasks WHERE goal_id=?", (goal_id,)):
        db.update("tasks", t["id"], {"goal_id": None})
    return db.delete("goals", goal_id)


# --------------------------------------------------------------------------- routines
def _check_span(start: str, end: str) -> None:
    if clock.hm_to_min(start) >= clock.hm_to_min(end):
        raise UserError("The end time has to be after the start time.")


def add_routine(title: str, days: list[int] | str, start: Any, end: Any,
                category: str | None = "Routine") -> tuple[dict, bool]:
    title = re.sub(r"\s+", " ", (title or "")).strip()
    if not title:
        raise UserError("A routine needs a title.")
    if isinstance(days, str):
        days = tp.parse_days(days) or []
    days = sorted({int(d) for d in days if 0 <= int(d) <= 6})
    if not days:
        raise UserError("Which days? For example Mon, Wed, Fri or 'weekdays'.")
    s, e = to_time(start, "start time"), to_time(end, "end time")
    if not s or not e:
        raise UserError("A routine needs a start and end time.")
    _check_span(s, e)
    for r in db.rows("SELECT * FROM routines WHERE active=1"):
        if _norm(r["title"]) == _norm(title) and r["days"] == ",".join(map(str, days)) and r["start"] == s:
            return r, False
    rid = db.insert("routines", dict(title=title[:120], days=",".join(map(str, days)), start=s, end=e,
                                     category=(category or "Routine")[:24]))
    return db.get("routines", rid), True


def list_routines(active_only: bool = True) -> list[dict]:
    sql = "SELECT * FROM routines" + (" WHERE active=1" if active_only else "") + " ORDER BY start, id"
    out = db.rows(sql)
    for r in out:
        r["day_list"] = [int(x) for x in r["days"].split(",") if x != ""]
    return out


def routines_on(d: date) -> list[dict]:
    return [r for r in list_routines() if d.weekday() in r["day_list"]]


def delete_routine(routine_id: int) -> bool:
    return db.delete("routines", routine_id)


# --------------------------------------------------------------------------- one-off events
def add_event(title: str, on: Any, start: Any, end: Any, category: str | None = "Event",
              notes: str = "") -> tuple[dict, bool]:
    title = re.sub(r"\s+", " ", (title or "")).strip()
    if not title:
        raise UserError("An event needs a title.")
    d = to_date(on, "date")
    if d is None:
        raise UserError("An event needs a date.")
    s, e = to_time(start, "start time"), to_time(end, "end time")
    if not s or not e:
        raise UserError("An event needs a start and end time.")
    _check_span(s, e)
    for ev in db.rows("SELECT * FROM events WHERE date=?", (d.isoformat(),)):
        if _norm(ev["title"]) == _norm(title) and ev["start"] == s:
            return ev, False
    eid = db.insert("events", dict(title=title[:120], date=d.isoformat(), start=s, end=e,
                                   category=(category or "Event")[:24], notes=(notes or "")[:1000]))
    return db.get("events", eid), True


def events_on(d: date) -> list[dict]:
    return db.rows("SELECT * FROM events WHERE date=? ORDER BY start", (d.isoformat(),))


def events_between(a: date, b: date) -> list[dict]:
    return db.rows("SELECT * FROM events WHERE date>=? AND date<=? ORDER BY date, start",
                   (a.isoformat(), b.isoformat()))


def delete_event(event_id: int) -> bool:
    return db.delete("events", event_id)
