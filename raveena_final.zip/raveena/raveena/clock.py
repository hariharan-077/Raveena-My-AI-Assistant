"""One place for "what time is it?" so planning is testable and timezone-aware."""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

# Developer aid: RAVEENA_FAKE_NOW=2026-10-12T14:20:00 pins the clock (used for demos and screenshots).
_frozen: datetime | None = None
if os.environ.get("RAVEENA_FAKE_NOW"):
    try:
        _frozen = datetime.fromisoformat(os.environ["RAVEENA_FAKE_NOW"])
    except ValueError:
        _frozen = None
_tz: ZoneInfo | None = None
_tz_name: str = ""


def set_timezone(name: str | None) -> None:
    """Use an IANA zone like 'Europe/Paris'. Empty means the computer's own zone."""
    global _tz, _tz_name
    name = (name or "").strip()
    if not name:
        _tz, _tz_name = None, ""
        return
    try:
        _tz, _tz_name = ZoneInfo(name), name
    except (ZoneInfoNotFoundError, ValueError):
        _tz, _tz_name = None, ""


def timezone_name() -> str:
    return _tz_name


def freeze(dt: datetime | None) -> None:
    """Pin 'now' (tests only). Pass None to release."""
    global _frozen
    _frozen = dt.replace(microsecond=0) if dt else None


def now() -> datetime:
    """Current local time as a naive datetime (all stored times are local)."""
    if _frozen is not None:
        return _frozen
    dt = datetime.now(_tz) if _tz else datetime.now().astimezone()
    return dt.replace(tzinfo=None, microsecond=0)


def today() -> date:
    return now().date()


def iso(dt: datetime | None = None) -> str:
    return (dt or now()).strftime("%Y-%m-%dT%H:%M:%S")


def parse_iso(s: str) -> datetime:
    return datetime.fromisoformat(s)


def minutes_of(dt: datetime) -> int:
    return dt.hour * 60 + dt.minute


def hm_to_min(s: str) -> int:
    h, _, m = s.partition(":")
    return int(h) * 60 + int(m or 0)


def min_to_hm(m: int) -> str:
    m = max(0, min(int(m), 24 * 60))
    return f"{m // 60:02d}:{m % 60:02d}"


def monday_of(d: date) -> date:
    return d - timedelta(days=d.weekday())
