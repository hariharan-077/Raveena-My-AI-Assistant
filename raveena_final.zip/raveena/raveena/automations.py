"""Things Raveena does for you when you open the app.

Each one can be switched off in Settings, goes through the same safety pipeline as everything else
(logged in the action log, undoable) and is idempotent: opening the app ten times in a day doesn't
plan ten times or write ten briefings.
"""
from __future__ import annotations

from datetime import datetime

from . import clock, conversation, db, fmt, planner, settings, tools
from . import tasks as T


def _briefing_exists(day: str) -> bool:
    for m in conversation.recent(30):
        if m["meta"].get("kind") == "briefing" and m["meta"].get("date") == day:
            return True
    return False


def briefing_text(now: datetime, rolled: int = 0) -> str:
    name = settings.display_name()
    today = now.date()
    items = [i for i in planner.agenda(today) if i["kind"] == "task" and i["status"] == "planned"
             and planner._at(today.isoformat(), i["end"]) > now]
    parts = [f"{fmt.greeting(now.hour)}, {name}."]
    if items:
        first = items[0]
        parts.append(f"{'Today' if now.hour < 17 else 'For the rest of today'} you have "
                     f"{fmt.plural(len(items), 'focus session')} planned, {fmt.duration(sum(planner._m(i['end']) - planner._m(i['start']) for i in items))} in all. "
                     f"First up is “{first['title']}” at {fmt.time(first['start'])}.")
    elif T.list_tasks(status=["todo", "doing"], limit=1):
        parts.append("Nothing is planned for the rest of today. Say “plan my day” if you'd like me to fit something in.")
    else:
        parts.append("Your task list is clear. Tell me what's on your mind, or add something.")
    if rolled:
        parts.append(f"{fmt.plural(rolled, 'session')} from earlier didn't happen, so I moved "
                     f"{'it' if rolled == 1 else 'them'} forward. No harm done.")
    risky = planner.deadline_watch(now, days=2)
    if risky:
        r = risky[0]
        label = fmt.due(r["task"]["due_date"]).lower().replace("due ", "due ", 1)
        parts.append(f"Heads up: “{r['task']['title']}” is {label} and still needs about "
                     f"{fmt.duration(r['short'])} that I can't fit yet. Want to look at it together?")
    parts.append("How are you feeling?" if now.hour < 17 else "How has your day been?")
    return " ".join(parts)


def on_open(now: datetime | None = None) -> dict:
    """Run once per app open. Returns what happened, for gentle notices in the UI."""
    now = now or clock.now()
    cfg = settings.all()
    if not cfg["onboarded"]:
        return {}
    result = {"rolled": 0, "planned": False, "briefed": False}

    if cfg["auto_rollover"]:
        stale = int(db.scalar("SELECT COUNT(*) FROM blocks WHERE status='planned' AND date<?",
                              (now.date().isoformat(),), 0))
        if stale and tools.execute("rollover", {}, source="automation").ok:
            result["rolled"] = stale

    if cfg["auto_daily_plan"] and T.list_tasks(status=["todo", "doing"], limit=1):
        has_plan = db.scalar("SELECT COUNT(*) FROM blocks WHERE date=? AND status IN ('planned','done')",
                             (now.date().isoformat(),), 0)
        if result["rolled"] or not has_plan:        # missed work needs a new home; an empty day needs a plan
            out = tools.execute("plan_schedule", {"scope": "today"}, source="automation")
            result["planned"] = out.ok and bool(out.summary)

    if cfg["morning_briefing"] and not _briefing_exists(now.date().isoformat()):
        conversation.add("assistant", briefing_text(now, result["rolled"]),
                         {"kind": "briefing", "date": now.date().isoformat(), "mode": "auto"})
        result["briefed"] = True
    return result

