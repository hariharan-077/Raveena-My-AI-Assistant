"""SQLite storage.

Design notes
------------
* One local file, no server. Safe for a single person using the app in one or two tabs.
* Every write goes through ``insert`` / ``update`` / ``delete``. When a *journal* is
  active (see ``journal()``), each write records its inverse, so any action Raveena
  takes can be undone later by replaying the journal backwards. This is the safety
  net behind automation.
"""
from __future__ import annotations

import contextlib
import contextvars
import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Iterable, Iterator

from . import clock, config

TABLES = {
    "goals", "tasks", "routines", "events", "blocks", "time_logs", "trackers",
    "tracker_logs", "moods", "memories", "messages", "actions",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  why TEXT DEFAULT '',
  category TEXT DEFAULT 'General',
  target_date TEXT,
  progress INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  notes TEXT DEFAULT '',
  category TEXT DEFAULT 'General',
  priority INTEGER DEFAULT 3,
  due_date TEXT,
  due_time TEXT,
  est_minutes INTEGER DEFAULT 30,
  actual_minutes INTEGER DEFAULT 0,
  energy TEXT DEFAULT 'auto',
  status TEXT DEFAULT 'todo',
  goal_id INTEGER,
  postponed INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);

CREATE TABLE IF NOT EXISTS routines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  days TEXT NOT NULL,
  start TEXT NOT NULL,
  end TEXT NOT NULL,
  category TEXT DEFAULT 'Routine',
  active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  start TEXT NOT NULL,
  end TEXT NOT NULL,
  category TEXT DEFAULT 'Event',
  notes TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(date);

CREATE TABLE IF NOT EXISTS blocks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  start TEXT NOT NULL,
  end TEXT NOT NULL,
  task_id INTEGER NOT NULL,
  status TEXT DEFAULT 'planned',
  locked INTEGER DEFAULT 0,
  source TEXT DEFAULT 'auto',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_blocks_date ON blocks(date);
CREATE INDEX IF NOT EXISTS idx_blocks_task ON blocks(task_id);

CREATE TABLE IF NOT EXISTS time_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  start TEXT,
  minutes INTEGER NOT NULL,
  source TEXT DEFAULT 'manual'
);
CREATE INDEX IF NOT EXISTS idx_timelogs_date ON time_logs(date);

CREATE TABLE IF NOT EXISTS trackers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  kind TEXT DEFAULT 'sum',
  unit TEXT DEFAULT '',
  target REAL DEFAULT 1,
  step REAL DEFAULT 1,
  icon TEXT DEFAULT 'spark',
  color TEXT DEFAULT '#0F7C8C',
  source_category TEXT,
  active INTEGER DEFAULT 1,
  position INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS tracker_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tracker_id INTEGER NOT NULL,
  ts TEXT NOT NULL,
  date TEXT NOT NULL,
  value REAL NOT NULL,
  note TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_tlogs ON tracker_logs(tracker_id, date);

CREATE TABLE IF NOT EXISTS moods (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  date TEXT NOT NULL,
  mood INTEGER NOT NULL,
  energy INTEGER,
  tags TEXT DEFAULT '',
  note TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS memories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT DEFAULT 'fact',
  content TEXT NOT NULL,
  importance INTEGER DEFAULT 3,
  source TEXT DEFAULT 'user',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_used TEXT
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  meta TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  source TEXT DEFAULT 'chat',
  tool TEXT NOT NULL,
  args TEXT DEFAULT '{}',
  summary TEXT DEFAULT '',
  status TEXT NOT NULL,
  risk TEXT DEFAULT 'low',
  result TEXT DEFAULT '',
  undo TEXT,
  turn TEXT
);
"""

DEFAULT_TRACKERS = [
    dict(name="Water", kind="sum", unit="ml", target=2500, step=250, icon="drop",
         color="#2F8FBF", source_category=None, position=0),
    dict(name="Study", kind="sum", unit="min", target=120, step=30, icon="book",
         color="#5667D9", source_category="Study", position=1),
    dict(name="Exercise", kind="sum", unit="min", target=30, step=15, icon="pulse",
         color="#2F9E6E", source_category=None, position=2),
    dict(name="Sleep", kind="once", unit="h", target=7.5, step=0.5, icon="moon",
         color="#7B6BC9", source_category=None, position=3),
    dict(name="Meditate", kind="check", unit="", target=1, step=1, icon="leaf",
         color="#D9822B", source_category=None, position=4),
]

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None
_conn_path: Path | None = None
_tx_depth = 0
_journal_var: contextvars.ContextVar[list | None] = contextvars.ContextVar(
    "raveena_journal", default=None)


# --------------------------------------------------------------------------- setup
def init(path: Path | str | None = None) -> sqlite3.Connection:
    """Open (and create) the database. Safe to call repeatedly."""
    global _conn, _conn_path
    with _lock:
        if path is None and _conn is not None:
            return _conn                      # already open: keep using it
        target = Path(path) if path else config.DB_PATH
        if _conn is not None and _conn_path == target:
            return _conn
        if _conn is not None:
            _conn.close()
        target.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(target), check_same_thread=False, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(SCHEMA)
        _conn, _conn_path = conn, target
        _seed()
        return conn


def close() -> None:
    global _conn, _conn_path
    with _lock:
        if _conn is not None:
            _conn.close()
        _conn, _conn_path = None, None


def path() -> Path:
    init()
    assert _conn_path is not None
    return _conn_path


def _seed() -> None:
    """First-run defaults. Seeded once; deleting a tracker later never brings it back."""
    flag = scalar("SELECT value FROM settings WHERE key='trackers_seeded'")
    if flag:
        return
    for t in DEFAULT_TRACKERS:
        _exec("INSERT INTO trackers (name,kind,unit,target,step,icon,color,source_category,position) "
              "VALUES (?,?,?,?,?,?,?,?,?)",
              (t["name"], t["kind"], t["unit"], t["target"], t["step"], t["icon"], t["color"],
               t["source_category"], t["position"]))
    _exec("INSERT OR REPLACE INTO settings (key,value) VALUES ('trackers_seeded','true')")


# --------------------------------------------------------------------------- raw access
def _exec(sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
    with _lock:
        c = _conn if _conn is not None else init()
        return c.execute(sql, tuple(params))


def rows(sql: str, params: Iterable[Any] = ()) -> list[dict]:
    init()
    return [dict(r) for r in _exec(sql, params).fetchall()]


def row(sql: str, params: Iterable[Any] = ()) -> dict | None:
    init()
    r = _exec(sql, params).fetchone()
    return dict(r) if r else None


def scalar(sql: str, params: Iterable[Any] = (), default: Any = None) -> Any:
    init()
    r = _exec(sql, params).fetchone()
    return default if r is None or r[0] is None else r[0]


def run(sql: str, params: Iterable[Any] = ()) -> int:
    """Execute a write and return lastrowid. Prefer insert/update/delete for journaling."""
    init()
    return _exec(sql, params).lastrowid or 0


@contextlib.contextmanager
def transaction() -> Iterator[None]:
    """Group writes so they commit (or roll back) together. Nesting is fine."""
    global _tx_depth
    init()
    with _lock:
        outer = _tx_depth == 0
        if outer:
            _exec("BEGIN")
        _tx_depth += 1
        try:
            yield
        except BaseException:
            _tx_depth -= 1
            if outer:
                _exec("ROLLBACK")
            raise
        else:
            _tx_depth -= 1
            if outer:
                _exec("COMMIT")


def _check(table: str) -> str:
    if table not in TABLES:
        raise ValueError(f"unknown table {table!r}")
    return table


def _log(op: dict) -> None:
    j = _journal_var.get()
    if j is not None:
        j.append(op)


# --------------------------------------------------------------------------- CRUD (journaled)
def get(table: str, id: int) -> dict | None:
    return row(f"SELECT * FROM {_check(table)} WHERE id=?", (id,))


def insert(table: str, values: dict) -> int:
    _check(table)
    cols = ",".join(values)
    marks = ",".join("?" * len(values))
    rid = run(f"INSERT INTO {table} ({cols}) VALUES ({marks})", tuple(values.values()))
    _log({"op": "delete", "t": table, "id": rid})
    return rid


def update(table: str, id: int, values: dict) -> bool:
    _check(table)
    old = get(table, id)
    if old is None or not values:
        return False
    sets = ",".join(f"{k}=?" for k in values)
    run(f"UPDATE {table} SET {sets} WHERE id=?", (*values.values(), id))
    _log({"op": "restore", "t": table, "id": id, "row": old})
    return True


def delete(table: str, id: int) -> bool:
    _check(table)
    old = get(table, id)
    if old is None:
        return False
    run(f"DELETE FROM {table} WHERE id=?", (id,))
    _log({"op": "insert", "t": table, "row": old})
    return True


def delete_where(table: str, where: str, params: Iterable[Any] = ()) -> int:
    n = 0
    for r in rows(f"SELECT id FROM {_check(table)} WHERE {where}", params):
        n += int(delete(table, r["id"]))
    return n


# --------------------------------------------------------------------------- journal / undo
@contextlib.contextmanager
def journal() -> Iterator[list]:
    """Record the inverse of every write made inside the block."""
    ops: list = []
    token = _journal_var.set(ops)
    try:
        yield ops
    finally:
        _journal_var.reset(token)


def log_setting_change(key: str, old: Any) -> None:
    _log({"op": "setting", "key": key, "old": old})


def rollback(ops: list) -> None:
    """Undo a journal: replay inverse operations newest-first."""
    token = _journal_var.set(None)  # don't journal the undo itself
    try:
        with transaction():
            for op in reversed(ops):
                kind = op["op"]
                if kind == "delete":
                    run(f"DELETE FROM {_check(op['t'])} WHERE id=?", (op["id"],))
                elif kind == "restore":
                    r = op["row"]
                    cols = [c for c in r if c != "id"]
                    run(f"UPDATE {_check(op['t'])} SET {','.join(c + '=?' for c in cols)} WHERE id=?",
                        (*[r[c] for c in cols], r["id"]))
                elif kind == "insert":
                    r = op["row"]
                    run(f"INSERT OR REPLACE INTO {_check(op['t'])} ({','.join(r)}) "
                        f"VALUES ({','.join('?' * len(r))})", tuple(r.values()))
                elif kind == "setting":
                    if op["old"] is None:
                        run("DELETE FROM settings WHERE key=?", (op["key"],))
                    else:
                        run("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)",
                            (op["key"], op["old"]))
    finally:
        _journal_var.reset(token)


# --------------------------------------------------------------------------- helpers
def dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)


def loads(s: str | None, default: Any = None) -> Any:
    if not s:
        return default
    try:
        return json.loads(s)
    except (TypeError, ValueError):
        return default


def stamp() -> str:
    return clock.iso()


def wipe_everything() -> None:
    """Delete the database file and start fresh (used by the 'erase all data' button)."""
    p = path()
    close()
    for suffix in ("", "-wal", "-shm"):
        with contextlib.suppress(OSError):
            Path(str(p) + suffix).unlink()
    init(p)


def checkpoint() -> None:
    """Fold the write-ahead log into the main file (so a file copy is a complete backup)."""
    try:
        run("PRAGMA wal_checkpoint(TRUNCATE)")
    except sqlite3.Error:
        pass


def export_all() -> dict:
    """Every table as plain JSON-able lists, for the 'download my data' button."""
    out = {t: rows(f"SELECT * FROM {t}") for t in sorted(TABLES)}
    out["settings"] = {r["key"]: loads(r["value"]) for r in rows("SELECT key, value FROM settings")}
    return out
