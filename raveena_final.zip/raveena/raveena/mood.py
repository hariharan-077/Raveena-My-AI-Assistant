"""Mood and energy check-ins. They also shape how heavy Raveena makes your plan."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from . import clock, db
from .tasks import UserError

MOOD_LABELS = {1: "Very low", 2: "Low", 3: "Okay", 4: "Good", 5: "Great"}
ENERGY_LABELS = {1: "Drained", 2: "Low", 3: "Steady", 4: "Good", 5: "Charged"}


def _score(v, name: str) -> int | None:
    if v in (None, ""):
        return None
    try:
        n = int(round(float(v)))
    except (TypeError, ValueError):
        raise UserError(f"{name} should be a number from 1 to 5.")
    return min(5, max(1, n))


def log_mood(mood, energy=None, note: str = "", tags=None, when: datetime | None = None) -> dict:
    m = _score(mood, "Mood")
    if m is None:
        raise UserError("Mood should be a number from 1 (low) to 5 (great).")
    when = when or clock.now()
    if isinstance(tags, (list, tuple)):
        tags = ",".join(str(t).strip() for t in tags if str(t).strip())
    rid = db.insert("moods", dict(ts=clock.iso(when), date=when.date().isoformat(), mood=m,
                                  energy=_score(energy, "Energy"), tags=(tags or "")[:200],
                                  note=(note or "").strip()[:500]))
    return db.get("moods", rid)  # type: ignore[return-value]


def latest(within_hours: float | None = None) -> dict | None:
    r = db.row("SELECT * FROM moods ORDER BY ts DESC, id DESC LIMIT 1")
    if not r:
        return None
    if within_hours is not None:
        age = clock.now() - datetime.fromisoformat(r["ts"])
        if age > timedelta(hours=within_hours):
            return None
    return r


def on(d: date) -> list[dict]:
    return db.rows("SELECT * FROM moods WHERE date=? ORDER BY ts", (d.isoformat(),))


def history(days: int = 30, end: date | None = None) -> list[dict]:
    end = end or clock.today()
    start = end - timedelta(days=days - 1)
    return db.rows("SELECT * FROM moods WHERE date>=? AND date<=? ORDER BY ts",
                   (start.isoformat(), end.isoformat()))


def daily_averages(days: int = 30, end: date | None = None) -> dict[date, tuple[float, float | None]]:
    """date -> (avg mood, avg energy or None)."""
    buckets: dict[date, list[dict]] = {}
    for r in history(days, end):
        buckets.setdefault(date.fromisoformat(r["date"]), []).append(r)
    out = {}
    for d, rs in buckets.items():
        energies = [r["energy"] for r in rs if r["energy"]]
        out[d] = (sum(r["mood"] for r in rs) / len(rs), sum(energies) / len(energies) if energies else None)
    return out


def summary(days: int = 7) -> dict:
    cur = history(days)
    prev = history(days, end=clock.today() - timedelta(days=days))

    def avg(rs, key):
        vals = [r[key] for r in rs if r[key]]
        return sum(vals) / len(vals) if vals else None

    m, p = avg(cur, "mood"), avg(prev, "mood")
    return {"n": len(cur), "avg_mood": m, "avg_energy": avg(cur, "energy"),
            "delta": (m - p) if (m is not None and p is not None) else None}


def load_factor() -> tuple[float, str | None]:
    """How much of a normal day to plan. Lighter when you've told Raveena you're low."""
    r = latest(within_hours=14)
    if not r:
        return 1.0, None
    low = min(r["mood"], r["energy"] or 5)
    if low <= 2:
        return 0.65, "you said you're feeling low today"
    return 1.0, None
