"""Audit log, approval queue and undo for everything Raveena does on your behalf.

Every non-trivial action is written here with a plain-English summary. Low-risk actions run
immediately and store a journal of inverse operations, so they can be undone. High-risk actions
(deleting things, forgetting memories) are parked as *pending* until you approve them.
"""
from __future__ import annotations

from . import clock, db
from .tasks import UserError

STATUSES = ("done", "pending", "rejected", "failed", "undone")


def create(tool: str, args: dict, summary: str, *, risk: str = "low", status: str = "done",
           source: str = "chat", turn: str | None = None) -> int:
    return db.run(
        "INSERT INTO actions (ts,source,tool,args,summary,status,risk,turn) VALUES (?,?,?,?,?,?,?,?)",
        (clock.iso(), source, tool, db.dumps(args), summary, status, risk, turn))


def finish(action_id: int, status: str, *, result: str = "", summary: str | None = None,
           undo_ops: list | None = None) -> None:
    sets = ["status=?", "result=?"]
    params: list = [status, result[:4000]]
    if summary is not None:
        sets.append("summary=?")
        params.append(summary)
    if undo_ops:
        sets.append("undo=?")
        params.append(db.dumps(undo_ops))
    params.append(action_id)
    db.run(f"UPDATE actions SET {','.join(sets)} WHERE id=?", params)


def get(action_id: int) -> dict | None:
    r = db.row("SELECT * FROM actions WHERE id=?", (action_id,))
    return _decorate(r) if r else None


def _decorate(r: dict) -> dict:
    r["args"] = db.loads(r.get("args"), {})
    r["can_undo"] = r["status"] == "done" and bool(db.loads(r.get("undo"), []))
    return r


def recent(limit: int = 30, status: str | None = None) -> list[dict]:
    if status:
        rows = db.rows("SELECT * FROM actions WHERE status=? ORDER BY id DESC LIMIT ?", (status, limit))
    else:
        rows = db.rows("SELECT * FROM actions ORDER BY id DESC LIMIT ?", (limit,))
    return [_decorate(r) for r in rows]


def pending() -> list[dict]:
    return [_decorate(r) for r in db.rows("SELECT * FROM actions WHERE status='pending' ORDER BY id")]


def for_turn(turn: str) -> list[dict]:
    return [_decorate(r) for r in db.rows("SELECT * FROM actions WHERE turn=? ORDER BY id", (turn,))]


def reject(action_id: int) -> None:
    a = get(action_id)
    if a and a["status"] == "pending":
        finish(action_id, "rejected", result="You declined this.")


def undo(action_id: int) -> str:
    """Reverse an action by replaying its journal backwards."""
    a = get(action_id)
    if not a:
        raise UserError("I can't find that action.")
    if a["status"] == "undone":
        raise UserError("That's already been undone.")
    ops = db.loads(a.get("undo"), [])
    if a["status"] != "done" or not ops:
        raise UserError("That one can't be undone.")
    db.rollback(ops)
    db.run("UPDATE actions SET status='undone' WHERE id=?", (action_id,))
    return a["summary"]


def undo_turn(turn: str) -> int:
    """Undo every undoable action from one conversation turn, newest first."""
    n = 0
    for a in reversed(for_turn(turn)):
        if a["can_undo"]:
            undo(a["id"])
            n += 1
    return n


def clear_old(keep: int = 500) -> None:
    db.run("DELETE FROM actions WHERE id NOT IN (SELECT id FROM actions ORDER BY id DESC LIMIT ?)", (keep,))
