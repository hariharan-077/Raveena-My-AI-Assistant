"""The thinking layer: Gemini when connected, Lite when not.

``GeminiBrain`` runs a streaming function-calling loop against the Google Gemini API (the free tier of
Google AI Studio is enough to run Raveena):

    you speak -> Gemini may call tools (add a task, plan the day, log water...) -> tool results
    go back to Gemini -> Gemini replies. Repeat until it has nothing left to do.

Notes:
* Automatic function calling is switched off: Raveena runs the tools herself so every action goes
  through the safeguards in ``tools.execute`` (approvals, action log, undo).
* The model's own reply (including any thought signatures) is handed back unchanged during a tool loop,
  which Gemini requires for reliable multi-step tool use.
* ``effort`` (Quick / Balanced / Thoughtful) maps to the model's thinking budget.
"""
from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass, field
from typing import Iterator

from . import config, insights, persona, settings, tools
from .lite import LiteBrain

log = logging.getLogger("raveena.brain")

MAX_ROUNDS = 8
MAX_TOKENS = 4096
_CLIENTS: dict = {}          # one API client per key, reused across messages

# thinking_budget (tokens) for Gemini 2.5 models; Gemini 3 models take a level instead.
_BUDGETS = {"low": 0, "medium": 1024, "high": 4096}
_FALLBACK_MODELS = ("gemini-flash-latest", "gemini-flash-lite-latest")
_BLOCKED = {"SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "RECITATION", "IMAGE_SAFETY"}


@dataclass
class Turn:
    """One message from you and everything that happened in response."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:10])
    actions: list[dict] = field(default_factory=list)    # receipts for the UI
    mode: str = "ai"                                      # ai | lite
    streamed: bool = False
    note: str | None = None


class BrainError(Exception):
    def __init__(self, user_message: str):
        super().__init__(user_message)
        self.user_message = user_message


def sdk_available() -> bool:
    try:
        from google import genai  # noqa: F401
        return True
    except ImportError:
        return False


def _fin(candidate) -> str:
    fr = getattr(candidate, "finish_reason", None)
    return (getattr(fr, "name", None) or str(fr or "")).split(".")[-1].upper()


class GeminiBrain:
    name = "gemini"

    def __init__(self, api_key: str | None = None, model: str | None = None, effort: str | None = None,
                 client=None):
        self.model = model or settings.get("model") or config.DEFAULT_MODEL
        self.effort = effort or settings.get("effort") or "medium"
        self._api_key = api_key
        self._client = client
        self._send_thinking = True

    @property
    def client(self):
        if self._client is None:
            key = self._api_key or config.api_key()
            if key not in _CLIENTS:
                from google import genai
                from google.genai import types
                _CLIENTS[key] = genai.Client(api_key=key, http_options=types.HttpOptions(
                    timeout=40_000,
                    retry_options=types.HttpRetryOptions(attempts=2, initial_delay=1.0, max_delay=4.0,
                                                         http_status_codes=[429, 500, 502, 503, 504])))
            self._client = _CLIENTS[key]
        return self._client

    # ------------------------------------------------------------------ requests
    def _thinking(self, model: str | None = None):
        from google.genai import types
        m = (model or self.model).lower()
        if re.search(r"gemini-3", m):
            return types.ThinkingConfig(thinking_level={"low": "low", "medium": "medium", "high": "high"}[self.effort]
                                        if self.effort in _BUDGETS else "medium")
        if "2.5" in m or "latest" in m:
            budget = _BUDGETS.get(self.effort, 1024)
            if "pro" in m:
                budget = max(budget, 128)          # 2.5 Pro can't switch thinking off
            return types.ThinkingConfig(thinking_budget=budget)
        return None

    def _config(self, system: str, with_tools: bool, max_tokens: int, model: str | None = None):
        from google.genai import types
        kw: dict = dict(system_instruction=system, max_output_tokens=max_tokens)
        if with_tools:
            decls = [types.FunctionDeclaration(name=t["name"], description=t["description"],
                                               parameters_json_schema=t["input_schema"])
                     for t in tools.schemas()]
            kw["tools"] = [types.Tool(function_declarations=decls)]
            kw["automatic_function_calling"] = types.AutomaticFunctionCallingConfig(disable=True)
        if self._send_thinking:
            th = self._thinking(model)
            if th is not None:
                kw["thinking_config"] = th
        return types.GenerateContentConfig(**kw)

    @staticmethod
    def _contents(history: list[dict]) -> list:
        from google.genai import types
        out = []
        for m in history:
            role = "model" if m.get("role") == "assistant" else "user"
            out.append(types.Content(role=role, parts=[types.Part(text=str(m.get("content", "")))]))
        return out

    def _stream_once(self, contents: list, cfg, model: str | None = None):
        """Stream one model call. Yields text; returns (all parts, finish reason, block reason)."""
        parts: list = []
        finish, block = "", ""
        for chunk in self.client.models.generate_content_stream(model=model or self.model, contents=contents, config=cfg):
            pf = getattr(chunk, "prompt_feedback", None)
            if pf is not None and getattr(pf, "block_reason", None):
                block = str(getattr(pf.block_reason, "name", pf.block_reason))
            for cand in (chunk.candidates or []):
                if _fin(cand):
                    finish = _fin(cand)
                for part in (getattr(cand.content, "parts", None) or []):
                    parts.append(part)
                    if part.text and not part.thought and not part.function_call:
                        yield part.text
        return parts, finish, block

    def _round(self, contents: list, system: str, with_tools: bool = True, max_tokens: int = MAX_TOKENS):
        """One streamed model call. Yields text; returns the result. Maps SDK errors to friendly ones."""
        from google.genai import errors
        try:
            try:
                return (yield from self._stream_once(contents, self._config(system, with_tools, max_tokens)))
            except errors.ClientError as e:
                if e.code == 400 and self._send_thinking and re.search(r"think", str(e), re.I):
                    log.warning("Model rejected the thinking setting; retrying without it.")
                    self._send_thinking = False
                    return (yield from self._stream_once(contents, self._config(system, with_tools, max_tokens)))
                if e.code == 404:                      # model retired or misspelled: try Google's "latest" aliases
                    for fb in _FALLBACK_MODELS:
                        if fb == self.model:
                            continue
                        try:
                            log.warning("Model %s not found; trying %s.", self.model, fb)
                            result = yield from self._stream_once(contents, self._config(system, with_tools, max_tokens, fb), fb)
                        except errors.ClientError as e2:
                            if e2.code == 404:
                                continue
                            raise
                        self.model = fb
                        try:
                            settings.set("model", fb)
                        except Exception:              # noqa: BLE001 - saving the choice is best-effort
                            pass
                        return result
                raise
        except errors.ClientError as e:
            code = e.code
            if code == 429:
                raise BrainError("I'm being rate limited right now (the free Gemini tier has per-minute and daily "
                                 "limits). Give me a moment.") from e
            if code in (401, 403) or re.search(r"API key", str(e), re.I):
                raise BrainError("Gemini refused my connection. Check the API key in Settings.") from e
            if code == 404:
                raise BrainError(f"I couldn't find the model \"{self.model}\". Pick another in Settings "
                                 "(try Gemini Flash (latest)).") from e
            raise BrainError("Gemini couldn't process that request. Check the model name in Settings.") from e
        except errors.ServerError as e:
            for fb in _FALLBACK_MODELS:            # busy servers: try the other Flash model once, quickly
                if fb == self.model:
                    continue
                try:
                    log.warning("Gemini busy (%s); trying %s.", e.code, fb)
                    return (yield from self._stream_once(contents, self._config(system, with_tools, max_tokens, fb), fb))
                except errors.APIError:
                    continue
            raise BrainError(f"Google's Gemini servers are busy right now (error {e.code}). I retried a few times; "
                             "try again in a minute, or pick Gemini Flash-Lite (latest) in Settings.") from e
        except errors.APIError as e:
            raise BrainError(f"Gemini is having trouble right now (error {getattr(e, 'code', '?')}).") from e
        except BrainError:
            raise
        except Exception as e:                                             # noqa: BLE001 - network etc.
            if type(e).__module__.split(".")[0] in ("httpx", "httpx2", "httpcore", "requests", "urllib3") \
                    or isinstance(e, (ConnectionError, TimeoutError, OSError)):
                raise BrainError("I couldn't reach Gemini. Are you online?") from e
            raise

    # ------------------------------------------------------------------ the conversation loop
    def reply(self, history: list[dict], turn: Turn) -> Iterator[str]:
        from google.genai import types
        user_text = history[-1]["content"] if history else ""
        contents = self._contents(history)
        system = persona.system_prompt() + "\n\n" + persona.snapshot(user_text)
        for _ in range(MAX_ROUNDS):
            gen = self._round(contents, system)
            first, result = True, None
            while True:
                try:
                    chunk = next(gen)
                except StopIteration as stop:
                    result = stop.value
                    break
                if first and turn.streamed:
                    yield "\n\n"                       # separate text before and after a tool call
                first = False
                turn.streamed = True
                yield chunk

            parts, finish, block = result
            calls = [p.function_call for p in parts if p.function_call]
            if block or (finish in _BLOCKED and not calls):
                yield "\n\nI'm not able to help with that one."
                return
            if not calls:
                if finish == "MAX_TOKENS":
                    yield " …"
                return

            contents.append(types.Content(role="model", parts=parts))     # unchanged, thought signatures included
            responses = []
            for fc in calls:
                out = tools.execute(fc.name, dict(fc.args or {}), source="chat", turn=turn.id)
                if not out.silent:
                    turn.actions.append(out.chip())
                payload = {"result": out.text} if out.ok else {"error": out.text}
                responses.append(types.Part.from_function_response(name=fc.name, response=payload))
            contents.append(types.Content(role="user", parts=responses))
        yield "\n\nI got a little tangled up there. Could you say that another way?"

    # ------------------------------------------------------------------ one-shot text (reviews, summaries)
    def complete(self, prompt: str, system: str | None = None, max_tokens: int = 1500) -> str:
        from google.genai import types
        contents = [types.Content(role="user", parts=[types.Part(text=prompt)])]
        gen = self._round(contents, system or persona.system_prompt(), with_tools=False, max_tokens=max_tokens)
        parts: list[str] = []
        while True:
            try:
                parts.append(next(gen))
            except StopIteration:
                break
        return "".join(parts).strip()


class SmartBrain:
    """Gemini if it's available; Lite if not, or if Gemini fails before doing anything."""

    def __init__(self, primary: GeminiBrain | None):
        self.primary = primary
        self.lite = LiteBrain()

    @property
    def mode(self) -> str:
        return "ai" if self.primary else "lite"

    def reply(self, history: list[dict], turn: Turn) -> Iterator[str]:
        if self.primary is None:
            turn.mode = "lite"
            yield from self.lite.reply(history, turn)
            return
        try:
            yield from self.primary.reply(history, turn)
        except BrainError as e:
            log.warning("AI failed: %s", e.user_message)
            if turn.actions or turn.streamed:
                yield f"\n\n*{e.user_message}*"
                return
            turn.note = e.user_message
            yield f"*{e.user_message} I'll handle this one in Lite mode.*\n\n"
            yield from self.lite.reply(history, turn)


def get_brain() -> SmartBrain:
    if settings.get("use_ai") and config.api_key() and sdk_available():
        return SmartBrain(GeminiBrain())
    return SmartBrain(None)


def status() -> dict:
    """What's powering Raveena right now, and why (for the UI)."""
    if not sdk_available():
        return dict(mode="lite", model=None, reason="The 'google-genai' package isn't installed.")
    if not config.api_key():
        return dict(mode="lite", model=None, reason="No API key yet.")
    if not settings.get("use_ai"):
        return dict(mode="lite", model=None, reason="AI is switched off in Settings.")
    return dict(mode="ai", model=settings.get("model") or config.DEFAULT_MODEL, reason="")


# --------------------------------------------------------------------------- weekly review
def rule_based_review() -> str:
    sug = insights.suggestions(14)
    parts = [insights.week_sentence(7)]
    wins = [s for s in sug if s.tone == "win"][:1]
    work = [s for s in sug if s.tone != "win"][:2]
    for s in wins + work:
        parts.append(f"{s.title}. {s.detail}")
    return "\n\n".join(parts)


def weekly_review() -> tuple[str, str]:
    """(text, mode). A short, warm review written by Gemini if connected, otherwise a rule-based one."""
    brain = get_brain()
    if brain.primary is not None:
        try:
            prompt = ("Write my weekly review from these facts. Maximum 170 words, plain prose, no headings or "
                      "bullet points. Open with something genuinely good that happened, name one pattern you "
                      "noticed that I might not have, and end with one specific, small change for next week. "
                      "Warm and honest; don't recite numbers one after another.\n\n" + insights.digest(14))
            text = brain.primary.complete(prompt, max_tokens=1200)
            if text:
                return text, "ai"
        except BrainError as e:
            log.warning("review fell back: %s", e.user_message)
    return rule_based_review(), "lite"
