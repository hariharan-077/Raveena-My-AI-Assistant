"""Personal memory: what Raveena knows about you, visible and editable by you.

Memories are short plain sentences ("Studies best in the morning"). They are ranked by
importance, recency and overlap with what you're talking about, and a compact selection is
given to the AI model on every turn, so you never have to repeat yourself.
"""
from __future__ import annotations

import re
from datetime import datetime

from . import clock, db
from .tasks import UserError

CATEGORIES = {
    "goal": "Goals and dreams",
    "preference": "Preferences",
    "routine": "Routines and habits",
    "person": "People",
    "health": "Wellbeing",
    "fact": "About me",
    "reflection": "Reflections",
    "win": "Wins",
}
_STOP = {"the", "and", "for", "that", "with", "this", "have", "has", "was", "are", "you", "your", "from",
         "about", "into", "when", "what", "how", "can", "will", "not", "but", "they", "them", "she", "his",
         "her", "its", "just", "very", "really", "like", "want", "need", "also", "than", "then", "too"}


def _tokens(s: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9']+", s.lower()) if len(w) > 2 and w not in _STOP}


def _similar(a: str, b: str) -> bool:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return a.strip().lower() == b.strip().lower()
    jacc = len(ta & tb) / len(ta | tb)
    contains = a.strip().lower() in b.strip().lower() or b.strip().lower() in a.strip().lower()
    return jacc >= 0.7 or (contains and min(len(ta), len(tb)) >= 2)


def remember(content: str, category: str = "fact", importance: int = 3,
             source: str = "user") -> tuple[dict, bool]:
    """Save a memory. If a near-duplicate exists it is refreshed instead. Returns (memory, created)."""
    content = re.sub(r"\s+", " ", (content or "")).strip()
    if len(content) < 3:
        raise UserError("What should I remember?")
    category = category if category in CATEGORIES else "fact"
    try:
        importance = min(5, max(1, int(importance)))
    except (TypeError, ValueError):
        importance = 3
    for m in db.rows("SELECT * FROM memories"):
        if _similar(m["content"], content):
            new_text = content if len(content) >= len(m["content"]) else m["content"]
            db.update("memories", m["id"], {"content": new_text[:400], "importance": max(importance, m["importance"]),
                                            "updated_at": db.stamp()})
            return db.get("memories", m["id"]), False  # type: ignore[return-value]
    now = db.stamp()
    mid = db.insert("memories", dict(category=category, content=content[:400], importance=importance,
                                     source=source, created_at=now, updated_at=now))
    return db.get("memories", mid), True  # type: ignore[return-value]


def get(memory_id: int) -> dict | None:
    return db.get("memories", memory_id)


def list_all(category: str | None = None) -> list[dict]:
    if category:
        return db.rows("SELECT * FROM memories WHERE category=? ORDER BY importance DESC, updated_at DESC", (category,))
    return db.rows("SELECT * FROM memories ORDER BY importance DESC, updated_at DESC")


def update(memory_id: int, **fields) -> dict:
    values = {}
    if "content" in fields:
        text = re.sub(r"\s+", " ", str(fields["content"])).strip()
        if len(text) < 3:
            raise UserError("A memory can't be empty. Delete it instead.")
        values["content"] = text[:400]
    if fields.get("category") in CATEGORIES:
        values["category"] = fields["category"]
    if "importance" in fields:
        values["importance"] = min(5, max(1, int(fields["importance"])))
    if values:
        values["updated_at"] = db.stamp()
        db.update("memories", memory_id, values)
    return db.get("memories", memory_id)  # type: ignore[return-value]


def forget(memory_id: int) -> bool:
    return db.delete("memories", memory_id)


def find(ref) -> dict:
    s = str(ref if ref is not None else "").strip()
    if re.fullmatch(r"#?\d+", s):
        m = get(int(s.lstrip("#")))
        if m:
            return m
        raise UserError(f"There's no memory with id {s}.")
    q = _tokens(s)
    scored = []
    for m in list_all():
        overlap = len(q & _tokens(m["content"])) / max(1, len(q)) if q else 0
        if s.lower() in m["content"].lower():
            overlap = 1.0
        scored.append((overlap, m))
    scored.sort(key=lambda x: -x[0])
    if scored and scored[0][0] >= 0.6 and (len(scored) == 1 or scored[0][0] > scored[1][0]):
        return scored[0][1]
    raise UserError(f"I couldn't tell which memory you mean by '{s}'. Use its id from the memory list.")


def search(query: str, limit: int = 10) -> list[dict]:
    q = _tokens(query)
    out = []
    for m in list_all():
        score = len(q & _tokens(m["content"])) + (2 if query.lower() in m["content"].lower() else 0)
        if score:
            out.append((score, m))
    out.sort(key=lambda x: (-x[0], -x[1]["importance"]))
    return [m for _, m in out[:limit]]


def relevant(query: str = "", limit: int = 18) -> list[dict]:
    """Pick the memories most worth showing the model right now."""
    q = _tokens(query)
    now = clock.now()
    scored = []
    for m in list_all():
        age_days = max(0.0, (now - datetime.fromisoformat(m["updated_at"])).total_seconds() / 86400)
        recency = max(0.0, 1 - age_days / 120) * 1.2
        overlap = (len(q & _tokens(m["content"])) / max(1, len(q))) * 4 if q else 0
        scored.append((m["importance"] + recency + overlap, m))
    scored.sort(key=lambda x: -x[0])
    chosen = [m for _, m in scored[:limit]]
    order = list(CATEGORIES)
    chosen.sort(key=lambda m: (order.index(m["category"]) if m["category"] in order else 99, -m["importance"]))
    return chosen


def mark_used(ids: list[int]) -> None:
    """Note that these memories were shown to the model (not journaled; it's bookkeeping)."""
    if ids:
        db.run(f"UPDATE memories SET last_used=? WHERE id IN ({','.join('?' * len(ids))})", (db.stamp(), *ids))
