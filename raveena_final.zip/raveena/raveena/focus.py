"""A simple focus timer. Real time spent is what teaches Raveena how long things take you."""
from __future__ import annotations

from datetime import datetime

from . import clock, db, planner, settings
from . import tasks as T
from .tasks import UserError


def active() -> dict | None:
    f = settings.get("focus")
    return f if f and f.get("task_id") else None


def start(task_id: int, block_id: int | None = None) -> dict:
    if active():
        raise UserError("A focus session is already running. Stop it first.")
    t = db.get("tasks", task_id)
    if not t or t["status"] in ("done", "dropped"):
        raise UserError("That task isn't open.")
    f = {"task_id": task_id, "block_id": block_id, "start": clock.iso()}
    settings.set("focus", f)
    if t["status"] == "todo":
        db.update("tasks", task_id, {"status": "doing"})
    return f


def elapsed_seconds(now: datetime | None = None) -> int:
    f = active()
    if not f:
        return 0
    return max(0, int(((now or clock.now()) - clock.parse_iso(f["start"])).total_seconds()))


def stop(complete: bool = False, now: datetime | None = None) -> dict:
    """Log the time. If it covered a planned session, that session is done (and the day re-plans if it ran over)."""
    f = active()
    if not f:
        raise UserError("There's no focus session running.")
    now = now or clock.now()
    started = clock.parse_iso(f["start"])
    mins = max(1, int(round((now - started).total_seconds() / 60)))
    task = db.get("tasks", f["task_id"])
    block = db.get("blocks", f["block_id"]) if f.get("block_id") else None
    if block is None or block["status"] != "planned":
        block = planner.block_for_task(f["task_id"], started.date())
    result: dict = {"minutes": mins, "task": task, "finished": complete, "replanned": None}
    with db.transaction():
        settings.set("focus", None)
        planned = (planner._m(block["end"]) - planner._m(block["start"])) if block else 0
        if block and block["status"] == "planned" and mins >= max(10, planned * 0.5):
            out = planner.complete_block(block["id"], mins, finished=complete or None, now=now)
            result.update(finished=out["finished"], replanned=out["replanned"])
        else:
            T.log_time(f["task_id"], mins, start=started.strftime("%H:%M"), on=started.date(), source="focus")
            if complete:
                T.complete_task(f["task_id"])
    result["task"] = db.get("tasks", f["task_id"])
    return result


def cancel() -> None:
    settings.set("focus", None)
