"""Raveena Lite: the offline brain.

No AI model and no internet. Plain pattern matching for the things people say most:
add a task, plan the day, log water, report a missed session, share how they feel.
It keeps the app fully usable without an API key, and it is the automatic fallback if the
connection to Gemini drops. It's honest about being simple (see ``FALLBACK``).
"""
from __future__ import annotations

import random
import re
import time
from datetime import timedelta
from typing import Callable, Iterator

from . import clock, conversation, fmt, insights, planner, settings, tools, trackers
from . import tasks as T
from . import timeparse as tp
from .tasks import UserError

YES = re.compile(r"^\s*(yes|yeah|yep|yup|sure|please|ok|okay|do it|go ahead|sounds good|that would help|pls|y)\b", re.I)
NO = re.compile(r"^\s*(no|nope|nah|not now|it'?s fine|i'?m fine|no thanks|n)\b", re.I)

CRISIS = re.compile(
    r"\b(kill myself|killing myself|end my life|ending my life|suicid\w*|want to die|wanna die|"
    r"don'?t want to (?:be here|live|exist)|hurt myself|harm myself|self[- ]harm|no reason to live|"
    r"better off without me|can'?t go on)\b", re.I)

CATEGORY_WORDS = {
    "Study": r"study|revise|revision|exam|assignment|homework|lecture|chapter|essay|lab|thesis|quiz|course|class|read|"
             r"problem set|notes|flashcards|syllabus",
    "Work": r"email|meeting|report|client|presentation|invoice|boss|project|proposal|slides|standup|review",
    "Health": r"gym|workout|run|yoga|doctor|dentist|meditat|walk|stretch|medicine|physio|therapy|checkup",
    "Personal": r"buy|call|clean|laundry|bills?|pay|cook|groceries|renew|birthday|gift|mom|dad|family|friend|visa|"
                r"passport|rent|book a",
    "Creative": r"write|draw|paint|music|guitar|piano|blog|design|photo|sketch|compose|edit video|poem",
}
EVENT_WORDS = (r"meeting|appointment|exam|interview|class|lecture|call|dentist|doctor|flight|dinner|lunch|party|"
               r"concert|session|haircut|seminar|viva|webinar|workshop")

EMOTIONS = [  # (key, pattern, mood, energy)
    ("overwhelmed", r"overwhelm\w*|too much|swamped|drowning|can'?t keep up|so much to do|buried|too many things", 2, 2),
    ("stressed", r"stress\w*|pressure|panick\w*|tense|on edge|freaking out", 2, 3),
    ("anxious", r"anxi\w+|nervous|worried|worry|scared|afraid|dread\w*", 2, 3),
    ("sad", r"\bsad\b|\bdown\b|\blow\b|unhappy|crying|cried|lonely|empty|heartbroken|miserable|depress\w*|hopeless|"
            r"awful|terrible|rough day|bad day", 2, 2),
    ("tired", r"tired|exhaust\w*|drained|sleepy|worn out|burn(?:t|ed) out|no energy|wiped|knackered", 2, 1),
    ("angry", r"angry|furious|annoyed|irritat\w*|frustrat\w*|mad at|fed up", 2, 3),
    ("stuck", r"stuck|unmotivated|procrastinat\w*|can'?t focus|can'?t concentrate|no motivation|lazy|can'?t start", 2, 2),
    ("great", r"great|amazing|fantastic|excited|thrilled|wonderful|awesome|best day|on top of the world", 5, 5),
    ("good", r"\bgood\b|happy|calm|relaxed|content|peaceful|better|proud|hopeful|grateful|motivated|productive", 4, 4),
    ("okay", r"\bokay\b|\bok\b|\bfine\b|\bmeh\b|so-?so|alright|not bad", 3, 3),
]
NEGATIVE = {"overwhelmed", "stressed", "anxious", "sad", "tired", "angry", "stuck"}
POSITIVE = {"great", "good", "okay"}

FEELING_REPLIES = {
    "overwhelmed": [
        "That's a lot to hold at once, and we don't have to solve all of it right now. Want me to go through today and cut it down to what really matters?",
        "Feeling swamped usually means the plate is too full, not that you're doing something wrong. Shall I lighten today and move whatever isn't urgent?",
        "Okay, let's make it smaller. If I take everything that isn't urgent off today, would that help?",
    ],
    "stressed": [
        "That sounds tense. What's the one thing pressing on you most right now? Stress makes everything feel equally urgent, and usually only one or two things really are.",
        "I'm sorry it's piling up. Tell me what's weighing on you most and we'll sort what's actually due soon from what's just loud. Or I can lighten today if you'd rather.",
    ],
    "anxious": [
        "Worry has a way of making everything feel urgent at once. Do you want to tell me what's on your mind? Saying the big thing out loud often shrinks it.",
        "That sounds uncomfortable. I'm here. What's the worry that keeps coming back?",
    ],
    "sad": [
        "I'm sorry today feels heavy. You don't have to explain it or fix it. Would you like to talk about what's behind it, or shall I quietly make today lighter?",
        "That sounds hard. I'm glad you told me. Do you want to talk it through, or would it help if I took some pressure off your day?",
    ],
    "tired": [
        "It sounds like you're running on empty, and that's worth listening to. Want me to go easy on today's plan?",
        "Being tired makes everything harder. Shall I lighten today so the important things fit and the rest can wait?",
    ],
    "angry": [
        "That sounds really frustrating. What happened?",
        "Ugh, I can hear how irritating that is. Do you want to vent, or would you rather I help you deal with whatever's causing it?",
    ],
    "stuck": [
        "Getting started is often the hardest part. Want me to pick one task and shrink it to a ten-minute first step?",
        "Being stuck isn't laziness; it usually means the first step is unclear. Shall I choose the smallest possible piece of something on your list?",
    ],
    "great": [
        "That's lovely to hear. What's been going so well? I'd like to remember what's working for you.",
        "Love that! Is there something behind it you'd like me to remember?",
    ],
    "good": [
        "Glad to hear it. Anything you'd like to make the most of today?",
        "That's good to hear. Let me know if there's something you want to get ahead on while the energy's there.",
    ],
    "okay": [
        "Okay is allowed. Is there anything you'd like to get done today, or is it a quiet one?",
        "Fair enough. I'm here if you want to plan something or just chat.",
    ],
}
OFFER_ON = {"overwhelmed": "lighten", "tired": "lighten", "sad": "lighten", "stressed": "lighten", "stuck": "tiny"}

FALLBACK = ("I didn't quite catch that. I'm in Lite mode right now (no AI connection), so I understand simple "
            "things like “add a task…”, “plan my day”, “what's next”, “drank 2 glasses of water”, “done with "
            "<task>”, or just telling me how you feel. Connect Gemini in Settings for natural conversation.")

HELP = ("Here's what I can do in Lite mode:\n\n"
        "- **Tasks:** “add lab report by Friday 2h”, “done with lab report”, “delete old task”\n"
        "- **Plan:** “plan my day”, “plan the week”, “what's next?”, “I missed the physics session”\n"
        "- **Track:** “drank 2 glasses of water”, “studied 45 minutes”, “slept 7 hours”, “meditated”\n"
        "- **Calendar:** “gym every Mon Wed Fri 6-7pm”, “dentist on 20 Oct 3pm”\n"
        "- **Remember:** “remember that I study best at night”\n"
        "- **Talk:** tell me how you're feeling and I'll listen.\n\n"
        "Connect Gemini in Settings and I can do all of this in natural conversation.")


# --------------------------------------------------------------------------- context
class Ctx:
    def __init__(self, turn):
        self.turn = turn
        self.name = settings.display_name()
        self.now = clock.now()

    def call(self, name: str, **args) -> tools.Outcome:
        out = tools.execute(name, args, source="chat", turn=self.turn.id)
        if not out.silent:
            self.turn.actions.append(out.chip())
        return out


def _set_offer(kind: str | None) -> None:
    settings.set("lite_offer", {"kind": kind, "ts": clock.iso()} if kind else None)


def _get_offer() -> str | None:
    o = settings.get("lite_offer")
    if not o or not o.get("kind"):
        return None
    if (clock.now() - clock.parse_iso(o["ts"])) > timedelta(minutes=30):
        return None
    return o["kind"]


# --------------------------------------------------------------------------- text helpers
def _strip_leading(s: str) -> str:
    s = re.sub(r"^\s*(?:to|that|about|my|the|a|an)\s+", "", s.strip(), flags=re.I)
    return s.strip(" .,!?;:")


def _title_case_first(s: str) -> str:
    s = s.strip(" .,!?;:-")
    return s[:1].upper() + s[1:] if s else s


def guess_category(title: str) -> str:
    low = title.lower()
    for cat, pattern in CATEGORY_WORDS.items():
        if re.search(rf"\b(?:{pattern})", low):
            return cat
    return "General"


def parse_task_text(text: str) -> dict:
    """'write lab report by friday for 2 hours, high priority' -> structured task fields."""
    rest = text.strip()
    prio, rest = tp.extract_priority(rest)
    dur, rest = tp.extract_duration(rest)
    due, rest = tp.extract_date(rest)
    due_time, rest = tp.extract_time(rest)
    rest = re.sub(r"\b(?:by|before|until|due|on|at|for|in|this|next)\s*$", "", rest.strip(), flags=re.I)
    rest = re.sub(r"\s*,\s*$", "", rest)
    title = _title_case_first(_strip_leading(rest))
    return dict(title=title, due_date=due.isoformat() if due else None, due_time=due_time,
                est_minutes=dur, priority=prio, category=guess_category(title))


def _strip_days_phrase(text: str) -> str:
    wd = "|".join(sorted(tp.WEEKDAYS, key=len, reverse=True))
    text = re.sub(rf"\b(?:every|each|on)?\s*(?:{wd})s?\b(?:\s*(?:,|and|&|-|to)\s*(?:{wd})s?\b)*", " ", text, flags=re.I)
    text = re.sub(r"\b(?:every ?day|daily|weekdays?|weekends?|each day|every|weekly|routine)\b", " ", text, flags=re.I)
    return re.sub(r"\s+", " ", text).strip(" ,.-")


def _find_task_or_ask(phrase: str) -> dict:
    return T.find_task(re.sub(r"^(?:the|my|a|an)\s+", "", phrase.strip(" .,!?"), flags=re.I))


def _task_phrase_or_current(phrase: str, ctx: Ctx) -> dict:
    phrase = phrase.strip(" .,!?")
    if phrase:
        return _find_task_or_ask(phrase)
    cur, _ = planner.current_and_next(ctx.now)
    if cur:
        return T.get_task(cur["task_id"])  # type: ignore[return-value]
    checks = planner.pending_checkins(ctx.now)
    if checks:
        return T.get_task(checks[-1]["task_id"])  # type: ignore[return-value]
    raise UserError("Which task do you mean?")


# --------------------------------------------------------------------------- intents
# each returns a string reply, or None if the message isn't theirs

def _crisis(text: str, ctx: Ctx) -> str | None:
    if not CRISIS.search(text):
        return None
    contact = (settings.get("crisis_contact") or "").strip()
    who = f" You could start with {contact}." if contact else ""
    return ("I'm really glad you told me, and I'm taking it seriously. If you might act on these thoughts or you're "
            "in danger, please contact your local emergency number or a crisis line right now. If you can, tell "
            f"someone you trust how you're feeling so you're not alone with it.{who}\n\n"
            "We can put every plan and task aside. I'm here with you. Can you tell me what's happening right now?")


def _offer_reply(text: str, ctx: Ctx) -> str | None:
    offer = _get_offer()
    if not offer:
        return None
    _set_offer(None)
    if YES.match(text):
        if offer == "lighten":
            out = ctx.call("plan_schedule", scope="today", gentle=True)
            if not out.ok:
                return out.text
            return ("Done. I've made today lighter and kept what matters most. Here's what's left:\n\n"
                    + _agenda_text(ctx.now.date(), ctx.now, upcoming_only=True) + _risk_text(ctx.now, 2))
        if offer == "tiny":
            top = (T.list_tasks(status=["todo", "doing"], limit=1) or [None])[0]
            if not top:
                return "You've got nothing open right now, which is a nice problem. Want to add something?"
            return (f"Let's try: just ten minutes on “{top['title']}”, only the very first step. "
                    "You can stop after that if you want. Tell me how it goes.")
    if NO.match(text):
        return "Okay. I'm here if you want to talk it through."
    return None


def _undo(text: str, ctx: Ctx) -> str | None:
    if not re.match(r"^\s*(undo|undo that|take that back|revert( that)?)\s*[.!]*\s*$", text, re.I):
        return None
    turn = conversation.last_assistant_turn()
    n = actions_undo(turn) if turn else 0
    return "Undone." if n else "There's nothing from my last reply that I can undo."


def actions_undo(turn: str) -> int:
    from . import actions
    return actions.undo_turn(turn)


def _greeting(text: str, ctx: Ctx) -> str | None:
    if not re.match(r"^\s*(hi|hello|hey|hiya|yo|namaste|hola|good (morning|afternoon|evening|night))\b[\s!.,]*(raveena)?[\s!.]*$", text, re.I):
        return None
    cur, nxt = planner.current_and_next(ctx.now)
    parts = [f"{fmt.greeting(ctx.now.hour)}, {ctx.name}."]
    sm = planner.day_summary(ctx.now.date())
    if cur:
        parts.append(f"You're due to be on “{cur['title']}” until {fmt.time(cur['end'])}.")
    elif nxt:
        parts.append(f"Next up is “{nxt['title']}” at {fmt.time(nxt['start'])}.")
    elif not sm["blocks"] and T.list_tasks(status=["todo", "doing"], limit=1):
        parts.append("Nothing's scheduled yet. Say “plan my day” and I'll fit things in.")
    parts.append("How are you doing?")
    return " ".join(parts)


def _thanks(text: str, ctx: Ctx) -> str | None:
    if re.match(r"^\s*(thanks|thank you|thx|ty|cheers|thank u)\b", text, re.I):
        return random.choice(["Anytime.", "Of course.", "Happy to help."])
    return None


def _help(text: str, ctx: Ctx) -> str | None:
    if len(text.split()) <= 8 and re.search(r"\b(help|what can you do|how do you work|commands|what do you do)\b", text, re.I):
        return HELP
    return None


def _line(i: dict) -> str:
    when = f"{fmt.time(i['start'])} to {fmt.time(i['end'])}"
    if i["kind"] == "task":
        tag = {"done": " (done)", "missed": " (missed)", "skipped": " (skipped)"}.get(i["status"], "")
        return f"- {when}: {i['title']}{tag}"
    return f"- {when}: {i['title']} *({i['kind']})*"


def _agenda_text(d, now, *, upcoming_only: bool = False) -> str:
    items = planner.agenda(d)
    if upcoming_only and d == now.date():
        items = [i for i in items if i["kind"] == "task" and i["status"] == "planned"
                 and planner._at(d.isoformat(), i["end"]) > now]
    return "\n".join(_line(i) for i in items) or "- Nothing planned."


def _week_text(now) -> str:
    rows = []
    for k in range(7):
        d = now.date() + timedelta(days=k)
        sm = planner.day_summary(d)
        if sm["blocks"]:
            rows.append(f"- **{fmt.day(d)}**: {fmt.plural(sm['blocks'], 'session')}, {fmt.duration(sm['planned'])}")
    return "\n".join(rows) or "- Nothing planned."


def _risk_text(now, days: int = 3) -> str:
    risky = planner.deadline_watch(now, days=days)[:3]
    return "".join(f"\n\nHeads up: “{r['task']['title']}” is {fmt.due(r['task']['due_date']).lower()} and still needs about "
                   f"{fmt.duration(r['short'])} that I can't fit yet." for r in risky)


def _plan(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*(?:(?:can|could) you |please |let'?s |lets |i need you to |go ahead and )*"
                 r"(re-?plan|plan|re-?schedule|rearrange|organi[sz]e|sort out)\b(.*)$", text, re.I)
    if not m:
        return None
    rest = m.group(2).lower()
    if rest.strip(" .!?") and not re.search(r"\b(my|the|this|today|tomorrow|week|day|afternoon|evening|rest|everything)\b", rest):
        return None
    if "week" in rest:
        scope = "week"
    elif "tomorrow" in rest:
        scope = "tomorrow"
    else:
        scope = "today"
    gentle = bool(re.search(r"\b(light|easy|gentle|relax|slow|low energy|tired|chill)\b", text, re.I))
    out = ctx.call("plan_schedule", scope=scope, gentle=gentle)
    if not out.ok:
        return out.text
    if scope == "week":
        body = "Here's the week ahead:\n\n" + _week_text(ctx.now)
    else:
        d = ctx.now.date() + timedelta(days=1 if scope == "tomorrow" else 0)
        body = (f"Here's {'tomorrow' if scope == 'tomorrow' else 'the rest of today'}:\n\n"
                + _agenda_text(d, ctx.now, upcoming_only=scope == "today"))
    return body + _risk_text(ctx.now, 7 if scope == "week" else 3)


def _show_schedule(text: str, ctx: Ctx) -> str | None:
    low = text.lower()
    if re.search(r"\b(what'?s|what is|what do i have|show|view|tell me|see|check)\b.*\b(schedule|agenda|plan|timetable|calendar|day)\b", low) \
            or re.match(r"^\s*(what'?s next|what next|what should i do( now| next)?|up next|what now)\s*\??\s*$", low) \
            or re.match(r"^\s*(my )?(schedule|agenda|plan)\s*\??\s*$", low):
        d = tp.parse_date(low) or ctx.now.date()
        body = f"**{fmt.long_date(d)}**\n\n" + _agenda_text(d, ctx.now)
        if d == ctx.now.date():
            cur, nxt = planner.current_and_next(ctx.now)
            head = (f"Right now: “{cur['title']}” until {fmt.time(cur['end'])}." if cur else
                    f"Next up: “{nxt['title']}” at {fmt.time(nxt['start'])}." if nxt else "Nothing else is planned today.")
            return f"{head}\n\n{body}"
        return body
    return None


def _list_tasks(text: str, ctx: Ctx) -> str | None:
    if re.search(r"\b(what'?s due|what do i (have|need) to do|my (tasks|to-?dos?|todo list|to do list)|show (me )?(my )?tasks|list (my )?tasks|open tasks)\b", text, re.I):
        out = ctx.call("list_tasks", status="open", limit=12)
        return "Here's what's open:\n\n" + out.text if out.text != "No matching tasks." else "You've got nothing open. Enjoy it, or add something."
    return None


def _after_replan(out, ctx: Ctx) -> str:
    if "re-planned" not in out.text:
        return ""
    return "\n\nI've adjusted the rest of today to fit:\n\n" + _agenda_text(ctx.now.date(), ctx.now, upcoming_only=True)


def _complete(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*(?:i\s+)?(?:just\s+|have\s+)?(?:finished|completed|done with|done|did|wrapped up|nailed|handled|sorted|finished off)\b[\s:,-]*(.*)$", text, re.I) \
        or re.match(r"^\s*mark\s+(.+?)\s+(?:as\s+)?(?:done|complete|completed|finished)\s*[.!]*$", text, re.I)
    if not m:
        return None
    phrase = m.group(1)
    minutes, phrase = tp.extract_duration(re.sub(r"\b(took|taking|in|after|spent)\b", " ", phrase, flags=re.I))
    try:
        t = _task_phrase_or_current(re.sub(r"\b(today|just now|already)\b", "", phrase, flags=re.I), ctx)
    except UserError as e:
        return str(e)
    out = ctx.call("report_session", task=str(t["id"]), outcome="done", actual_minutes=minutes)
    if not out.ok:
        return out.text
    first = out.text.split("\n")[0]
    return f"Nice work. {first}" + _after_replan(out, ctx)


def _took(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*(.+?)\s+(?:took|ran)\s+(?:me\s+)?(?:about\s+|around\s+)?(.+?)\s*[.!]*$", text, re.I)
    if not m:
        return None
    minutes = tp.parse_duration(m.group(2))
    if not minutes:
        return None
    try:
        t = _find_task_or_ask(re.sub(r"^(?:the|my)\s+", "", m.group(1), flags=re.I))
    except UserError:
        return None
    out = ctx.call("report_session", task=str(t["id"]), outcome="done", actual_minutes=minutes)
    if not out.ok:
        return out.text
    return "Got it, thanks for telling me. " + out.text.split("\n")[0] + _after_replan(out, ctx)


def _missed(text: str, ctx: Ctx) -> str | None:
    m = re.search(r"\b(missed|skipped|skip|couldn'?t (?:do|get to|finish|make it to)|didn'?t (?:get to|do|finish|manage)|"
                  r"ran out of time (?:for|on)|never got to|fell behind on|blew off)\b\s*(.*)$", text, re.I)
    if not m or re.search(r"\b(feel|feeling)\b", text, re.I):
        return None
    outcome = "skipped" if m.group(1).lower().startswith("skip") else "missed"
    try:
        t = _task_phrase_or_current(re.sub(r"\b(today|this morning|this afternoon|yesterday)\b", "", m.group(2), flags=re.I), ctx)
    except UserError as e:
        return str(e)
    out = ctx.call("report_session", task=str(t["id"]), outcome=outcome)
    if not out.ok:
        return out.text
    return ("That's okay, it happens. I've moved it and rebuilt the rest of your day. Here's what's left today:\n\n"
            + _agenda_text(ctx.now.date(), ctx.now, upcoming_only=True) + _risk_text(ctx.now, 2))


def _num(s: str) -> float:
    words = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "half": 0.5}
    return float(words.get(s.lower(), s) if not s.replace(".", "").isdigit() else s)


def _log_tracker(text: str, ctx: Ctx) -> str | None:
    low = text.lower()
    water = re.search(r"\b(?:drank|had|drink|downed|finished|log(?:ged)?|add(?:ed)?|\+)\s*(?P<n>\d+(?:\.\d+)?|a|an|one|two|three|four|five|six|half)?\s*"
                      r"(?P<unit>glass(?:es)?|cups?|bottles?|ml|litres?|liters?|l)\b(?:\s+of)?(?:\s+water)?", low)
    if water or re.search(r"\b(drank|had|log(?:ged)?|drink)\b.*\bwater\b", low):
        n, unit = (water.group("n"), water.group("unit")) if water else (None, "glass")
        amount = _num(n) if n else 1.0
        per = {"glass": 250, "cup": 250, "bottle": 500, "ml": 1, "l": 1000, "litre": 1000, "liter": 1000}
        key = next((k for k in per if unit.startswith(k)), "glass") if unit else "glass"
        ml = amount * per[key]
        out = ctx.call("log_activity", tracker="water", value=ml)
        return out.text if out.ok else out.text
    m = re.search(r"\bslept\b.*?(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hours?)\b|\bsleep\b.*?(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hours?)\b", low)
    if m:
        hours = float(m.group(1) or m.group(2))
        out = ctx.call("log_activity", tracker="sleep", value=hours)
        return out.text
    if re.search(r"\b(meditat\w*|mindful\w*)\b", low) and not re.search(r"\b(should|need to|remind|tomorrow|want to)\b", low):
        mins = tp.parse_duration(low)
        out = ctx.call("log_activity", tracker="meditate")
        return out.text + (f" ({fmt.duration(mins)}, nicely done.)" if mins else "")
    study = re.search(r"\b(studied|studying|revised|revising|learnt|learned|did homework)\b", low)
    exercise = re.search(r"\b(worked out|exercised|jogged|ran|walked|swam|cycled|lifted|did yoga|trained|went to the gym|went for a (?:run|walk|swim))\b", low)
    if study or exercise:
        mins = tp.parse_duration(low)
        name = "study" if study else "exercise"
        if not mins:
            return f"Nice. How long was it? Tell me the minutes and I'll log it to {name}."
        out = ctx.call("log_activity", tracker=name, value=mins)
        return out.text
    for t in trackers.list_trackers():                    # custom trackers by name
        if t["name"].lower() in ("water", "study", "exercise", "sleep", "meditate"):
            continue
        if re.search(rf"\b{re.escape(t['name'].lower())}\b", low):
            nm = re.search(r"(\d+(?:\.\d+)?)", low)
            if nm or t["kind"] == "check":
                out = ctx.call("log_activity", tracker=t["name"], value=float(nm.group(1)) if nm else None)
                return out.text
    return None


def _remember(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*(?:please\s+)?(?:remember|note|keep in mind)(?:\s+that)?\s+(?!to\b)(.+)$", text, re.I)
    if not m:
        return None
    raw = m.group(1).strip(" .")
    name = ctx.name if ctx.name != "there" else "The user"
    content = re.sub(r"^(?:i am|i'm)\s+", f"{name} is ", raw, flags=re.I)
    content = re.sub(r"^i\s+", f"{name} ", content, flags=re.I)
    content = re.sub(r"\bmy\b", f"{name}'s", content, flags=re.I)
    low = raw.lower()
    cat = ("preference" if re.search(r"prefer|like|love|hate|favou?rite|best at|enjoy", low) else
           "goal" if re.search(r"goal|dream|want to become|aim", low) else
           "routine" if re.search(r"every|usually|routine|always|each", low) else
           "person" if re.search(r"\bmy (mom|dad|mother|father|sister|brother|friend|boss|partner|wife|husband|roommate)\b", low) else
           "health" if re.search(r"allerg|medic|anxiety|sleep|health|diet|injur", low) else "fact")
    out = ctx.call("remember", content=content[:300], category=cat, importance=3, explicit=True)
    return "Got it, I'll remember that." if out.ok else out.text


def _forget(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*forget(?:\s+about|\s+that)?\s+(.+)$", text, re.I)
    if not m:
        return None
    out = ctx.call("forget", memory=m.group(1).strip(" ."))
    if out.status == "pending":
        return "I can do that. Please confirm below and I'll forget it."
    return out.text


def _delete(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*(?:delete|remove|get rid of)\s+(?:the\s+)?(?:task\s+)?(.+)$", text, re.I)
    if not m:
        return None
    try:
        t = T.find_task(m.group(1).strip(" ."), statuses=None)
    except UserError as e:
        return str(e)
    out = ctx.call("delete_task", task=str(t["id"]))
    return "Deleting is permanent, so I need your OK. Please confirm below." if out.status == "pending" else out.text


def _insights(text: str, ctx: Ctx) -> str | None:
    if not re.search(r"\b(how am i doing|how'?s my week|my progress|insights?|weekly review|week in review|how did i do)\b", text, re.I):
        return None
    sug = insights.suggestions()
    lines = [insights.week_sentence()]
    for s in sug[:3]:
        lines.append(f"**{s.title}.** {s.detail}")
    return "\n\n".join(lines)


def _goal(text: str, ctx: Ctx) -> str | None:
    m = re.match(r"^\s*(?:my\s+)?(?:new\s+)?goal(?:\s+is)?(?:\s+to)?\s*[:\-]?\s+(.+)$", text, re.I)
    if not m:
        return None
    due, rest = tp.extract_date(m.group(1))
    title = _title_case_first(_strip_leading(rest))
    out = ctx.call("create_goal", title=title, target_date=due.isoformat() if due else None,
                   category=guess_category(title))
    if not out.ok:
        return out.text
    return f"Lovely, that's a goal now. Want to break “{title}” into steps? Tell me the first one and I'll add it as a task."


def _routine(text: str, ctx: Ctx) -> str | None:
    days = tp.parse_days(text)
    rng, rest = tp.extract_time_range(text)
    if not days or not rng:
        return None
    if not re.search(r"\b(every|each|routine|weekly|daily|weekdays?|weekends?)\b|(?:mon|tues|wednes|thurs|fri|satur|sun)days\b", text, re.I):
        return None
    title = _title_case_first(_strip_leading(_strip_days_phrase(rest))) or "Routine"
    out = ctx.call("add_routine", title=title, days=days, start_time=rng[0], end_time=rng[1])
    if not out.ok:
        return out.text
    return out.text.split(" Re-plan")[0] + " Say “plan my day” and I'll work around it."


def _event(text: str, ctx: Ctx) -> str | None:
    rng, rest = tp.extract_time_range(text)
    due, rest2 = tp.extract_date(rest if rng else text)
    t, rest3 = tp.extract_time(rest2) if not rng else (None, rest2)
    has_event_word = bool(re.search(rf"\b(?:{EVENT_WORDS})\b", text, re.I))
    if not due or not (rng or (t and has_event_word)):
        return None
    start, end = rng if rng else (t, clock.min_to_hm(min(23 * 60 + 59, clock.hm_to_min(t) + 60)))
    title = _title_case_first(_strip_leading(re.sub(r"^\s*(?:add|schedule|book|put|set up)\s+(?:an?\s+)?(?:event\s+)?", "", rest3, flags=re.I)))
    out = ctx.call("add_event", title=title or "Event", date=due.isoformat(), start_time=start, end_time=end)
    if not out.ok:
        return out.text
    return out.text.split(" Re-plan")[0] + " I'll plan around it."


_ADD = re.compile(r"^\s*(?:(?:please|can you|could you)\s+)?(?:add|create|new|make)\s+(?:a\s+|an\s+|new\s+)?(?:task|todo|to-?do|reminder)?\s*(?:to|for|called|:)?\s*[:\-]?\s*(.+)$", re.I)
_REMIND = re.compile(r"^\s*(?:please\s+)?(?:remind me to|don'?t (?:let me )?forget to|remember to)\s+(.+)$", re.I)
_TODO = re.compile(r"^\s*(?:todo|task|to-?do)\s*[:\-]\s*(.+)$", re.I)
_IMPLICIT = re.compile(r"^\s*(?:i|we)\s+(?:really\s+)?(?:need to|have to|must|should|gotta|got to|ought to|want to)\s+(.+)$", re.I)


def _make_task(raw: str, ctx: Ctx, lead: str = "Added") -> str:
    spec = parse_task_text(raw)
    if not spec["title"]:
        return "What should the task be called?"
    out = ctx.call("add_task", **{k: v for k, v in spec.items() if v is not None})
    if not out.ok:
        return out.text
    bits = []
    if spec["due_date"]:
        bits.append(f"due {fmt.day_phrase(spec['due_date'])}")
    if spec["est_minutes"]:
        bits.append(f"about {fmt.duration(spec['est_minutes'])}")
    msg = f"{lead} “{spec['title']}”" + (f" ({', '.join(bits)})" if bits else "") + "."
    if "already" in out.text.lower():
        msg = f"“{spec['title']}” is already on your list."
    return msg + " Say “plan my day” when you want me to fit it in."


def _add_task(text: str, ctx: Ctx) -> str | None:
    for rx in (_ADD, _REMIND, _TODO):
        m = rx.match(text)
        if m:
            return _make_task(m.group(1), ctx)
    return None


def _add_task_implicit(text: str, ctx: Ctx) -> str | None:
    m = _IMPLICIT.match(text)
    if m and not re.search(r"\b(rest|sleep|cry|scream|quit|give up|disappear)\b", m.group(1), re.I):
        return _make_task(m.group(1), ctx, lead="Noted. Added")
    return None


def detect_feeling(text: str) -> tuple[str, int, int, bool] | None:
    low = text.lower()
    if low.rstrip().endswith("?") and not re.search(r"\bi\b", low):
        return None
    if not re.search(r"\b(i|i'm|im|i am|i've|ive|feeling|feel|felt|today|been|so|really|very|kinda|bit|my day)\b", low):
        return None
    for key, pattern, mood, energy in EMOTIONS:
        m = re.search(pattern, low)
        if not m:
            continue
        negated = bool(re.search(r"\b(?:not|never|no longer|hardly|isn'?t|aren'?t|don'?t feel|didn'?t feel)\s+(?:\w+\s+){0,2}" + re.escape(m.group(0)), low)) \
            or bool(re.search(r"\bn'?t\s+(?:\w+\s+){0,2}" + re.escape(m.group(0)), low))
        if negated:
            if key in POSITIVE:
                return "sad", 2, 2, True
            if key in NEGATIVE:
                return "okay", 3, 3, True
        return key, mood, energy, False
    return None


def _feelings(text: str, ctx: Ctx) -> str | None:
    f = detect_feeling(text)
    if not f:
        return None
    key, mood, energy, _ = f
    note = ""
    if settings.get("auto_mood"):
        ctx.call("log_mood", mood=mood, energy=energy, note=text[:140], tags=[key])
        note = "\n\n*I've noted how you're feeling so I can keep your plans realistic.*"
    reply = random.choice(FEELING_REPLIES[key])
    _set_offer(OFFER_ON.get(key))
    return reply + note


def _fallback_task(text: str, ctx: Ctx) -> str | None:
    """A short phrase with a date or duration in it is most likely a quick-capture task."""
    if len(text.split()) > 12 or text.rstrip().endswith("?"):
        return None
    due, _ = tp.extract_date(text)
    dur, _ = tp.extract_duration(text)
    if due or dur:
        return _make_task(text, ctx, lead="I took that as a task. Added")
    return None


INTENTS: list[Callable[[str, Ctx], str | None]] = [
    _crisis, _offer_reply, _undo, _greeting, _thanks, _help, _plan, _complete, _missed, _took,
    _log_tracker, _remember, _forget, _delete, _insights, _goal, _routine, _event, _add_task,
    _feelings, _add_task_implicit, _show_schedule, _list_tasks, _fallback_task,
]


def respond(text: str, turn) -> str:
    ctx = Ctx(turn)
    text = text.strip()
    for intent in INTENTS:
        try:
            reply = intent(text, ctx)
        except UserError as e:
            return str(e)
        if reply is not None:
            return reply
    return FALLBACK


def stream_words(text: str, delay: float = 0.012) -> Iterator[str]:
    for chunk in re.findall(r"\S+\s*|\n+", text):
        yield chunk
        time.sleep(delay)


class LiteBrain:
    name = "lite"

    def reply(self, history: list[dict], turn) -> Iterator[str]:
        text = history[-1]["content"] if history else ""
        turn.mode = "lite"
        yield from stream_words(respond(text, turn))
