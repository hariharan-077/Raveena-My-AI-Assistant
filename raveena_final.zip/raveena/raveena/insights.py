"""Turning your history into advice.

Raveena doesn't just show charts. Each finding becomes a *suggestion* with a plain reason and,
where it makes sense, a one-click action (change a setting, add a routine, start a conversation).
Nothing here is guessed from too little data: every rule states how much evidence it needs.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, timedelta

from . import clock, db, fmt, mood, planner, settings, trackers
from . import tasks as T


@dataclass
class Suggestion:
    key: str
    title: str
    detail: str
    tone: str = "tip"                 # tip | heads-up | win
    action: dict | None = None        # {"type": "settings"|"routine"|"chat"|"tracker_target", "label": str, ...}


def _fmt_h(h: int) -> str:
    return fmt.time(f"{h % 24:02d}:00")


# --------------------------------------------------------------------------- raw numbers
def stats(days: int = 14, end: date | None = None) -> dict:
    end = end or clock.today()
    start = end - timedelta(days=days - 1)
    s, e = start.isoformat(), end.isoformat()

    blocks = db.rows("SELECT b.*, t.category FROM blocks b JOIN tasks t ON t.id=b.task_id WHERE b.date>=? AND b.date<=?",
                     (s, e))
    done = [b for b in blocks if b["status"] == "done"]
    missed = [b for b in blocks if b["status"] == "missed"]
    ended = len(done) + len(missed)

    def part(b: dict) -> str:
        h = int(b["start"][:2])
        return "morning" if h < 12 else "afternoon" if h < 17 else "evening"

    parts: dict[str, dict[str, int]] = {p: {"done": 0, "ended": 0} for p in ("morning", "afternoon", "evening")}
    for b in done + missed:
        parts[part(b)]["ended"] += 1
        parts[part(b)]["done"] += int(b["status"] == "done")

    logs = db.rows("SELECT l.*, t.category FROM time_logs l JOIN tasks t ON t.id=l.task_id WHERE l.date>=? AND l.date<=?",
                   (s, e))
    focus_by_day: dict[str, int] = defaultdict(int)
    by_weekday: dict[int, list[int]] = defaultdict(list)
    by_category: dict[str, int] = defaultdict(int)
    for lg in logs:
        focus_by_day[lg["date"]] += lg["minutes"]
        by_category[lg["category"]] += lg["minutes"]
    for i in range(days):
        d = start + timedelta(days=i)
        by_weekday[d.weekday()].append(focus_by_day.get(d.isoformat(), 0))

    completed = db.rows("SELECT * FROM tasks WHERE status='done' AND completed_at>=? AND completed_at<?",
                        (s, (end + timedelta(days=1)).isoformat()))
    today = clock.today().isoformat()
    open_tasks = T.list_tasks(status=["todo", "doing"])
    overdue = [t for t in open_tasks if t["due_date"] and t["due_date"] < today]
    stuck = [t for t in open_tasks if (t["postponed"] or 0) >= 3]
    old = [t for t in open_tasks if not t["due_date"] and t["created_at"][:10] <= (end - timedelta(days=21)).isoformat()]

    return dict(start=start, end=end, days=days, blocks_done=len(done), blocks_missed=len(missed), ended=ended,
                adherence=(len(done) / ended) if ended else None, parts=parts,
                focus_minutes=sum(focus_by_day.values()), focus_days=len(focus_by_day),
                focus_by_day=dict(focus_by_day), by_weekday={k: sum(v) / max(1, len(v)) for k, v in by_weekday.items()},
                by_category=dict(by_category), tasks_completed=len(completed), open=len(open_tasks),
                overdue=overdue, stuck=stuck, old=old, logs=logs, mood=mood.summary(min(days, 14)))


def hourly_focus(days: int = 28) -> list[float]:
    """Minutes of logged work in each hour of the day, over the last N days."""
    start = (clock.today() - timedelta(days=days - 1)).isoformat()
    hist = [0.0] * 24
    for lg in db.rows("SELECT start, minutes FROM time_logs WHERE date>=? AND start IS NOT NULL", (start,)):
        s = clock.hm_to_min(lg["start"])
        left = lg["minutes"]
        t = s
        while left > 0 and t < 24 * 60:
            h = t // 60
            chunk = min(left, (h + 1) * 60 - t)
            hist[h] += chunk
            left -= chunk
            t += chunk
    return hist


def learned_peak(days: int = 28) -> tuple[int, int, float] | None:
    """Best three-hour window for focused work, if there's enough evidence: (start_h, end_h, share)."""
    hist = hourly_focus(days)
    total = sum(hist)
    distinct = db.scalar("SELECT COUNT(DISTINCT date) FROM time_logs WHERE date>=?",
                         ((clock.today() - timedelta(days=days - 1)).isoformat(),), 0)
    if total < 300 or distinct < 5:
        return None
    best = max(range(0, 22), key=lambda h: sum(hist[h:h + 3]))
    share = sum(hist[best:best + 3]) / total
    return (best, best + 3, share) if share >= 0.35 else None


def pace() -> dict[str, float]:
    return {k: v for k, v in T.estimation_factors().items()}


# --------------------------------------------------------------------------- suggestions
def suggestions(days: int = 14) -> list[Suggestion]:
    st = stats(days)
    cfg = settings.all()
    out: list[Suggestion] = []
    evidence = st["ended"] + st["focus_days"] + st["mood"]["n"]

    # --- getting to know you
    if not T.list_routines():
        out.append(Suggestion("routines", "Tell me your fixed commitments",
                              "Classes, work hours, meals, the gym: I plan around them, so schedules stop colliding "
                              "with real life.", "tip",
                              {"type": "chat", "label": "Tell Raveena my routine",
                               "prompt": "Let me tell you about my weekly routine so you can plan around it."}))
    if mood.summary(7)["n"] == 0:
        out.append(Suggestion("checkin", "Try a ten-second daily check-in",
                              "A quick mood and energy tap each evening lets me spot what drains you and what helps, "
                              "and go lighter on hard days.", "tip",
                              {"type": "chat", "label": "Check in now", "prompt": "I'd like to do a quick check-in."}))

    # --- pace per category
    factors = T.estimation_factors()
    for cat, f in sorted(factors.items()):
        if cat == "*":
            continue
        if f >= 1.2:
            out.append(Suggestion(f"pace-{cat}", f"{cat} tasks take you about {int(round((f - 1) * 100))}% longer than you plan",
                                  f"I now plan them at {f:.1f}x your estimate so your day stops overflowing. "
                                  "Splitting big ones into smaller steps helps your own estimates too.", "tip"))
        elif f <= 0.85:
            out.append(Suggestion(f"pace-{cat}", f"You usually beat your {cat} estimates",
                                  f"You tend to finish in about {int(round(f * 100))}% of the time you expect, "
                                  "so I've trimmed those plans and you'll get breathing room.", "win"))

    # --- when you actually do your best work
    lp = learned_peak()
    if lp:
        ps, pe = clock.hm_to_min(cfg["peak_start"]) // 60, clock.hm_to_min(cfg["peak_end"]) // 60
        overlap = max(0, min(pe, lp[1]) - max(ps, lp[0]))
        if overlap <= 1:
            out.append(Suggestion("peak", f"Your real focus hours look like {_fmt_h(lp[0])} to {_fmt_h(lp[1])}",
                                  f"About {int(lp[2] * 100)}% of the work you've logged happens then, not in your "
                                  f"current focus window ({fmt.time(cfg['peak_start'])} to {fmt.time(cfg['peak_end'])}). "
                                  "Moving it means your hardest tasks land when you're actually sharp.", "tip",
                                  {"type": "settings", "label": "Use these hours",
                                   "values": {"peak_start": f"{lp[0]:02d}:00", "peak_end": f"{lp[1]:02d}:00"}}))

    # --- plan adherence by time of day
    rates = {p: v["done"] / v["ended"] for p, v in st["parts"].items() if v["ended"] >= 4}
    if len(rates) >= 2:
        best, worst = max(rates, key=rates.get), min(rates, key=rates.get)
        if rates[best] - rates[worst] >= 0.3:
            out.append(Suggestion("timeofday", f"You follow through far more in the {best}",
                                  f"{int(rates[best] * 100)}% of {best} sessions get done versus "
                                  f"{int(rates[worst] * 100)}% in the {worst}. Put your most important work early and "
                                  f"keep the {worst} for lighter tasks.", "tip"))

    # --- plan size
    if st["ended"] >= 6 and st["adherence"] is not None:
        cur = int(cfg["max_focus_minutes"])
        if st["adherence"] < 0.55:
            new = max(120, int(round(cur * 0.8 / 30)) * 30)
            out.append(Suggestion("lighter", f"You finished {st['blocks_done']} of {st['ended']} planned sessions",
                                  "That usually means the plan is too full, not that you're lazy. A lighter daily load "
                                  "will feel better and you'll finish more of it.", "heads-up",
                                  {"type": "settings", "label": f"Plan {fmt.duration(new)} a day",
                                   "values": {"max_focus_minutes": new}}))
        elif st["adherence"] >= 0.9 and st["ended"] >= 10 and st["open"] > 8 and cur < 480:
            new = cur + 30
            out.append(Suggestion("heavier", "You're finishing almost everything I plan",
                                  f"{int(st['adherence'] * 100)}% of sessions done. There's room to take on a bit more "
                                  "without strain.", "win",
                                  {"type": "settings", "label": f"Plan {fmt.duration(new)} a day",
                                   "values": {"max_focus_minutes": new}}))

    # --- upcoming overload
    today = clock.today()
    cap = sum(planner.day_capacity(today + timedelta(days=i), cfg) for i in range(3))
    booked = sum(planner.day_summary(today + timedelta(days=i))["planned"] for i in range(3))
    if cap and booked > cap * 1.1:
        out.append(Suggestion("overload", "The next three days are heavily booked",
                              f"{fmt.duration(booked)} planned against your usual {fmt.duration(cap)}. Something should "
                              "move: let's decide what truly has to happen first.", "heads-up",
                              {"type": "chat", "label": "Help me lighten it",
                               "prompt": "My next few days look overbooked. Help me decide what to move or drop."}))

    # --- backlog health
    for t in st["stuck"][:2]:
        out.append(Suggestion(f"stuck-{t['id']}", f"“{t['title']}” keeps slipping",
                              f"It's moved {t['postponed']} times. Usually that means it's too big or unclear. "
                              "Shrinking it to a 15-minute first step often breaks the jam, or drop it if it no longer matters.",
                              "heads-up", {"type": "chat", "label": "Break it down",
                                           "prompt": f"Help me break down “{t['title']}” into a tiny first step, or decide to drop it."}))
    if len(st["overdue"]) >= 3:
        out.append(Suggestion("overdue", f"{len(st['overdue'])} tasks are overdue",
                              "Pick one to finish today, then reschedule or drop the rest. A shorter honest list beats "
                              "a long guilty one.", "heads-up",
                              {"type": "chat", "label": "Sort them out", "prompt": "Help me sort out my overdue tasks."}))
    if len(st["old"]) >= 4:
        out.append(Suggestion("old", f"{len(st['old'])} tasks have sat undated for 3+ weeks",
                              "Either give them a date or let them go. Old undated tasks quietly drain attention.", "tip",
                              {"type": "chat", "label": "Review them", "prompt": "Help me review my old undated tasks."}))

    # --- habits
    for t in trackers.list_trackers():
        streak = trackers.streak(t)
        if streak >= 5:
            out.append(Suggestion(f"streak-{t['id']}", f"{streak} days in a row: {t['name']}",
                                  "Streaks are built from boring repetition. Nicely done.", "win"))
            continue
        hist = trackers.history(t, 14)
        active_days = sum(1 for _, v in hist if v > 0)
        met_days = sum(1 for _, v in hist if trackers.met(t, v))
        if active_days >= 3 and met_days / 14 < 0.35 and t["kind"] == "sum":
            avg_active = sum(v for _, v in hist if v > 0) / active_days
            new_target = max(t["step"], round(avg_active / t["step"]) * t["step"])
            if new_target < t["target"]:
                shown = trackers.format_value(t, round(avg_active / 5) * 5 if (t["unit"] or "") in ("min", "ml") else round(avg_active, 1))
                out.append(Suggestion(f"target-{t['id']}", f"{t['name']} goal met on {met_days} of 14 days",
                                      f"On the days you do it you average {shown}. "
                                      "A target you can actually hit builds the habit faster than one you keep missing.",
                                      "tip", {"type": "tracker_target", "label": f"Set goal to {trackers.format_value(t, new_target)}",
                                              "tracker_id": t["id"], "value": new_target}))

    # --- sleep and energy
    sleep = next((t for t in trackers.list_trackers() if t["name"].lower() == "sleep"), None)
    if sleep:
        sl = trackers.totals_between(sleep, today - timedelta(days=27), today)
        daily = mood.daily_averages(28)
        good = [daily[d][1] for d in sl if sl[d] >= 7 and d in daily and daily[d][1]]
        poor = [daily[d][1] for d in sl if sl[d] < 7 and d in daily and daily[d][1]]
        if len(good) >= 3 and len(poor) >= 3 and sum(good) / len(good) - sum(poor) / len(poor) >= 0.6:
            wind_end = clock.hm_to_min(cfg["sleep_time"])
            out.append(Suggestion("sleep", "Your energy is clearly better after 7+ hours of sleep",
                                  f"Average energy {sum(good) / len(good):.1f} after a full night versus "
                                  f"{sum(poor) / len(poor):.1f} after a short one. Protecting a wind-down before bed is "
                                  "probably your highest-leverage habit.", "tip",
                                  {"type": "routine", "label": "Add a wind-down routine",
                                   "title": "Wind down", "days": list(range(7)),
                                   "start": clock.min_to_hm(wind_end - 30), "end": clock.min_to_hm(wind_end)}))

    # --- mood
    recent = mood.history(14)[-5:]
    if len(recent) >= 4 and sum(r["mood"] for r in recent) / len(recent) <= 2.4:
        contact = (cfg.get("crisis_contact") or "").strip()
        extra = f" If it would help to talk to someone, {contact} is a good place to start." if contact else \
            " If it keeps up for a couple of weeks, talking with someone you trust, or a professional, is worth considering."
        out.append(Suggestion("mood-low", "The last few days have looked heavy",
                              "I'll keep your plans lighter while you're feeling low." + extra, "heads-up",
                              {"type": "chat", "label": "Talk about it", "prompt": "I've been feeling low lately and I'd like to talk."}))
    elif st["mood"]["delta"] is not None and st["mood"]["delta"] >= 0.7 and st["mood"]["n"] >= 4:
        out.append(Suggestion("mood-up", "Your mood is up on last week",
                              "Worth noticing what changed. Tell me and I'll remember what's working.", "win"))

    if evidence < 4 and not out:
        out.append(Suggestion("early", "I'm still getting to know you",
                              "Plan a few days, tick things off and log how you feel. After about a week I can start "
                              "pointing out patterns that are specific to you.", "tip"))
    rank = {"heads-up": 0, "tip": 1, "win": 2}
    out.sort(key=lambda s: rank.get(s.tone, 1))
    return out


def apply(s: Suggestion) -> str:
    """Carry out a suggestion's one-click action. Returns a message for the UI."""
    a = s.action or {}
    kind = a.get("type")
    if kind == "settings":
        settings.update(a["values"])
        return "Done. I'll plan around that from now on."
    if kind == "routine":
        T.add_routine(a["title"], a["days"], a["start"], a["end"], "Routine")
        return f"Added “{a['title']}” to your routines."
    if kind == "tracker_target":
        trackers.update_tracker(a["tracker_id"], target=a["value"])
        return "Goal updated."
    return ""


# --------------------------------------------------------------------------- summaries
def week_sentence(days: int = 7) -> str:
    st = stats(days)
    bits = []
    if st["ended"]:
        bits.append(f"finished {st['blocks_done']} of {st['ended']} planned sessions")
    if st["focus_minutes"]:
        bits.append(f"put in {fmt.duration(st['focus_minutes'])} of focused work")
    if st["tasks_completed"]:
        bits.append(f"completed {fmt.plural(st['tasks_completed'], 'task')}")
    for t in trackers.list_trackers():
        if t["name"].lower() in ("water", "sleep"):
            hist = trackers.history(t, days)
            n = sum(1 for _, v in hist if trackers.met(t, v))
            if any(v > 0 for _, v in hist):
                bits.append(f"hit your {t['name'].lower()} goal on {n} of {days} days")
    m = st["mood"]
    if m["avg_mood"] is not None:
        bits.append(f"averaged a mood of {m['avg_mood']:.1f} out of 5")
    if not bits:
        return "There isn't enough yet to summarise. Plan a day and tick things off, and this fills in."
    head = "In the last %d days you " % days
    return head + ", ".join(bits[:-1]) + (", and " if len(bits) > 1 else "") + bits[-1] + "."


def digest(days: int = 14) -> str:
    """A compact, factual summary for the AI model (it turns this into advice)."""
    st = stats(days)
    lines = [f"Window: last {days} days.", week_sentence(min(days, 7))]
    if st["ended"]:
        lines.append(f"Plan adherence: {st['blocks_done']}/{st['ended']} sessions done "
                     f"({int((st['adherence'] or 0) * 100)}%). Morning/afternoon/evening done: " +
                     ", ".join(f"{p} {v['done']}/{v['ended']}" for p, v in st["parts"].items()))
    lines.append(f"Open tasks: {st['open']}; overdue: {len(st['overdue'])}; slipped 3+ times: "
                 f"{', '.join(t['title'] for t in st['stuck']) or 'none'}.")
    f = T.estimation_factors()
    lines.append("Pace (actual/estimate): " + ", ".join(f"{k} x{v}" for k, v in f.items()))
    lp = learned_peak()
    if lp:
        lines.append(f"Learned best focus window: {_fmt_h(lp[0])} to {_fmt_h(lp[1])} ({int(lp[2] * 100)}% of logged work).")
    for t in trackers.list_trackers():
        h = trackers.history(t, min(days, 14))
        lines.append(f"{t['name']}: goal met {sum(1 for _, v in h if trackers.met(t, v))}/{len(h)} days, "
                     f"streak {trackers.streak(t)}.")
    m = st["mood"]
    if m["avg_mood"] is not None:
        lines.append(f"Mood avg {m['avg_mood']:.1f}/5, energy {(m['avg_energy'] or 0):.1f}/5 over {m['n']} check-ins.")
    sug = suggestions(days)
    if sug:
        lines.append("Suggestions I'd make:")
        lines += [f"- [{s.tone}] {s.title}: {s.detail}" for s in sug[:6]]
    return "\n".join(lines)
