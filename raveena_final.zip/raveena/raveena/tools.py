"""Everything Raveena can *do*, in one place.

The AI model, the offline "Lite" brain and the UI buttons all go through ``execute``.
That is where the safeguards live:

* **low risk**   (adding, updating, planning, logging): runs immediately, is written to the
                  action log and is journaled so it can be undone.
* **high risk**  (deleting tasks/goals/trackers, forgetting memories): never runs on its own.
                  It becomes a *pending* action you approve or decline in the app.
* **read-only**  tools leave no trace.

To add a capability, write a handler and decorate it with ``@tool``. Anything that reaches
outside this app (sending email, posting messages) should be registered with ``risk="high"``.
"""
from __future__ import annotations

import logging
import traceback
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Callable

from . import actions, clock, db, fmt, focus, memory, planner, settings, trackers
from . import mood as mood_mod
from . import tasks as T
from . import timeparse as tp
from .tasks import UserError

log = logging.getLogger("raveena.tools")


# --------------------------------------------------------------------------- plumbing
@dataclass
class Result:
    text: str                 # what the model reads
    summary: str = ""         # what you read (the receipt under the message)


@dataclass
class Outcome:
    status: str               # done | pending | failed
    text: str
    summary: str
    action_id: int | None
    undoable: bool
    tool: str
    silent: bool = False      # read-only: no receipt

    @property
    def ok(self) -> bool:
        return self.status != "failed"

    def chip(self) -> dict:
        return dict(action_id=self.action_id, tool=self.tool, status=self.status,
                    summary=self.summary, undoable=self.undoable)


@dataclass
class Tool:
    name: str
    description: str
    properties: dict
    required: list[str]
    handler: Callable[..., Result]
    risk: str = "low"
    preview: Callable[[dict], str] | None = None
    readonly: bool = False
    expose: bool = True        # False = internal (automations); never shown to the AI model


REGISTRY: dict[str, Tool] = {}


def tool(name: str, description: str, props: dict | None = None, *, required: list[str] | None = None,
         risk: str = "low", preview: Callable[[dict], str] | None = None, readonly: bool = False,
         expose: bool = True):
    def deco(fn: Callable[..., Result]):
        REGISTRY[name] = Tool(name, description, props or {}, list(required or []), fn, risk, preview, readonly, expose)
        return fn
    return deco


def _s(desc: str, enum: list[str] | None = None) -> dict:
    d: dict[str, Any] = {"type": "string", "description": desc}
    if enum:
        d["enum"] = enum
    return d


def _i(desc: str) -> dict:
    return {"type": "integer", "description": desc}


def _n(desc: str) -> dict:
    return {"type": "number", "description": desc}


def _b(desc: str) -> dict:
    return {"type": "boolean", "description": desc}


def schemas() -> list[dict]:
    """Tool definitions in the shape the Gemini API expects (JSON schema)."""
    out = []
    for t in REGISTRY.values():
        if not t.expose:
            continue
        out.append({"name": t.name, "description": t.description,
                    "input_schema": {"type": "object", "properties": t.properties, "required": t.required}})
    return out


def _clean_args(t: Tool, args: Any) -> dict:
    if not isinstance(args, dict):
        return {}
    return {k: v for k, v in args.items() if k in t.properties and v is not None}


def _find_pending(name: str, args: dict) -> dict | None:
    for a in actions.pending():
        if a["tool"] == name and a["args"] == args:
            return a
    return None


def execute(name: str, args: dict | None = None, *, source: str = "chat", turn: str | None = None,
            confirmed: bool = False, action_id: int | None = None) -> Outcome:
    t = REGISTRY.get(name)
    if t is None:
        return Outcome("failed", f"I don't have a tool called '{name}'.", "", None, False, name, silent=True)
    args = _clean_args(t, args)

    if t.risk == "high" and not confirmed:
        try:
            preview = t.preview(args) if t.preview else name
        except UserError as e:
            return Outcome("failed", str(e), str(e), None, False, name)
        dup = _find_pending(name, args)
        aid = dup["id"] if dup else actions.create(name, args, preview, risk="high", status="pending",
                                                   source=source, turn=turn)
        text = (f"NOT DONE YET. This needs the user's approval, and a confirmation card is now showing in the "
                f"app: {preview}. Tell them it's waiting for their OK. Don't call it again.")
        return Outcome("pending", text, f"Waiting for your OK: {preview}", aid, False, name)

    try:
        with db.transaction(), db.journal() as ops:
            res = t.handler(**args)
    except UserError as e:
        msg = str(e)
        aid = None
        if not t.readonly:
            aid = action_id or actions.create(name, args, msg, risk=t.risk, status="failed", source=source, turn=turn)
            actions.finish(aid, "failed", result=msg)
        return Outcome("failed", msg, msg, aid, False, name, silent=t.readonly)
    except TypeError as e:                                   # wrong/missing arguments from the model
        msg = f"I called '{name}' with the wrong details ({e}). Nothing was changed."
        return Outcome("failed", msg, msg, None, False, name, silent=True)
    except Exception as e:                                   # noqa: BLE001 - never crash a conversation
        log.error("tool %s failed: %s", name, traceback.format_exc())
        msg = f"That didn't work ({type(e).__name__}). Nothing was changed."
        aid = None
        if not t.readonly:
            aid = action_id or actions.create(name, args, msg, risk=t.risk, status="failed", source=source, turn=turn)
            actions.finish(aid, "failed", result=traceback.format_exc()[-1500:])
        return Outcome("failed", msg, msg, aid, False, name, silent=t.readonly)

    if t.readonly:
        return Outcome("done", res.text, res.summary, None, False, name, silent=True)
    aid = action_id or actions.create(name, args, res.summary, risk=t.risk, status="done", source=source, turn=turn)
    actions.finish(aid, "done", result=res.text, summary=res.summary or name, undo_ops=ops)
    return Outcome("done", res.text, res.summary or name, aid, bool(ops), name)


def approve(action_id: int) -> Outcome:
    a = actions.get(action_id)
    if not a or a["status"] != "pending":
        raise UserError("That request isn't waiting for approval any more.")
    return execute(a["tool"], a["args"], source=a["source"], turn=a["turn"], confirmed=True, action_id=action_id)


def decline(action_id: int) -> None:
    actions.reject(action_id)


# --------------------------------------------------------------------------- small formatting helpers
def _task_line(t: dict) -> str:
    bits = []
    if t.get("due_date"):
        bits.append(f"due {fmt.day(t['due_date'])}" + (f" {fmt.time(t['due_time'])}" if t.get("due_time") else ""))
    bits += [fmt.duration(t["est_minutes"]), f"P{t['priority']}", t["category"]]
    return f"#{t['id']} \"{t['title']}\" ({', '.join(bits)})"


def _short_task(t: dict) -> str:
    return f"“{t['title']}”"


# =========================================================================== TASKS
@tool("add_task",
      "Create a task or to-do. Use for anything the user wants to do or not forget. Infer sensible defaults "
      "(a rough time estimate, a category, a due date if they imply one) instead of asking. Dates are YYYY-MM-DD "
      "using the current date from the context.",
      {"title": _s("Short action-style title, e.g. 'Write lab report'."),
       "due_date": _s("Deadline, YYYY-MM-DD."),
       "due_time": _s("Deadline time of day, HH:MM (24h), only if they gave one."),
       "est_minutes": _i("Estimated effort in minutes."),
       "priority": _i("1 urgent, 2 high, 3 normal (default), 4 low."),
       "category": _s("Study, Work, Health, Personal, Creative or General."),
       "energy": _s("deep = needs full focus, light = easy/admin, auto = decide from the title.",
                    ["auto", "deep", "light"]),
       "notes": _s("Extra detail worth keeping."),
       "goal": _s("Goal id or title to link this task to.")},
      required=["title"])
def _h_add_task(title, due_date=None, due_time=None, est_minutes=None, priority=None, category=None,
                energy="auto", notes="", goal=None):
    goal_id = T.find_goal(goal)["id"] if goal else None
    t, created = T.add_task(title, due_date=due_date, due_time=due_time, est_minutes=est_minutes, priority=priority,
                            category=category, energy=energy, notes=notes, goal_id=goal_id)
    if not created:
        return Result(f"That task already exists: {_task_line(t)}. Nothing was added.", f"Already had {_short_task(t)}")
    when = f", due {fmt.day(t['due_date'])}" if t["due_date"] else ""
    return Result(f"Added {_task_line(t)}. It isn't scheduled until you plan the day or week.",
                  f"Added {_short_task(t)}{when}")


@tool("update_task",
      "Change an existing task: rename it, move its deadline, change priority or estimate, or drop it "
      "(status 'dropped' keeps it recoverable). To clear a due date pass due_date 'none'.",
      {"task": _s("Task id (best) or a distinctive part of its title."),
       "title": _s("New title."), "due_date": _s("New deadline YYYY-MM-DD, or 'none'."),
       "due_time": _s("New deadline time HH:MM, or 'none'."), "est_minutes": _i("New estimate in minutes."),
       "priority": _i("1 urgent .. 4 low."), "category": _s("New category."),
       "energy": _s("deep, light or auto.", ["auto", "deep", "light"]), "notes": _s("New notes."),
       "status": _s("todo, doing or dropped.", ["todo", "doing", "dropped"])},
      required=["task"])
def _h_update_task(task, **fields):
    t = T.find_task(task)
    changes = {k: v for k, v in fields.items() if v is not None}
    if not changes:
        raise UserError("What should I change about that task?")
    for k in ("due_date", "due_time"):
        if str(changes.get(k, "")).lower() == "none":
            changes[k] = None
    updated = T.update_task(t["id"], **changes)
    return Result(f"Updated {_task_line(updated)}. Re-plan if the schedule should reflect this.",
                  f"Updated {_short_task(updated)}")


@tool("complete_task",
      "Mark a task as finished. If the user says how long it really took, pass actual_minutes (total time spent), "
      "which teaches Raveena to estimate your pace.",
      {"task": _s("Task id (best) or a distinctive part of its title."),
       "actual_minutes": _i("Total minutes it really took.")}, required=["task"])
def _h_complete_task(task, actual_minutes=None):
    t = T.find_task(task)
    done = T.complete_task(t["id"], actual_minutes)
    extra = ""
    if done["actual_minutes"] and done["est_minutes"]:
        r = done["actual_minutes"] / done["est_minutes"]
        if r >= 1.25:
            extra = f" It took {fmt.duration(done['actual_minutes'])} against an estimate of {fmt.duration(done['est_minutes'])}."
        elif r <= 0.75:
            extra = f" Faster than planned: {fmt.duration(done['actual_minutes'])} vs {fmt.duration(done['est_minutes'])}."
    return Result(f"Marked {_short_task(done)} done.{extra}", f"Done: {_short_task(done)}")


@tool("list_tasks", "List tasks. Use when you need ids or want to check what's open.",
      {"status": _s("open (default), done or all.", ["open", "done", "all"]),
       "category": _s("Filter by category."), "search": _s("Words in the title."),
       "due_before": _s("Only tasks due on or before this date YYYY-MM-DD."), "limit": _i("Max rows (default 20).")},
      readonly=True)
def _h_list_tasks(status="open", category=None, search=None, due_before=None, limit=20):
    sts = {"open": ["todo", "doing"], "done": ["done"], "all": None}.get(status or "open", ["todo", "doing"])
    rows = T.list_tasks(status=sts, category=category, search=search,
                        due_before=T.to_date(due_before, "due_before"), limit=int(limit or 20))
    if not rows:
        return Result("No matching tasks.")
    return Result("\n".join(_task_line(t) + (" [done]" if t["status"] == "done" else "") for t in rows))


@tool("delete_task",
      "Permanently delete a task and its scheduled time. Needs the user's approval. Prefer update_task with "
      "status 'dropped' unless they clearly want it gone.",
      {"task": _s("Task id or distinctive part of the title.")}, required=["task"], risk="high",
      preview=lambda a: f"Delete task {_short_task(T.find_task(a.get('task'), statuses=None))} and its scheduled time")
def _h_delete_task(task):
    t = T.find_task(task, statuses=None)
    T.delete_task(t["id"])
    return Result(f"Deleted {_short_task(t)}.", f"Deleted {_short_task(t)}")


# =========================================================================== SCHEDULE
@tool("plan_schedule",
      "Build or rebuild the schedule for today, tomorrow, the next 7 days ('week') or a specific date. Replanning "
      "keeps anything the user locked, treats unconfirmed past sessions as missed, fits work around routines and "
      "events, and reports tasks that can't meet their deadline. Use this whenever the user asks to plan, replan "
      "or reschedule, or after big changes to tasks.",
      {"scope": _s("today, tomorrow, week, or a date YYYY-MM-DD."),
       "gentle": _b("Plan a lighter load (about 60%). Use when the user is tired, low or overwhelmed.")})
def _h_plan_schedule(scope="today", gentle=False):
    scope = (scope or "today").strip().lower()
    load = 0.6 if gentle else None
    if scope == "today":
        res = planner.plan_today(load=load)
    elif scope == "tomorrow":
        res = planner.plan_day(clock.today() + timedelta(days=1), load=load)
    elif scope in ("week", "this week", "the week", "7 days", "next 7 days"):
        res = planner.plan_week(load=load)
    else:
        d = T.to_date(scope, "date")
        if d is None:
            raise UserError("Plan which day? Use today, tomorrow, week or a date.")
        res = planner.plan_day(d, load=load)
    n = len(res.placed)
    label = {"today": "today", "tomorrow": "tomorrow"}.get(scope, "the week" if "week" in scope or "7" in scope else scope)
    summary = f"Planned {label}: {fmt.plural(n, 'block')}, {fmt.duration(res.minutes_placed)}" if n else f"Planned {label}: nothing to place"
    if res.at_risk:
        summary += f", {len(res.at_risk)} at risk"
    return Result(res.text(), summary)


@tool("get_schedule", "Read the schedule (routines, events and planned work sessions with ids) for one day.",
      {"date": _s("YYYY-MM-DD, 'today' or 'tomorrow'. Default today.")}, readonly=True)
def _h_get_schedule(date=None):
    d = T.to_date(date or "today", "date") or clock.today()
    items = planner.agenda(d)
    lines = [f"{fmt.long_date(d)}:"]
    for i in items:
        tag = {"task": f"{i['status']}", "routine": "routine", "event": "event"}[i["kind"]]
        extra = f" (task #{i['task_id']}, block #{i['id']})" if i["kind"] == "task" else ""
        lines.append(f"  {i['start']}-{i['end']} [{tag}] {i['title']}{extra}")
    if len(lines) == 1:
        lines.append("  Nothing scheduled.")
    gaps = planner.day_gaps(d, items)
    if gaps:
        lines.append("  Free: " + ", ".join(f"{g['start']}-{g['end']}" for g in gaps[:6]))
    return Result("\n".join(lines))


@tool("schedule_task",
      "Put a task at a specific time. It's locked, so replanning won't move it. Fails if it overlaps something.",
      {"task": _s("Task id or distinctive part of the title."), "date": _s("YYYY-MM-DD."),
       "start_time": _s("HH:MM (24h)."), "minutes": _i("Length in minutes (default: the task's estimate).")},
      required=["task", "date", "start_time"])
def _h_schedule_task(task, date, start_time, minutes=None):
    t = T.find_task(task)
    b = planner.schedule_task(t["id"], date, start_time, minutes)
    return Result(f"Scheduled {_short_task(t)} on {fmt.day(b['date'])} {b['start']}-{b['end']} (block #{b['id']}, locked).",
                  f"Scheduled {_short_task(t)} for {fmt.day(b['date'])} at {fmt.time(b['start'])}")


@tool("move_block", "Move a scheduled work session to another time or day (it becomes locked).",
      {"block_id": _i("Block id from get_schedule or plan_schedule."), "date": _s("YYYY-MM-DD."),
       "start_time": _s("HH:MM (24h).")}, required=["block_id", "date", "start_time"])
def _h_move_block(block_id, date, start_time):
    b = planner.move_block(int(block_id), date, start_time)
    t = db.get("tasks", b["task_id"])
    return Result(f"Moved to {fmt.day(b['date'])} {b['start']}-{b['end']}.",
                  f"Moved {_short_task(t)} to {fmt.day(b['date'])} at {fmt.time(b['start'])}")


@tool("report_session",
      "Tell the planner what happened with a scheduled work session so it can adapt: 'done' (optionally with how "
      "long it really took), 'missed' (didn't happen) or 'skipped' (chose not to). Missed or overrunning sessions "
      "automatically re-plan the rest of the day. Use whenever the user says they did, finished, missed, skipped or "
      "ran over something.",
      {"task": _s("Task id or distinctive part of the title."),
       "outcome": _s("done, missed or skipped.", ["done", "missed", "skipped"]),
       "actual_minutes": _i("How long the session really took, if they said."),
       "finished": _b("True if the whole task is now complete; false if only this session is.")},
      required=["task", "outcome"])
def _h_report_session(task, outcome, actual_minutes=None, finished=None):
    t = T.find_task(task)
    now = clock.now()
    today_blocks = [b for b in db.rows("SELECT * FROM blocks WHERE task_id=? AND date=? AND status='planned' "
                                       "ORDER BY start", (t["id"], now.date().isoformat()))]
    past = [b for b in today_blocks if planner._at(b["date"], b["start"]) <= now]
    block = past[-1] if past else (today_blocks[0] if today_blocks else None)
    if outcome == "done":
        if block:
            out = planner.complete_block(block["id"], actual_minutes, finished, now=now)
            msg = f"Logged the session for {_short_task(t)}."
            if out["finished"]:
                msg += " The task is complete."
            elif out["left"]:
                msg += f" About {fmt.duration(out['left'])} is still left on it."
            if out["overrun"] >= 10:
                msg += f" It ran {fmt.duration(out['overrun'])} over."
            if out["replanned"]:
                msg += " I re-planned the rest of today:\n" + out["replanned"].text()
            return Result(msg, f"Logged {_short_task(t)}" + (f", {fmt.duration(actual_minutes)}" if actual_minutes else ""))
        if finished is False:
            if not actual_minutes:
                raise UserError("How long did you work on it?")
            T.log_time(t["id"], actual_minutes)
            return Result(f"Logged {fmt.duration(actual_minutes)} on {_short_task(t)}.", f"Logged time on {_short_task(t)}")
        T.complete_task(t["id"], actual_minutes)
        return Result(f"Marked {_short_task(t)} done.", f"Done: {_short_task(t)}")
    # missed / skipped
    if block:
        out = planner.miss_block(block["id"], status="skipped" if outcome == "skipped" else "missed", now=now)
        res = out["replanned"]
    else:
        if outcome == "missed":
            T.bump_postponed(t["id"])
        res = planner.plan_today(mark=False, now=now)
    return Result(f"Marked the session for {_short_task(t)} as {outcome} and re-planned:\n{res.text()}",
                  f"{outcome.capitalize()} {_short_task(t)}, re-planned the day")


@tool("log_time", "Record time spent on a task that wasn't a scheduled session ('I studied biology for 45 minutes').",
      {"task": _s("Task id or distinctive part of the title."), "minutes": _i("Minutes spent.")},
      required=["task", "minutes"])
def _h_log_time(task, minutes):
    t = T.find_task(task)
    t = T.log_time(t["id"], minutes)
    return Result(f"Logged {fmt.duration(minutes)}. Total on {_short_task(t)}: {fmt.duration(t['actual_minutes'])}.",
                  f"Logged {fmt.duration(minutes)} on {_short_task(t)}")


# =========================================================================== CALENDAR
@tool("add_event", "Add a one-off fixed commitment (appointment, exam, class, meeting). The planner schedules around it.",
      {"title": _s("What it is."), "date": _s("YYYY-MM-DD."), "start_time": _s("HH:MM (24h)."),
       "end_time": _s("HH:MM (24h)."), "category": _s("Optional category."), "notes": _s("Optional notes.")},
      required=["title", "date", "start_time", "end_time"])
def _h_add_event(title, date, start_time, end_time, category=None, notes=""):
    e, created = T.add_event(title, date, start_time, end_time, category or "Event", notes)
    when = f"{fmt.day(e['date'])} {fmt.time(e['start'])} to {fmt.time(e['end'])}"
    if not created:
        return Result(f"That event already exists (#{e['id']}).", f"Already had “{e['title']}”")
    return Result(f"Added event #{e['id']} “{e['title']}” on {when}. Re-plan to schedule around it.",
                  f"Added “{e['title']}”, {when}")


@tool("add_routine",
      "Add a repeating weekly commitment or habit block (classes, gym, meals, commute, wind-down). The planner treats "
      "it as busy time every matching day.",
      {"title": _s("What it is."), "days": {"type": "array", "items": {"type": "integer"},
                                            "description": "Weekdays as numbers, Monday=0 .. Sunday=6."},
       "start_time": _s("HH:MM (24h)."), "end_time": _s("HH:MM (24h)."), "category": _s("Optional category.")},
      required=["title", "days", "start_time", "end_time"])
def _h_add_routine(title, days, start_time, end_time, category=None):
    r, created = T.add_routine(title, days, start_time, end_time, category or "Routine")
    label = f"{tp.days_label([int(x) for x in r['days'].split(',')])}, {fmt.time(r['start'])} to {fmt.time(r['end'])}"
    if not created:
        return Result(f"That routine already exists (#{r['id']}).", f"Already had “{r['title']}”")
    return Result(f"Added routine #{r['id']} “{r['title']}” ({label}). Re-plan so the schedule works around it.",
                  f"Added routine “{r['title']}”, {label}")


def _calendar_item(kind: str, item_id: int) -> dict:
    item = db.get("routines" if kind == "routine" else "events", int(item_id))
    if not item:
        raise UserError(f"There's no {kind} with id {item_id}.")
    return item


@tool("delete_calendar_item", "Remove a routine or event. Needs the user's approval.",
      {"kind": _s("routine or event.", ["routine", "event"]), "id": _i("Its id.")}, required=["kind", "id"],
      risk="high", preview=lambda a: f"Remove {a.get('kind')} “{_calendar_item(a.get('kind', 'event'), a.get('id'))['title']}”")
def _h_delete_calendar_item(kind, id):
    item = _calendar_item(kind, id)
    (T.delete_routine if kind == "routine" else T.delete_event)(int(id))
    return Result(f"Removed {kind} “{item['title']}”.", f"Removed {kind} “{item['title']}”")


# =========================================================================== TRACKERS
@tool("log_activity",
      "Log progress on a tracker: water (value in ml; a glass is about 250 ml), study or exercise minutes, sleep "
      "hours, or tick a done/not-done habit. Use whenever the user says they drank, studied, exercised, slept, "
      "meditated, etc.",
      {"tracker": _s("Tracker name, e.g. Water, Study, Exercise, Sleep, Meditate, or a custom one."),
       "value": _n("Amount in the tracker's unit. Omit for a done/not-done habit or to add one default step."),
       "note": _s("Optional note.")}, required=["tracker"])
def _h_log_activity(tracker, value=None, note=""):
    out = trackers.log(tracker, value, note)
    if "tracker" not in out:                      # done/not-done habit already ticked today
        return Result("That's already ticked for today.", "Already ticked today")
    t, tot = out["tracker"], out["total"]
    target = trackers.format_value(t, t["target"]) if t["kind"] != "check" else "done"
    now_s = trackers.format_value(t, tot)
    added = trackers.format_value(t, out["value"]) if t["kind"] != "check" else ""
    if t["kind"] == "check":
        return Result(f"Ticked {t['name']} for today.", f"Ticked {t['name']}")
    msg = f"{t['name']} today: {now_s} of {target}."
    if t["kind"] == "sum" and added:
        return Result("Logged " + added + ". " + msg, f"Logged {added} {t['name'].lower()} ({now_s} of {target})")
    return Result(msg, f"{t['name']}: {now_s} (goal {target})")


@tool("create_tracker", "Start tracking something new (a habit, a count, a daily number).",
      {"name": _s("Name, e.g. 'Reading'."),
       "kind": _s("sum = adds up through the day, once = one value per day, check = done/not done.",
                  ["sum", "once", "check"]),
       "unit": _s("Unit, e.g. min, ml, pages, h."), "target": _n("Daily target."), "step": _n("Typical amount per tap."),
       "count_time_from_category": _s("Optional: automatically count time logged on tasks of this category.")},
      required=["name", "kind", "target"])
def _h_create_tracker(name, kind, target, unit="", step=None, count_time_from_category=None):
    t, created = trackers.add_tracker(name, kind, unit, target, step, source_category=count_time_from_category)
    if not created:
        return Result(f"I already track {t['name']}.", f"Already tracking {t['name']}")
    return Result(f"Now tracking {t['name']} (target {trackers.format_value(t, t['target'])}/day).",
                  f"Started tracking {t['name']}")


@tool("delete_tracker", "Stop tracking something and delete its history. Needs the user's approval.",
      {"tracker": _s("Tracker name or id.")}, required=["tracker"], risk="high",
      preview=lambda a: f"Delete the {trackers.find_tracker(a.get('tracker'))['name']} tracker and its history")
def _h_delete_tracker(tracker):
    t = trackers.find_tracker(tracker)
    trackers.delete_tracker(t["id"])
    return Result(f"Deleted the {t['name']} tracker.", f"Deleted {t['name']} tracker")


# =========================================================================== MOOD
@tool("log_mood",
      "Record how the user is feeling (mood 1 low .. 5 great, energy 1 drained .. 5 charged) when they share "
      "feelings, so patterns can be spotted and plans kept realistic. Mention that you noted it.",
      {"mood": _i("1 to 5."), "energy": _i("1 to 5, if you can tell."),
       "note": _s("A few words in the user's own terms (no diagnosis)."),
       "tags": {"type": "array", "items": {"type": "string"}, "description": "e.g. stressed, tired, excited."},
       "explicit": _b("True only if the user explicitly asked you to log it.")},
      required=["mood"])
def _h_log_mood(mood, energy=None, note="", tags=None, explicit=False):
    if not settings.get("auto_mood") and not explicit:
        raise UserError("Automatic mood logging is switched off. Ask the user if they'd like it logged.")
    r = mood_mod.log_mood(mood, energy, note, tags)
    label = mood_mod.MOOD_LABELS[r["mood"]]
    return Result(f"Logged mood {r['mood']}/5 ({label})" + (f", energy {r['energy']}/5" if r["energy"] else "") + ".",
                  f"Noted your mood: {label.lower()}")



# =========================================================================== MEMORY
@tool("remember",
      "Save something worth knowing about the user for the long term: goals, preferences, routines, people, what "
      "works for them, recurring struggles, wins. Keep it to one short sentence in third person ('Studies best in "
      "the morning'). Don't save trivia or one-off chatter.",
      {"content": _s("One short sentence."),
       "category": _s("goal, preference, routine, person, health, fact, reflection or win.",
                      list(memory.CATEGORIES)),
       "importance": _i("1 (minor) to 5 (core to who they are). Default 3."),
       "explicit": _b("True only if the user explicitly asked you to remember it.")},
      required=["content"])
def _h_remember(content, category="fact", importance=3, explicit=False):
    if not settings.get("auto_memory") and not explicit:
        raise UserError("Automatic memory is switched off. Ask the user before saving this.")
    m, created = memory.remember(content, category, importance, source="user" if explicit else "raveena")
    return Result(("Saved" if created else "Updated") + f" memory #{m['id']}: {m['content']}",
                  ("Remembered: " if created else "Updated memory: ") + m["content"])


def _memory_preview(a: dict) -> str:
    return f"Forget: “{memory.find(a.get('memory'))['content']}”"


@tool("forget", "Delete a saved memory. Needs the user's approval.",
      {"memory": _s("Memory id (best) or distinctive words from it.")}, required=["memory"], risk="high",
      preview=_memory_preview)
def _h_forget(memory):                       # parameter name matches the schema key
    from . import memory as mem
    m = mem.find(memory)
    mem.forget(m["id"])
    return Result(f"Forgot: {m['content']}", f"Forgot: {m['content']}")


@tool("search_memory", "Look through saved memories.", {"query": _s("Words to look for.")}, required=["query"],
      readonly=True)
def _h_search_memory(query):
    hits = memory.search(query)
    return Result("\n".join(f"#{m['id']} ({m['category']}) {m['content']}" for m in hits) or "Nothing saved about that.")


# =========================================================================== GOALS
@tool("create_goal",
      "Create a goal and, optionally, break it into concrete tasks in the same call (a study plan, a project plan). "
      "Prefer 3 to 8 well-sized tasks with sensible dates.",
      {"title": _s("The goal, e.g. 'Pass the networking exam'."), "why": _s("Why it matters to them, if said."),
       "target_date": _s("YYYY-MM-DD."), "category": _s("Study, Work, Health, Personal, Creative or General."),
       "tasks": {"type": "array", "description": "Tasks that move the goal forward.",
                 "items": {"type": "object", "properties": {
                     "title": {"type": "string"}, "est_minutes": {"type": "integer"},
                     "due_date": {"type": "string", "description": "YYYY-MM-DD"},
                     "priority": {"type": "integer"}}, "required": ["title"]}}},
      required=["title"])
def _h_create_goal(title, why="", target_date=None, category=None, tasks=None):
    g, created = T.add_goal(title, why=why, target_date=target_date, category=category)
    added = []
    for spec in (tasks or [])[:12]:
        if not isinstance(spec, dict) or not spec.get("title"):
            continue
        t, made = T.add_task(spec["title"], due_date=spec.get("due_date") or target_date,
                             est_minutes=spec.get("est_minutes"), priority=spec.get("priority"),
                             category=category or g["category"], goal_id=g["id"])
        if made:
            added.append(t)
    msg = ("Created" if created else "Already had") + f" goal #{g['id']} “{g['title']}”"
    if added:
        msg += " with tasks: " + "; ".join(f"#{t['id']} {t['title']}" for t in added)
    return Result(msg + ".", (f"Goal “{g['title']}”" + (f" with {len(added)} tasks" if added else "")))


@tool("delete_goal", "Delete a goal. Its tasks stay, just unlinked. Needs the user's approval.",
      {"goal": _s("Goal id or part of its title.")}, required=["goal"], risk="high",
      preview=lambda a: f"Delete the goal “{T.find_goal(a.get('goal'))['title']}” (its tasks stay)")
def _h_delete_goal(goal):
    g = T.find_goal(goal)
    T.delete_goal(g["id"])
    return Result(f"Deleted goal “{g['title']}”. Its tasks are still on your list.", f"Deleted goal “{g['title']}”")


@tool("update_goal", "Update a goal's progress, status, title or target date.",
      {"goal": _s("Goal id or part of its title."), "progress": _i("0-100 (only used if the goal has no tasks)."),
       "status": _s("active, done or paused.", ["active", "done", "paused"]), "title": _s("New title."),
       "target_date": _s("New target date YYYY-MM-DD, or 'none'.")}, required=["goal"])
def _h_update_goal(goal, **fields):
    g = T.find_goal(goal)
    changes = {k: v for k, v in fields.items() if v is not None}
    if str(changes.get("target_date", "")).lower() == "none":
        changes["target_date"] = None
    g = T.update_goal(g["id"], **changes)
    return Result(f"Updated goal “{g['title']}”.", f"Updated goal “{g['title']}”")


# =========================================================================== INSIGHTS & SETTINGS
@tool("get_insights",
      "Get an analysis of recent progress (completion, focus time, habits, mood, estimate accuracy) plus Raveena's "
      "current suggestions. Use for 'how am I doing?' and weekly reviews. Turn the findings into practical advice "
      "in your own words rather than reciting numbers.",
      {"days": _i("Window in days (default 14).")}, readonly=True)
def _h_get_insights(days=14):
    from . import insights
    return Result(insights.digest(int(days or 14)))


_PREF_KEYS = {
    "name": "What to call the user.", "wake_time": "HH:MM", "sleep_time": "HH:MM", "day_start": "HH:MM, earliest the "
    "planner may place work", "day_end": "HH:MM, latest the planner may place work", "peak_start": "HH:MM, start of best "
    "focus hours", "peak_end": "HH:MM, end of best focus hours", "max_focus_minutes": "Most task minutes to plan "
    "on a weekday (60-720)", "weekend_load": "Share of that on weekends (0.1-1)", "break_minutes": "Break after long "
    "sessions (0-30)", "tone": "warm, coach or concise", "time_format": "12h or 24h", "crisis_contact": "Someone "
    "or somewhere to suggest if the user is struggling",
}


@tool("update_preferences",
      "Change a personal setting the user asked for (wake/sleep times, focus hours, daily workload, tone, name).",
      {"setting": _s("Which setting: " + "; ".join(f"{k} ({v})" for k, v in _PREF_KEYS.items()), list(_PREF_KEYS)),
       "value": _s("The new value.")}, required=["setting", "value"])
def _h_update_preferences(setting, value):
    key, raw = setting, str(value).strip()
    if key in settings.TIME_KEYS:
        v: Any = T.to_time(raw, key)
    elif key in ("max_focus_minutes", "break_minutes"):
        lo, hi = (60, 720) if key == "max_focus_minutes" else (0, 30)
        v = int(float(raw))
        if not lo <= v <= hi:
            raise UserError(f"{key} should be between {lo} and {hi}.")
    elif key == "weekend_load":
        v = float(raw)
        if not 0.1 <= v <= 1:
            raise UserError("weekend_load should be between 0.1 and 1.")
    elif key == "tone":
        if raw not in ("warm", "coach", "concise"):
            raise UserError("Tone can be warm, coach or concise.")
        v = raw
    elif key == "time_format":
        if raw not in ("12h", "24h"):
            raise UserError("Time format can be 12h or 24h.")
        v = raw
    else:
        v = raw[:200]
    settings.set(key, v)
    return Result(f"Set {key} to {v}.", f"Updated {key.replace('_', ' ')}: {v}")


# =========================================================================== INTERNAL (automations)
@tool("rollover", "Move unconfirmed sessions from earlier days out of the way so they can be re-planned.",
      expose=False)
def _h_rollover():
    n = planner.rollover(clock.now())
    return Result(f"{n} unfinished session(s) from earlier days were rolled forward." if n else "Nothing to roll over.",
                  f"Rolled {fmt.plural(n, 'unfinished session')} forward" if n else "")


@tool("focus_start", "Start the focus timer on a task.", {"task": _s("Task id."), "block_id": _i("Optional session id.")},
      required=["task"], expose=False)
def _h_focus_start(task, block_id=None):
    t = T.find_task(task)
    focus.start(t["id"], int(block_id) if block_id else None)
    return Result(f"Focusing on {_short_task(t)}.", f"Started focus on {_short_task(t)}")


@tool("focus_stop", "Stop the focus timer and log the time.", {"complete": _b("Also mark the task finished.")},
      expose=False)
def _h_focus_stop(complete=False):
    out = focus.stop(bool(complete))
    msg = f"Logged {fmt.duration(out['minutes'])} on {_short_task(out['task'])}"
    if out["finished"]:
        msg += " and finished it"
    return Result(msg + ".", msg)


@tool("session_done", "Mark one scheduled session done.",
      {"block_id": _i("Session id."), "actual_minutes": _i("How long it really took."),
       "finished": _b("Whether the whole task is now complete.")}, required=["block_id"], expose=False)
def _h_session_done(block_id, actual_minutes=None, finished=None):
    out = planner.complete_block(int(block_id), actual_minutes, finished)
    t = out["task"]
    bits = [f"Logged {_short_task(t)}"]
    if out["finished"]:
        bits.append("finished")
    elif out["left"]:
        bits.append(f"about {fmt.duration(out['left'])} left")
    if out["overrun"] >= 10:
        bits.append(f"ran {fmt.duration(out['overrun'])} over, re-planned the rest of today")
    text = ", ".join(bits)
    return Result(text + (("\n" + out["replanned"].text()) if out["replanned"] else ""), text)


@tool("session_missed", "Mark one scheduled session as missed or skipped and re-plan.",
      {"block_id": _i("Session id."), "skipped": _b("True if it was a choice rather than a miss.")},
      required=["block_id"], expose=False)
def _h_session_missed(block_id, skipped=False):
    out = planner.miss_block(int(block_id), status="skipped" if skipped else "missed")
    t = db.get("tasks", out["block"]["task_id"])
    return Result(f"{'Skipped' if skipped else 'Missed'} session for {_short_task(t)}; re-planned.\n" + out["replanned"].text(),
                  f"{'Skipped' if skipped else 'Missed'} {_short_task(t)}, re-planned the day")
