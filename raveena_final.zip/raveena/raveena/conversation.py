"""The running conversation, stored locally so Raveena picks up where you left off."""
from __future__ import annotations

from . import clock, db


def add(role: str, content: str, meta: dict | None = None) -> int:
    return db.run("INSERT INTO messages (ts,role,content,meta) VALUES (?,?,?,?)",
                  (clock.iso(), role, content, db.dumps(meta or {})))


def recent(limit: int = 60) -> list[dict]:
    rows = db.rows("SELECT * FROM messages ORDER BY id DESC LIMIT ?", (limit,))[::-1]
    for r in rows:
        r["meta"] = db.loads(r["meta"], {})
    return rows


def count() -> int:
    return int(db.scalar("SELECT COUNT(*) FROM messages", default=0))


def last_assistant_turn() -> str | None:
    r = db.row("SELECT meta FROM messages WHERE role='assistant' ORDER BY id DESC LIMIT 1")
    return (db.loads(r["meta"], {}) or {}).get("turn") if r else None


def history_for_model(limit: int = 24) -> list[dict]:
    """Recent turns as the model expects them: alternating roles, starting with the user."""
    out: list[dict] = []
    for m in recent(limit):
        if m["role"] not in ("user", "assistant") or not m["content"].strip():
            continue
        if m["meta"].get("kind") == "note":          # UI-only notices are not part of the dialogue
            continue
        if out and out[-1]["role"] == m["role"]:
            out[-1]["content"] += "\n\n" + m["content"]
        else:
            out.append({"role": m["role"], "content": m["content"]})
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out


def clear() -> None:
    db.run("DELETE FROM messages")
