"""Paths, environment variables and model choices.

Everything Raveena stores lives in ``data/`` next to the app (one SQLite file),
so backing up or moving your assistant means copying that folder.
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = ROOT / ".env"


def _load_dotenv(path: Path) -> None:
    """Tiny .env reader (no extra dependency). Real environment variables win."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))


_load_dotenv(ENV_FILE)

DATA_DIR = Path(os.environ.get("RAVEENA_DATA_DIR") or "data").expanduser()
if not DATA_DIR.is_absolute():
    DATA_DIR = ROOT / DATA_DIR
DB_PATH = DATA_DIR / "raveena.db"
CACHE_DIR = DATA_DIR / "cache"

# Model IDs: https://ai.google.dev/gemini-api/docs/models
# The "-latest" aliases always point at Google's current Flash models, so they keep working when Google
# retires an older version (which is what causes "I couldn't find that model").
DEFAULT_MODEL = os.environ.get("RAVEENA_MODEL", "gemini-flash-latest")
MODEL_CHOICES = {
    "gemini-flash-latest": "Gemini Flash (latest), balanced and free (recommended)",
    "gemini-flash-lite-latest": "Gemini Flash-Lite (latest), fastest, highest free limits",
    "gemini-2.5-flash": "Gemini 2.5 Flash (older, may be retired)",
}
# How much the model thinks before answering (mapped to Gemini's thinking budget).
EFFORT_CHOICES = {"low": "Quick", "medium": "Balanced", "high": "Thoughtful"}

# Optional passcode gate (set RAVEENA_PASSCODE if you ever host this somewhere reachable).
PASSCODE = os.environ.get("RAVEENA_PASSCODE", "")

_runtime_key: str | None = None


def api_key() -> str | None:
    """The Gemini API key, from this session, the environment or .env."""
    return (_runtime_key or os.environ.get("GEMINI_API_KEY")
            or os.environ.get("GOOGLE_API_KEY") or None)


def set_api_key(key: str | None) -> None:
    global _runtime_key
    _runtime_key = (key or "").strip() or None


def save_api_key_to_env(key: str) -> Path:
    """Persist the key in ``.env`` (plain text, owner-only permissions)."""
    key = key.strip()
    lines: list[str] = []
    if ENV_FILE.exists():
        lines = [ln for ln in ENV_FILE.read_text(encoding="utf-8").splitlines()
                 if not ln.startswith("GEMINI_API_KEY=")]
    lines.append(f"GEMINI_API_KEY={key}")
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        ENV_FILE.chmod(0o600)
    except OSError:
        pass
    os.environ["GEMINI_API_KEY"] = key
    return ENV_FILE
