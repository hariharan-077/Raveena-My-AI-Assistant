"""First run: a short, human introduction instead of a settings form."""
from __future__ import annotations

from datetime import time as dtime

import streamlit as st

from .. import clock, config, conversation, memory, settings
from .. import tasks as T
from . import avatar

PEAKS = {
    "Early morning": ("06:30", "09:30"),
    "Morning": ("09:00", "12:00"),
    "Afternoon": ("13:00", "16:00"),
    "Evening": ("17:00", "20:00"),
    "Late night": ("20:00", "23:00"),
}
TONES = {"Warm and gentle": "warm", "Direct, like a coach": "coach", "Brief and to the point": "concise"}


def _m(t: dtime) -> int:
    return t.hour * 60 + t.minute


def _finish(name: str, wake: dtime, sleep: dtime, focus: str, goals: str, tone: str, key: str, save_key: bool) -> None:
    w, s = _m(wake), _m(sleep)
    day_start = max(w + 60, 6 * 60) if w < 20 * 60 else 8 * 60
    day_end = min(s - 60, 23 * 60) if s > w else 23 * 60
    if day_end - day_start < 6 * 60:
        day_start, day_end = 8 * 60, 22 * 60
    ps, pe = (clock.hm_to_min(x) for x in PEAKS[focus])
    ps, pe = max(ps, day_start), min(pe, day_end)
    if pe - ps < 60:
        ps, pe = day_start, min(day_start + 180, day_end)
    settings.update({
        "name": name.strip(), "wake_time": wake.strftime("%H:%M"), "sleep_time": sleep.strftime("%H:%M"),
        "day_start": clock.min_to_hm(day_start), "day_end": clock.min_to_hm(day_end),
        "peak_start": clock.min_to_hm(ps), "peak_end": clock.min_to_hm(pe), "tone": TONES[tone], "onboarded": True,
    })
    for line in [g.strip() for g in goals.splitlines() if g.strip()][:5]:
        T.add_goal(line)
        memory.remember(f"Is working toward: {line}", "goal", 4, source="user")
    if key.strip():
        config.set_api_key(key)
        if save_key:
            config.save_api_key_to_env(key)
    welcome = (f"Hi {name.strip()}, I'm Raveena. I'll keep track of your tasks, plan your days around your routines, "
               "log your habits and listen when you want to talk. I'll remember what matters so you never have to "
               "repeat yourself.\n\nA good first step: tell me about your week, like classes, work hours or the gym, "
               "and I'll plan around them. Or just tell me what's on your mind.")
    if not config.api_key():
        welcome += ("\n\n*I'm in Lite mode for now, so I follow simple commands. Add your Gemini API key in "
                    "Settings and we can talk naturally.*")
    conversation.add("assistant", welcome, {"kind": "welcome"})


def render() -> None:
    _, mid, _ = st.columns([1, 1.7, 1])
    with mid:
        st.html(f'<div class="hello" style="padding-top:2.2rem">{avatar.orb_html(clock.now().hour, 72)}'
                "<h2>Hi, I'm Raveena.</h2>"
                "<p>I'll help you plan your days, keep track of what matters, and listen when you need to talk. "
                "Everything stays on this computer. Let's set a few things up, and you can change any of it later.</p></div>")
        with st.form("onboarding", border=True):
            name = st.text_input("What should I call you?", placeholder="Your first name")
            c1, c2 = st.columns(2)
            wake = c1.time_input("You usually wake up around", value=dtime(7, 0), step=900)
            sleep = c2.time_input("and go to sleep around", value=dtime(23, 0), step=900)
            focus = st.radio("When does your head feel clearest?", list(PEAKS), index=1, horizontal=True,
                             help="I'll save your hardest tasks for these hours.")
            goals = st.text_area("What are you working toward right now?", height=96,
                                 placeholder="One per line, for example:\nPass my networking exam in December\nRun a 10k",
                                 help="Optional. I'll remember these and weigh your tasks against them.")
            tone = st.radio("How should I talk to you?", list(TONES), horizontal=True)
            with st.expander("Connect Gemini for natural conversation (optional)"):
                st.caption("Without a key I still work, in a simpler Lite mode. With one, you can just talk to me. "
                           "Your key stays on this computer.")
                key = st.text_input("Gemini API key", type="password", placeholder="AIza…")
                save_key = st.checkbox("Remember it on this computer (saved in a local .env file)", value=True)
            go = st.form_submit_button("Start with Raveena", type="primary", use_container_width=True)
        if go:
            if not name.strip():
                st.error("I'd love to know what to call you.")
            else:
                _finish(name, wake, sleep, focus, goals, tone, key, save_key)
                st.rerun()
