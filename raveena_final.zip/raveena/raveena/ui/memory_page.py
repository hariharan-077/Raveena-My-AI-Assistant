"""Memory: everything Raveena knows about you, visible and editable."""
from __future__ import annotations

import streamlit as st

from .. import memory
from . import common
from .components import empty, esc, page_head, section


@st.dialog("Edit memory")
def _edit(mid: int) -> None:
    m = memory.get(mid)
    if not m:
        return
    text = st.text_area("What I remember", value=m["content"], height=100)
    cats = list(memory.CATEGORIES)
    c1, c2 = st.columns(2)
    cat = c1.selectbox("Kind", cats, index=cats.index(m["category"]) if m["category"] in cats else 0,
                       format_func=lambda k: memory.CATEGORIES[k])
    imp = c2.slider("How important is it?", 1, 5, int(m["importance"]))
    if st.button("Save", type="primary", use_container_width=True):
        try:
            memory.update(mid, content=text, category=cat, importance=imp)
            st.rerun()
        except Exception as e:                                  # noqa: BLE001
            st.error(str(e))


@st.dialog("Forget this?")
def _forget(mid: int, content: str) -> None:
    st.write(f"I'll forget: “{content}”")
    c1, c2 = st.columns(2)
    if c1.button("Forget it", type="primary", use_container_width=True):
        common.run("forget", memory=str(mid))
        st.rerun()
    if c2.button("Keep it", use_container_width=True):
        st.rerun()


def render() -> None:
    total = len(memory.list_all())
    common.html(page_head("What I remember", "Everything here lives on this computer. Edit or remove anything, any time. "
                          "I use it to stop you having to explain yourself twice."
                          + (f" Right now that's {total} thing{'s' if total != 1 else ''}." if total else "")))
    with st.expander("Teach me something", expanded=not total):
        with st.form("teach", clear_on_submit=True, border=False):
            text = st.text_input("Tell me in a sentence", placeholder="I focus best with lo-fi music on")
            c1, c2 = st.columns(2)
            cat = c1.selectbox("Kind", list(memory.CATEGORIES), index=list(memory.CATEGORIES).index("preference"),
                               format_func=lambda k: memory.CATEGORIES[k])
            imp = c2.slider("How important is it?", 1, 5, 3)
            if st.form_submit_button("Remember it", type="primary"):
                out = common.run("remember", content=text, category=cat, importance=imp, explicit=True)
                if out.ok:
                    st.rerun()
    if not total:
        common.html(empty("Nothing yet. As we talk, I'll save the things worth remembering, like goals, what works for you "
                          "and who matters. You'll always see them here first."))
    for key, label in memory.CATEGORIES.items():
        items = memory.list_all(key)
        if not items:
            continue
        common.html(section(label, str(len(items))))
        for m in items:
            with st.container(key=f"row-mem-{m['id']}"):
                a, b, c = st.columns([8, 0.8, 0.8], vertical_alignment="center")
                src = "" if m["source"] == "user" else "<small>noticed by Raveena</small>"
                common.html(f'<div class="mem">{esc(m["content"])}{src}</div>', a)
                if b.button("", icon=":material/edit:", key=f"me-{m['id']}", type="tertiary", help="Edit"):
                    _edit(m["id"])
                if c.button("", icon=":material/delete:", key=f"md-{m['id']}", type="tertiary", help="Forget"):
                    _forget(m["id"], m["content"])
