"""Helpers shared by every page."""
from __future__ import annotations

import streamlit as st

from .. import actions, clock, settings, tools
from . import avatar
from .components import esc
from .icons import svg

PAGES: dict[str, object] = {}          # filled in by app.py: key -> st.Page


def html(content: str, target=None) -> None:
    """Render HTML, including inline SVG, into ``target`` (default: the current container).

    ``st.html`` strips <svg>, so this goes through markdown's raw-HTML path. The wrapping <div> makes the
    whole thing one HTML block, so markdown never rewrites the text inside it.
    """
    (target if target is not None else st).markdown(f'<div class="raw">{content}</div>', unsafe_allow_html=True)


def goto(key: str) -> None:
    page = PAGES.get(key)
    if page is not None:
        st.switch_page(page)


def queue_prompt(text: str) -> None:
    """Send something to Raveena as if you'd typed it, then jump to the chat."""
    st.session_state["queued_prompt"] = text
    goto("chat")


def assistant_avatar() -> str:
    return avatar.orb_png(clock.now().hour)


def user_avatar() -> str:
    return avatar.initial_png((settings.get("name") or "?")[:1])


def run(name: str, *, quiet: bool = False, **args) -> tools.Outcome:
    """Run a tool on your behalf from a button. Shows what happened and offers Undo."""
    out = tools.execute(name, args, source="ui", confirmed=True)
    if not quiet:
        if out.ok and not out.silent:
            st.session_state["last_ui_action"] = {"id": out.action_id, "summary": out.summary}
            st.toast(out.summary or "Done", icon=":material/check:")
        elif not out.ok:
            st.toast(out.text, icon=":material/error:")
    return out


def undo_banner() -> None:
    """After a one-click change (replan, delete...), show what happened with an Undo button."""
    note = st.session_state.get("last_ui_action")
    if not note or not note.get("id"):
        return
    a = actions.get(note["id"])
    if not a or not a["can_undo"]:
        st.session_state.pop("last_ui_action", None)
        return
    c1, c2, c3 = st.columns([8, 1.6, 0.7], vertical_alignment="center")
    with c1:
        html(f'<span class="receipt">{svg("check", 14)}{esc(note["summary"])}</span>')
    if c2.button("Undo", icon=":material/undo:", key="undo_banner"):
        actions.undo(note["id"])
        st.session_state.pop("last_ui_action", None)
        st.toast("Undone", icon=":material/undo:")
        st.rerun()
    if c3.button("", icon=":material/close:", key="dismiss_banner", type="tertiary", help="Dismiss"):
        st.session_state.pop("last_ui_action", None)
        st.rerun()
