"""Raveena's look.

Idea: a day that breathes. One memorable element (the orb whose light follows the time of day),
her voice set in a serif like a personal note, and a quiet sans interface everywhere else.
Surfaces are flat with hairlines instead of identical shadowed cards; colour is reserved for meaning
(peacock = actions, marigold = "now", rose = needs attention).
"""
from __future__ import annotations

from string import Template

import streamlit as st

LIGHT = dict(
    fog="#EEF1F7", paper="#FFFFFF", paper2="#F6F8FC", ink="#18213A", slate="#586480", faint="#8791AB",
    line="#DCE1EC", line2="#E8ECF4", peacock="#0F7C8C", peacockink="#0A5C69", peacockwash="#E2F1F3",
    marigold="#F2A33A", marigoldwash="#FDF1DD", marigoldink="#7A4B05", rose="#D9496A", rosewash="#FBE9EE",
    good="#2E8F6B", shadow="rgba(24,33,58,.10)", onpeacock="#FFFFFF",
)
DARK = dict(
    fog="#0F1426", paper="#171E36", paper2="#1D2542", ink="#E8ECF8", slate="#A3ADCD", faint="#7681A8",
    line="#2B3560", line2="#232C52", peacock="#4CC3D3", peacockink="#8FDCE6", peacockwash="#143743",
    marigold="#F6B25C", marigoldwash="#3A2E1A", marigoldink="#F6C98A", rose="#F0728D", rosewash="#3D1F2B",
    good="#5CC9A0", shadow="rgba(0,0,0,.45)", onpeacock="#07202A",
)

CATEGORY_COLORS = {
    "Study": "#5667D9", "Work": "#0E8A9A", "Health": "#2F9E6E", "Personal": "#D9822B",
    "Creative": "#C0508A", "General": "#7A869E", "Routine": "#9AA3BD", "Event": "#586480",
}


def category_color(cat: str) -> str:
    return CATEGORY_COLORS.get(cat, CATEGORY_COLORS["General"])


def theme_type() -> str:
    try:
        t = st.context.theme.type
    except Exception:                              # older Streamlit, or not known yet
        t = None
    return t if t in ("light", "dark") else "light"


_CSS = Template(r"""
@import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&display=swap');

:root {
  --fog:$fog; --paper:$paper; --paper2:$paper2; --ink:$ink; --slate:$slate; --faint:$faint;
  --line:$line; --line2:$line2; --peacock:$peacock; --peacock-ink:$peacockink; --peacock-wash:$peacockwash;
  --marigold:$marigold; --marigold-wash:$marigoldwash; --marigold-ink:$marigoldink;
  --rose:$rose; --rose-wash:$rosewash; --good:$good; --shadow:$shadow; --on-peacock:$onpeacock;
  --serif:"Newsreader","Iowan Old Style","Palatino Linotype",Palatino,Georgia,serif;
  --sans:"Figtree",system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
}

/* ---------- base ---------- */
html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"] {
  background: var(--fog) !important; color: var(--ink); font-family: var(--sans);
}
.stApp { font-size: 15px; -webkit-font-smoothing: antialiased; }
[data-testid="stHeader"] { background: transparent !important; height: 2.6rem; }
[data-testid="stDecoration"], footer, [data-testid="stStatusWidget"] { display: none !important; }
[data-testid="stMainBlockContainer"] { max-width: 1280px; padding: 2.4rem 2.4rem 7rem; }
p, li, label, span, div { font-family: inherit; }
h1, h2, h3, h4 { font-family: var(--serif) !important; font-weight: 500 !important; letter-spacing: -0.012em;
  color: var(--ink) !important; }
h2 { font-size: 1.55rem !important; margin-top: 1.4rem !important; }
h3 { font-size: 1.22rem !important; }
a { color: var(--peacock-ink); }
hr { border-color: var(--line) !important; opacity: 1; }
::selection { background: var(--peacock-wash); }
*:focus-visible { outline: 2px solid var(--peacock) !important; outline-offset: 2px; }
[data-testid="stCaptionContainer"], .stCaption, small { color: var(--slate) !important; }

/* ---------- sidebar ---------- */
[data-testid="stSidebar"] { background: var(--paper) !important; border-right: 1px solid var(--line); }
[data-testid="stSidebar"] [data-testid="stSidebarContent"] { padding-top: .4rem; }
[data-testid="stSidebarHeader"] { display: none; }
[data-testid="stSidebarUserContent"] { padding: 1.4rem 1rem 1rem !important; }
[data-testid="stSidebar"] [data-testid="stPageLink-NavLink"] {
  border-radius: 10px; padding: .5rem .75rem; color: var(--slate); font-weight: 500; text-decoration: none; gap: .7rem;
}
[data-testid="stSidebar"] [data-testid="stPageLink-NavLink"]:hover { background: var(--paper2); color: var(--ink); }
[data-testid="stSidebar"] [data-testid="stPageLink-NavLink"][aria-current="page"] {
  background: var(--peacock-wash); color: var(--peacock-ink); font-weight: 600;
}
[data-testid="stSidebar"] [data-testid="stPageLink-NavLink"] p { font-size: .95rem; }

.brand { display: flex; align-items: center; gap: .8rem; margin: .2rem 0 1.5rem .25rem; }
.brand .name { font: 500 1.55rem/1 var(--serif); letter-spacing: -0.01em; color: var(--ink); }
.brand .sub { font-size: .8rem; color: var(--slate); margin-top: .22rem; }
.side-foot { margin: 1.6rem .3rem 0; font-size: .82rem; color: var(--slate); line-height: 1.45; }
.side-foot b { color: var(--ink); font-weight: 600; }
.dot { display: inline-block; width: .5rem; height: .5rem; border-radius: 50%; background: var(--good); margin-right: .4rem; }
.dot.off { background: var(--marigold); }

/* ---------- the orb ---------- */
.orb { display: inline-block; flex: none; width: var(--sz,44px); height: var(--sz,44px); border-radius: 50%; position: relative;
  background: radial-gradient(circle at 33% 29%, var(--o1) 0%, var(--o2) 48%, var(--o3) 100%);
  box-shadow: 0 0 0 1px rgba(255,255,255,.35) inset, 0 8px 26px -4px var(--glow);
  animation: breathe 6s ease-in-out infinite; }
.orb::after { content:""; position:absolute; inset: 13% 46% 58% 15%; border-radius: 50%;
  background: rgba(255,255,255,.62); filter: blur(4px); }
.orb.is-thinking { animation-duration: 1.7s; }
@keyframes breathe { 0%,100% { transform: scale(1); } 50% { transform: scale(1.055); } }
@media (prefers-reduced-motion: reduce) { .orb { animation: none; } }

/* ---------- page header ---------- */
.page-head { margin: .2rem 0 1.5rem; }
.page-head h1 { font: 500 2.4rem/1.08 var(--serif) !important; letter-spacing: -0.018em; margin: 0; padding: 0; color: var(--ink); }
.page-head p { color: var(--slate); font-size: 1.04rem; line-height: 1.5; margin: .55rem 0 0; max-width: 44rem; }
.presence { display: flex; align-items: center; gap: 1rem; margin: .1rem 0 1.1rem; }
.presence h1 { font: 500 1.9rem/1.1 var(--serif) !important; letter-spacing: -0.014em; margin: 0; padding: 0; }
.presence .status { font-size: .86rem; color: var(--slate); margin-top: .2rem; }

/* ---------- buttons ---------- */
button[data-testid^="stBaseButton"] { font-family: var(--sans); font-weight: 500; border-radius: 10px; min-height: 2.3rem;
  box-shadow: none !important; transition: none; }
button[data-testid="stBaseButton-secondary"], button[data-testid="stBaseButton-secondaryFormSubmit"] {
  background: var(--paper); color: var(--ink); border: 1px solid var(--line); }
button[data-testid="stBaseButton-secondary"]:hover, button[data-testid="stBaseButton-secondaryFormSubmit"]:hover {
  border-color: var(--peacock); color: var(--peacock-ink); background: var(--paper); }
button[data-testid="stBaseButton-primary"], button[data-testid="stBaseButton-primaryFormSubmit"] {
  background: var(--peacock); color: var(--on-peacock); border: 1px solid var(--peacock); }
button[data-testid="stBaseButton-primary"]:hover, button[data-testid="stBaseButton-primaryFormSubmit"]:hover {
  background: var(--peacock-ink); border-color: var(--peacock-ink); color: var(--on-peacock); }
button[data-testid="stBaseButton-tertiary"] { background: transparent; border: none; color: var(--slate); }
button[data-testid="stBaseButton-tertiary"]:hover { color: var(--peacock-ink); background: var(--paper2); }
button[data-testid^="stBaseButton"] p { font-size: .9rem; }
button:disabled { opacity: .45; }

/* ---------- inputs ---------- */
[data-testid="stTextInputRootElement"], [data-testid="stNumberInputContainer"], [data-testid="stTextAreaRootElement"],
[data-testid="stDateInputField"], [data-testid="stTimeInputTimeDisplay"],
[data-baseweb="select"] > div, [data-baseweb="input"] > div, [data-baseweb="textarea"] {
  background: var(--paper) !important; border: 1px solid var(--line) !important; border-radius: 10px !important; }
[data-testid="stTextInputRootElement"]:focus-within, [data-testid="stNumberInputContainer"]:focus-within,
[data-testid="stTextAreaRootElement"]:focus-within, [data-testid="stDateInputField"]:focus-within,
[data-testid="stTimeInputTimeDisplay"]:focus-within, [data-baseweb="select"]:focus-within > div { border-color: var(--peacock) !important; }
[data-testid="stForm"] :is([data-testid="stTextInputRootElement"], [data-testid="stNumberInputContainer"], [data-testid="stTextAreaRootElement"],
  [data-testid="stDateInputField"], [data-testid="stTimeInputTimeDisplay"], [data-baseweb="select"] > div),
[data-testid="stDialog"] :is([data-testid="stTextInputRootElement"], [data-testid="stNumberInputContainer"], [data-testid="stTextAreaRootElement"],
  [data-testid="stDateInputField"], [data-testid="stTimeInputTimeDisplay"], [data-baseweb="select"] > div) { background: var(--paper2) !important; }
input, textarea { color: var(--ink) !important; font-family: var(--sans) !important; }
[data-testid="stWidgetLabel"] p, label p { font-size: .88rem; color: var(--slate); font-weight: 500; }
[data-testid="stWidgetLabel"] { margin-bottom: .1rem; }
[data-baseweb="popover"] [role="listbox"], [data-baseweb="menu"] { background: var(--paper) !important; border-radius: 10px; }
[data-testid="stCheckbox"] label span { color: var(--ink); }

/* ---------- segmented control / pills / tabs ---------- */
[data-testid="stSegmentedControl"] button, [data-testid="stPills"] button { border-radius: 999px !important; }
button[data-baseweb="tab"] { font-family: var(--sans); font-weight: 500; color: var(--slate); padding: .5rem .2rem; margin-right: 1.4rem; }
button[data-baseweb="tab"][aria-selected="true"] { color: var(--ink); }
[data-baseweb="tab-highlight"] { background: var(--peacock) !important; height: 2px !important; }
[data-baseweb="tab-border"] { background: var(--line) !important; }

/* ---------- chat ---------- */
[data-testid="stChatMessage"] { background: transparent !important; padding: .4rem 0 !important; gap: .95rem !important; align-items: flex-start; }
[data-testid="stChatMessage"] > img { width: 2.1rem; height: 2.1rem; border-radius: 50%; flex: none; margin-top: .15rem; }
[data-testid="stChatMessage"] [data-testid="stChatMessageContent"][aria-label="Chat message from assistant"] {
  font-family: var(--serif); font-size: 1.14rem; line-height: 1.62; color: var(--ink); }
[data-testid="stChatMessage"] [data-testid="stChatMessageContent"][aria-label="Chat message from assistant"] :is(p, li) {
  font-family: var(--serif); font-size: inherit; line-height: inherit; }
[data-testid="stChatMessage"]:has([aria-label="Chat message from user"]) { flex-direction: row-reverse; }
[data-testid="stChatMessage"]:has([aria-label="Chat message from user"]) > img { display: none; }
[data-testid="stChatMessage"] [data-testid="stChatMessageContent"][aria-label="Chat message from user"] {
  background: var(--peacock-wash); color: var(--ink); padding: .6rem 1.05rem !important; border-radius: 18px 18px 5px 18px;
  max-width: min(82%, 34rem); width: fit-content; font-size: 1rem; flex: 0 1 auto; margin: 0 0 0 auto !important; }
[data-testid="stChatMessageContent"][aria-label="Chat message from user"] [data-testid="stMarkdownContainer"] { margin-bottom: 0 !important; }
[data-testid="stChatMessageContent"][aria-label="Chat message from user"] p { margin: 0 !important; line-height: 1.5; }
[data-testid="stChatMessageContent"] p:last-child { margin-bottom: 0; }
[data-testid="stChatMessageContent"] em { color: var(--slate); }
[data-testid="stBottom"], [data-testid="stBottomBlockContainer"] { background: var(--fog) !important; }
[data-testid="stBottomBlockContainer"] { max-width: 1280px; padding-left: 2.4rem !important; padding-right: 2.4rem !important; }
[data-testid="stMarkdownContainer"]:has(> .raw) { margin-bottom: 0 !important; }
[data-testid="stChatInput"] { background: var(--paper) !important; border: 1px solid var(--line) !important; border-radius: 28px !important;
  box-shadow: 0 10px 30px -12px var(--shadow); }
[data-testid="stChatInput"] textarea { font-family: var(--sans) !important; font-size: 1rem; }
[data-testid="stChatInput"] textarea:focus-visible, [data-testid="stChatInput"] :focus-visible { outline: none !important; }
[data-testid="stChatInput"] [data-baseweb="textarea"], [data-testid="stChatInput"] [data-baseweb="base-input"] { border-radius: 26px !important; border-color: transparent !important; background: transparent !important; }
[data-testid="stChatInput"] button { background: var(--peacock) !important; color: var(--on-peacock) !important; border-radius: 50% !important; }
[data-testid="stChatInput"]:focus-within { border-color: var(--peacock) !important; }

.receipts { display: flex; flex-wrap: wrap; gap: .4rem; margin: .5rem 0 .1rem; font-family: var(--sans); }
.receipt { display: inline-flex; align-items: center; gap: .4rem; font: 500 .8rem/1.2 var(--sans); color: var(--slate);
  background: var(--paper); border: 1px solid var(--line); border-radius: 999px; padding: .26rem .7rem .26rem .55rem; }
.receipt .ico { color: var(--peacock); flex: none; }
.receipt.pending { border-color: var(--marigold); background: var(--marigold-wash); color: var(--marigold-ink); }
.receipt.pending .ico { color: var(--marigold); }
.receipt.failed { border-color: var(--rose); background: var(--rose-wash); color: var(--rose); }
.receipt.failed .ico { color: var(--rose); }
.receipt.muted { background: transparent; color: var(--faint); text-decoration: line-through; }
.receipt.muted .ico { color: var(--faint); }

.hello { text-align: center; padding: 3.2rem 1rem 1.4rem; }
.hello .orb { margin-bottom: 1.1rem; }
.hello h2 { font: 500 2.1rem/1.15 var(--serif) !important; margin: 0 0 .5rem !important; letter-spacing: -0.016em; }
.hello p { color: var(--slate); max-width: 30rem; margin: 0 auto; line-height: 1.55; }

/* ---------- app-style panes (chat page) ----------
   The chat page never scrolls as a whole: the thread and the day panel scroll on their own.
   Streamlit gives fixed-height containers a wrapper with a fixed flex-basis, so resize the wrapper. */
[data-testid="stAppScrollToBottomContainer"]:has(.st-key-thread) { overflow: hidden !important; }
[data-testid="stMainBlockContainer"]:has(.st-key-thread) { padding-bottom: 0 !important; }
[data-testid="stLayoutWrapper"]:has(> .st-key-thread) { flex: 0 0 calc(100vh - 15.9rem) !important; height: calc(100vh - 15.9rem) !important; min-height: 300px; }
[data-testid="stLayoutWrapper"]:has(> .st-key-rail-wrap) { flex: 0 0 calc(100vh - 11rem) !important; height: calc(100vh - 11rem) !important; min-height: 380px; }
.st-key-thread { padding-right: .6rem; }
.st-key-rail-wrap { padding: 0 .4rem 1rem .2rem; }
.st-key-thread, .st-key-rail-wrap { scrollbar-width: thin; scrollbar-color: var(--line) transparent; }
@media (max-width: 900px) {
  [data-testid="stLayoutWrapper"]:has(> .st-key-thread), [data-testid="stLayoutWrapper"]:has(> .st-key-rail-wrap) { flex: 0 0 auto !important; height: auto !important; }
}

/* ---------- containers & rows ---------- */
[data-testid="stVerticalBlockBorderWrapper"]:has(> div > [data-testid="stVerticalBlock"]) { border-color: var(--line); }
div[class*="st-key-panel"] { background: var(--paper); border: 1px solid var(--line); border-radius: 16px; padding: 1.1rem 1.25rem; }
div[class*="st-key-row-"] { border-bottom: 1px solid var(--line2); padding: .5rem 0; gap: .35rem; }
div[class*="st-key-row-"]:last-child { border-bottom: none; }
div[class*="st-key-quiet"] { background: transparent; }
[data-testid="stExpander"] { border: 1px solid var(--line) !important; border-radius: 12px !important; background: var(--paper); }
[data-testid="stExpander"] summary { font-weight: 500; }
[data-testid="stForm"] { border: 1px solid var(--line) !important; border-radius: 14px !important; background: var(--paper); padding: 1.1rem 1.2rem; }
[data-testid="stAlert"] { border-radius: 12px; }
[data-testid="stToast"] { border-radius: 12px; }
[data-testid="stProgress"] > div > div { background: var(--line2) !important; }
[data-testid="stProgress"] > div > div > div { background: var(--peacock) !important; }
[data-testid="stMetric"] { background: transparent; }
[data-testid="stDataFrame"] { border: 1px solid var(--line); border-radius: 12px; }

.h-section { font: 500 1.28rem/1.2 var(--serif); letter-spacing: -0.01em; margin: 1.5rem 0 .5rem; color: var(--ink); }
.h-section small { font: 400 .88rem var(--sans); color: var(--slate); margin-left: .5rem; }
.muted { color: var(--slate); }
.note { color: var(--slate); font-size: .9rem; line-height: 1.5; }
.empty { color: var(--slate); padding: 1.1rem .1rem; font-size: .98rem; line-height: 1.55; }
.empty b { color: var(--ink); font-weight: 600; }

/* ---------- agenda ---------- */
.time { font: 600 .92rem/1.2 var(--sans); color: var(--ink); font-variant-numeric: tabular-nums; }
.time small { display: block; font-weight: 400; font-size: .76rem; color: var(--faint); margin-top: .1rem; }
.fixed-row { display: flex; gap: 1rem; align-items: baseline; color: var(--slate); font-size: .94rem; padding: .15rem 0; }
.fixed-row .time { color: var(--slate); font-weight: 500; min-width: 4.6rem; }
.gap-row { margin: .1rem 0; padding: .35rem .8rem; border: 1px dashed var(--line); border-radius: 10px; color: var(--faint); font-size: .85rem; }
.heads { display: flex; gap: .6rem; align-items: flex-start; background: var(--rose-wash); color: var(--rose); border-radius: 12px; padding: .6rem .9rem; margin: 0 0 .5rem; font-size: .94rem; line-height: 1.45; }
.heads .ico { flex: none; margin-top: .15rem; }
.heads b { color: var(--ink); font-weight: 600; }
.timer { font: 500 2.6rem/1 var(--serif); letter-spacing: -0.01em; color: var(--ink); font-variant-numeric: tabular-nums; margin: .2rem 0 .7rem; }

/* ---------- chips ---------- */
.chip { display: inline-flex; align-items: center; gap: .3rem; font: 500 .76rem/1 var(--sans); padding: .26rem .6rem; border-radius: 999px;
  background: var(--paper2); color: var(--slate); border: 1px solid var(--line2); white-space: nowrap; }
.chip.warn { background: var(--rose-wash); color: var(--rose); border-color: transparent; }
.chip.ok { background: var(--peacock-wash); color: var(--peacock-ink); border-color: transparent; }
.chip.now { background: var(--marigold-wash); color: var(--marigold-ink); border-color: transparent; }
.chip.cat { background: color-mix(in srgb, var(--c) 13%, var(--paper)); color: color-mix(in srgb, var(--c) 78%, var(--ink)); border-color: transparent; }
.chip .ico { opacity: .85; }
.chips { display: flex; flex-wrap: wrap; gap: .35rem; margin-top: .3rem; }
.title-line { font-weight: 600; font-size: 1rem; color: var(--ink); line-height: 1.3; }
.title-line.done { color: var(--faint); text-decoration: line-through; text-decoration-color: var(--line); }

/* ---------- day rail & week grid ---------- */
.rail { position: relative; margin: .2rem 0 .4rem 3.1rem; border-left: 1px solid var(--line); }
.rail-hour { position: absolute; left: -3.1rem; width: 2.5rem; text-align: right; white-space: nowrap; font: 500 .7rem/1 var(--sans); color: var(--faint);
  font-variant-numeric: tabular-nums; transform: translateY(-50%); }
.rail-grid { position: absolute; left: 0; right: 0; border-top: 1px dashed var(--line2); }
.rail-item { position: absolute; left: .45rem; right: 0; box-sizing: border-box; border-radius: 8px; padding: .12rem .5rem;
  font: 500 .76rem/1.25 var(--sans); overflow: hidden; color: var(--ink); border-left: 3px solid var(--c);
  background: color-mix(in srgb, var(--c) 11%, var(--paper)); }
.rail-item small { display: block; color: var(--slate); font-weight: 400; font-size: .68rem; font-variant-numeric: tabular-nums; }
.rail-item.fixed { background: repeating-linear-gradient(135deg, var(--paper2) 0 6px, var(--line2) 6px 7px); color: var(--slate); border-left-color: var(--faint); }
.rail-item.done { opacity: .55; }
.rail-item.done .t { text-decoration: line-through; }
.rail-item.missed { background: transparent; border: 1px dashed var(--line); border-left: 3px dashed var(--faint); color: var(--faint); }
.rail-item.compact { display: flex; align-items: center; gap: .4rem; padding-top: 0; padding-bottom: 0; white-space: nowrap; }
.rail-item.compact .t { overflow: hidden; text-overflow: ellipsis; }
.rail-item.compact small { display: none; }
.rail-now { position: absolute; left: -5px; right: 0; border-top: 2px solid var(--marigold); z-index: 3; }
.rail-now::before { content: ""; position: absolute; left: -1px; top: -6px; width: 9px; height: 9px; border-radius: 50%; background: var(--marigold); }
.rail-now span { position: absolute; right: 0; top: -1.15rem; font: 600 .68rem var(--sans); color: var(--marigold-ink); background: var(--marigold-wash); padding: .08rem .4rem; border-radius: 6px; }

.week { display: grid; grid-template-columns: 2.6rem repeat(7, minmax(0, 1fr)); gap: 0; font-family: var(--sans); }
.week .col { position: relative; border-left: 1px solid var(--line2); }
.week .col.today { background: color-mix(in srgb, var(--marigold) 7%, transparent); }
.week .head { text-align: center; padding: .4rem 0 .5rem; font-size: .8rem; color: var(--slate); border-left: 1px solid var(--line2); }
.week .head b { display: block; color: var(--ink); font: 500 1.15rem var(--serif); }
.week .head.today b { color: var(--peacock-ink); }
.week .hours { position: relative; }
.week .rail-item { left: 2px; right: 2px; font-size: .68rem; padding: .08rem .3rem; border-left-width: 2px; }
.week .rail-item small { display: none; }

/* ---------- trackers, rings, charts ---------- */
.ring { position: relative; display: inline-block; flex: none; }
.ring .c { position: absolute; inset: 0; display: grid; place-items: center; color: var(--ink); }
.ring svg.bg { transform: rotate(-90deg); }
.dots { display: flex; gap: 3px; align-items: center; margin-top: .35rem; }
.dots i { width: 9px; height: 9px; border-radius: 3px; background: var(--line2); display: block; }
.dots i.on { background: var(--c, var(--peacock)); }
.dots i.part { background: color-mix(in srgb, var(--c, var(--peacock)) 38%, var(--paper)); }
.dots i.today { outline: 1.5px solid var(--ink); outline-offset: 1px; }
.bar { height: 7px; border-radius: 999px; background: var(--line2); overflow: hidden; }
.bar > i { display: block; height: 100%; border-radius: 999px; background: var(--c, var(--peacock)); }
.bar.thin { height: 5px; }
.legend { font-size: .8rem; color: var(--slate); }
svg.chart text { font-family: var(--sans); fill: var(--faint); font-size: 10.5px; }
svg.chart .grid { stroke: var(--line2); stroke-width: 1; }

.trk-ico { width: 2.3rem; height: 2.3rem; border-radius: 50%; display: inline-grid; place-items: center; flex: none;
  background: color-mix(in srgb, var(--c) 14%, var(--paper)); color: var(--c); }

/* ---------- suggestions ---------- */
.sug { padding: .55rem 0 .35rem; }
.sug h4 { font: 500 1.16rem/1.3 var(--serif) !important; margin: 0 0 .2rem !important; padding: 0 !important; letter-spacing: -0.008em; }
.sug p { color: var(--slate); margin: 0; line-height: 1.55; max-width: 46rem; }
.sug .tag { display: inline-block; width: .55rem; height: .55rem; border-radius: 50%; margin-right: .55rem; background: var(--peacock); vertical-align: .12rem; }
.sug .tag.heads-up { background: var(--rose); }
.sug .tag.win { background: var(--good); }
.review { font: 400 1.14rem/1.7 var(--serif); color: var(--ink); max-width: 40rem; }
.review p { margin: 0 0 .9rem; }

.chart-wrap { max-width: 680px; }

/* ---------- memory ---------- */
.mem { font: 400 1.04rem/1.5 var(--serif); color: var(--ink); }
.mem small { font: 400 .78rem var(--sans); color: var(--faint); margin-left: .4rem; }

/* ---------- approval cards ---------- */
.approve { background: var(--marigold-wash); border: 1px solid var(--marigold); border-radius: 14px; padding: .8rem 1rem; color: var(--marigold-ink); font-size: .95rem; }
.approve b { color: var(--ink); }

@media (max-width: 900px) {
  [data-testid="stMainBlockContainer"] { padding: 1rem 1rem 7rem; }
  .page-head h1 { font-size: 1.9rem !important; }
}
""")


def inject() -> None:
    """Add the stylesheet to the page. Call once per run, before anything else."""
    tokens = DARK if theme_type() == "dark" else LIGHT
    st.html(f"<style>{_CSS.substitute(tokens)}</style>")
