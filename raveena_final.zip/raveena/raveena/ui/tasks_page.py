"""Tasks: quick capture, a calm list grouped by when it's due, and your goals."""
from __future__ import annotations

from datetime import date, timedelta

import streamlit as st

from .. import clock, db, fmt, lite, planner
from .. import tasks as T
from . import common
from .components import chip, chips, empty, esc, page_head, section

ORDER = ["Overdue", "Today", "Tomorrow", "This week", "Later", "No date"]
ENERGY = {"auto": "Let Raveena decide", "deep": "Needs deep focus", "light": "Light and easy"}


def _bucket(t: dict, today: date) -> str:
    if not t["due_date"]:
        return "No date"
    d = date.fromisoformat(t["due_date"])
    if d < today:
        return "Overdue"
    if d == today:
        return "Today"
    if d == today + timedelta(days=1):
        return "Tomorrow"
    return "This week" if d <= today + timedelta(days=6) else "Later"


def _next_blocks() -> dict[int, dict]:
    now = clock.now()
    out: dict[int, dict] = {}
    for b in db.rows("SELECT * FROM blocks WHERE status='planned' ORDER BY date, start"):
        if planner._at(b["date"], b["end"]) > now and b["task_id"] not in out:
            out[b["task_id"]] = b
    return out


# --------------------------------------------------------------------------- dialogs
@st.dialog("Edit task", width="large")
def _edit(task_id: int) -> None:
    t = db.get("tasks", task_id)
    if not t:
        st.write("That task is gone.")
        return
    goals = T.list_goals(None)
    title = st.text_input("Title", value=t["title"])
    c1, c2, c3 = st.columns(3)
    cats = list(dict.fromkeys(T.CATEGORIES + [t["category"]]))
    cat = c1.selectbox("Category", cats, index=cats.index(t["category"]))
    prio = c2.selectbox("Priority", [1, 2, 3, 4], index=t["priority"] - 1, format_func=lambda p: T.PRIORITIES[p])
    est = c3.number_input("Estimate (minutes)", min_value=5, max_value=600, value=int(t["est_minutes"]), step=5)
    d1, d2, d3 = st.columns(3)
    has_due = d1.checkbox("Has a deadline", value=bool(t["due_date"]))
    due = d2.date_input("Due", value=date.fromisoformat(t["due_date"]) if t["due_date"] else clock.today(), disabled=not has_due)
    due_time = d3.text_input("Due time (optional)", value=t["due_time"] or "", placeholder="17:00", disabled=not has_due)
    e1, e2 = st.columns(2)
    energy = e1.selectbox("Kind of work", list(ENERGY), index=list(ENERGY).index(t["energy"]), format_func=ENERGY.get)
    goal_opts = [None] + [g["id"] for g in goals]
    goal = e2.selectbox("Goal", goal_opts, index=goal_opts.index(t["goal_id"]) if t["goal_id"] in goal_opts else 0,
                        format_func=lambda gid: "None" if gid is None else next(g["title"] for g in goals if g["id"] == gid))
    notes = st.text_area("Notes", value=t["notes"] or "", height=90)
    b1, b2, b3, _ = st.columns([1.2, 1.2, 1.2, 2])
    if b1.button("Save", type="primary", use_container_width=True):
        out = common.run("update_task", task=str(task_id), title=title, category=cat, priority=prio,
                         est_minutes=int(est), energy=energy, notes=notes,
                         due_date=due.isoformat() if has_due else "none",
                         due_time=(due_time.strip() or "none") if has_due else "none")
        if goal != t["goal_id"]:
            db.update("tasks", task_id, {"goal_id": goal})
        if out.ok:
            st.rerun()
    if b2.button("Set aside", use_container_width=True, help="Keeps it, but out of your plans"):
        common.run("update_task", task=str(task_id), status="dropped")
        st.rerun()
    if b3.button("Delete", use_container_width=True):
        st.session_state[f"confirm-del-{task_id}"] = True
    if st.session_state.get(f"confirm-del-{task_id}"):
        st.warning("This removes the task and its scheduled time for good (you can still undo it right after).")
        if st.button("Yes, delete it", key=f"del-yes-{task_id}", type="primary"):
            common.run("delete_task", task=str(task_id))
            st.session_state.pop(f"confirm-del-{task_id}", None)
            st.rerun()


@st.dialog("New goal")
def _new_goal() -> None:
    title = st.text_input("What are you working toward?", placeholder="Pass the networking exam")
    why = st.text_input("Why does it matter? (optional)")
    c1, c2 = st.columns(2)
    has_date = c1.checkbox("Has a target date")
    target = c2.date_input("Target date", value=clock.today() + timedelta(days=30), disabled=not has_date)
    cat = st.selectbox("Category", T.CATEGORIES, index=0)
    if st.button("Create goal", type="primary", use_container_width=True):
        out = common.run("create_goal", title=title, why=why, category=cat,
                         target_date=target.isoformat() if has_date else None)
        if out.ok:
            st.rerun()


@st.dialog("Delete this goal?")
def _delete_goal(goal_id: int, title: str) -> None:
    st.write(f"Delete **{title}**? Its tasks stay on your list, just no longer tied to it.")
    c1, c2 = st.columns(2)
    if c1.button("Delete goal", type="primary", use_container_width=True):
        common.run("delete_goal", goal=str(goal_id))
        st.rerun()
    if c2.button("Keep it", use_container_width=True):
        st.rerun()


@st.dialog("Add a step")
def _add_step(goal_id: int, goal_title: str) -> None:
    st.caption(f"A concrete next step for “{goal_title}”.")
    text = st.text_input("Step", placeholder="Read chapter 4 friday 90 min")
    if st.button("Add step", type="primary", use_container_width=True) and text.strip():
        spec = lite.parse_task_text(text)
        out = common.run("add_task", goal=str(goal_id), **{k: v for k, v in spec.items() if v is not None})
        if out.ok:
            st.rerun()


# --------------------------------------------------------------------------- capture
def _capture() -> None:
    with st.form("quick_add", clear_on_submit=True, border=False):
        c1, c2 = st.columns([6, 1], vertical_alignment="bottom")
        text = c1.text_input("Add a task", key="qa_text", placeholder="Lab report friday 2h, high priority",
                             help="I understand dates (friday, 25 oct, in 3 days), lengths (2h, 45 min) and priority words.")
        if c2.form_submit_button("Add", type="primary", use_container_width=True) and text.strip():
            spec = lite.parse_task_text(text)
            if not spec["title"]:
                st.toast("What should the task be called?", icon=":material/error:")
            else:
                out = common.run("add_task", **{k: v for k, v in spec.items() if v is not None})
                if out.ok:
                    st.rerun()


# --------------------------------------------------------------------------- rows
def _complete(task_id: int) -> None:
    common.run("complete_task", task=str(task_id))


def _row(t: dict, today: date, factors: dict, planned: dict[int, dict], goals: dict[int, dict]) -> None:
    with st.container(key=f"row-task-{t['id']}"):
        c0, c1, c2 = st.columns([0.4, 6.4, 1.1], vertical_alignment="center")
        with c0:
            st.checkbox("Done", key=f"tk-{t['id']}", value=False, label_visibility="collapsed",
                        on_change=_complete, args=(t["id"],))
        with c1:
            tags = []
            if t["due_date"]:
                overdue = t["due_date"] < today.isoformat()
                tags.append(chip(fmt.due(t["due_date"]) + (f", {fmt.time(t['due_time'])}" if t["due_time"] else ""),
                                 "warn" if overdue else "", icon="clock"))
            est = fmt.duration(t["est_minutes"])
            adj = T.effective_estimate(t, factors)
            tags.append(chip(f"{est}" + (f", plans {fmt.duration(adj)}" if abs(adj - t["est_minutes"]) >= 10 else "")))
            if t["priority"] <= 2:
                tags.append(chip(T.PRIORITIES[t["priority"]], "warn" if t["priority"] == 1 else ""))
            tags.append(chip(t["category"], cat=t["category"]))
            if t["status"] == "doing":
                tags.append(chip(f"{fmt.duration(t['actual_minutes'])} so far" if t["actual_minutes"] else "In progress", "now"))
            if (t["postponed"] or 0) >= 2:
                tags.append(chip(f"Slipped {t['postponed']} times", "warn"))
            if t["goal_id"] in goals:
                tags.append(chip(goals[t["goal_id"]]["title"][:28], icon="spark"))
            b = planned.get(t["id"])
            if b:
                tags.append(chip(f"Planned {fmt.day(b['date'])} {fmt.time(b['start'])}", "ok", icon="check"))
            common.html(f'<div class="title-line">{esc(t["title"])}</div>' + chips(*tags))
        with c2:
            if st.button("", icon=":material/edit:", key=f"ed-{t['id']}", type="tertiary", help="Edit"):
                _edit(t["id"])


def _finished_row(t: dict) -> None:
    with st.container(key=f"row-done-{t['id']}"):
        c1, c2 = st.columns([6.5, 1.3], vertical_alignment="center")
        with c1:
            took = f", took {fmt.duration(t['actual_minutes'])}" if t["actual_minutes"] else ""
            common.html(f'<div class="title-line done">{esc(t["title"])}</div>'
                        f'<div class="note">{esc(fmt.day((t["completed_at"] or "")[:10]) if t["completed_at"] else "")}{esc(took)}</div>')
        if c2.button("Reopen", key=f"ro-{t['id']}", type="tertiary"):
            T.reopen_task(t["id"])
            st.rerun()


def _dropped_row(t: dict) -> None:
    with st.container(key=f"row-drop-{t['id']}"):
        c1, c2 = st.columns([6.5, 1.3], vertical_alignment="center")
        common.html(f'<div class="title-line done">{esc(t["title"])}</div>', c1)
        if c2.button("Bring back", key=f"bb-{t['id']}", type="tertiary"):
            common.run("update_task", task=str(t["id"]), status="todo")
            st.rerun()


# --------------------------------------------------------------------------- goals
def _goals() -> None:
    c1, c2 = st.columns([5, 1.3], vertical_alignment="center")
    c1.html(section("Goals", "the bigger picture your tasks serve"))
    if c2.button("New goal", icon=":material/add:", key="new-goal"):
        _new_goal()
    goals = T.list_goals()
    if not goals:
        common.html(empty("No goals yet. A goal gives your tasks a reason, and I'll give tasks tied to one a little extra weight."))
    for g in goals:
        pct, done, total = T.goal_progress(g)
        with st.container(key=f"row-goal-{g['id']}"):
            a, b = st.columns([5, 1.6], vertical_alignment="center")
            with a:
                meta = [chip(f"{done} of {total} steps" if total else f"{pct}%")]
                if g["target_date"]:
                    meta.append(chip(f"By {fmt.day(g['target_date'])}", icon="clock"))
                common.html(f'<div class="title-line">{esc(g["title"])}</div>'
                            + f'<div style="margin:.45rem 0 .1rem">{_bar(pct)}</div>' + chips(*meta))
            with b:
                if st.button("Add a step", key=f"gs-{g['id']}", icon=":material/add:", use_container_width=True):
                    _add_step(g["id"], g["title"])
                d1, d2 = st.columns([3, 1])
                if d1.button("Mark achieved", key=f"gd-{g['id']}", type="tertiary", use_container_width=True):
                    common.run("update_goal", goal=str(g["id"]), status="done")
                    st.rerun()
                if d2.button("", icon=":material/delete:", key=f"gx-{g['id']}", type="tertiary", help="Delete this goal"):
                    _delete_goal(g["id"], g["title"])


def _bar(pct: int) -> str:
    from .components import bar
    return bar(pct / 100)


# --------------------------------------------------------------------------- page
def render() -> None:
    today = clock.today()
    open_tasks = T.list_tasks(status=["todo", "doing"])
    overdue = sum(1 for t in open_tasks if t["due_date"] and t["due_date"] < today.isoformat())
    week = sum(1 for t in open_tasks if t["due_date"] and today.isoformat() <= t["due_date"] <= (today + timedelta(days=6)).isoformat())
    sub = (f"{fmt.plural(len(open_tasks), 'open task')}, {week} due this week" + (f", {overdue} overdue" if overdue else "")
           if open_tasks else "Nothing open. Add something below, or enjoy the quiet.")
    common.html(page_head("Tasks", sub))
    _capture()

    f1, f2, f3 = st.columns([2.2, 1.4, 2.4], vertical_alignment="center")
    view = f1.segmented_control("Show", ["Open", "Done", "Set aside"], default="Open", key="task_view",
                                label_visibility="collapsed") or "Open"
    cats = ["All categories"] + sorted({t["category"] for t in T.list_tasks()})
    cat = f2.selectbox("Category", cats, label_visibility="collapsed", key="task_cat")
    q = f3.text_input("Search", placeholder="Search tasks", label_visibility="collapsed", key="task_q")

    def keep(t: dict) -> bool:
        return (cat == "All categories" or t["category"] == cat) and (not q or q.lower() in t["title"].lower())

    if view == "Open":
        factors = T.estimation_factors()
        planned = _next_blocks()
        goals = {g["id"]: g for g in T.list_goals(None)}
        rows = [t for t in open_tasks if keep(t)]
        if not rows:
            common.html(empty("No tasks match." if (q or cat != "All categories") else
                              "All clear. Add a task above, or tell Raveena what's on your mind."))
        groups: dict[str, list[dict]] = {k: [] for k in ORDER}
        for t in rows:
            groups[_bucket(t, today)].append(t)
        for name in ORDER:
            if groups[name]:
                common.html(section(name, str(len(groups[name]))))
                for t in groups[name]:
                    _row(t, today, factors, planned, goals)
    elif view == "Done":
        rows = [t for t in db.rows("SELECT * FROM tasks WHERE status='done' ORDER BY completed_at DESC LIMIT 60") if keep(t)]
        if not rows:
            common.html(empty("Nothing finished yet. It'll show up here when it is."))
        for t in rows:
            _finished_row(t)
    else:
        rows = [t for t in T.list_tasks(status="dropped") if keep(t)]
        if not rows:
            common.html(empty("Nothing set aside."))
        for t in rows:
            _dropped_row(t)
    _goals()
