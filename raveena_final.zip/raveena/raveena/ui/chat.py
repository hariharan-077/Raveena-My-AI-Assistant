"""The conversation, with a live view of today beside it."""
from __future__ import annotations

import logging

import streamlit as st

from .. import actions, brain, clock, conversation, fmt, planner, settings, tools, trackers
from . import avatar, common
from .components import esc, hello, rail, receipts, ring, section

log = logging.getLogger("raveena.ui")

QUICK = ["Plan my day", "What's next?", "I'm feeling overwhelmed", "How am I doing this week?"]
MOOD_ICONS = ["sentiment_very_dissatisfied", "sentiment_dissatisfied", "sentiment_neutral",
              "sentiment_satisfied", "sentiment_very_satisfied"]
MOOD_WORDS = ["Very low", "Low", "Okay", "Good", "Great"]


# --------------------------------------------------------------------------- pieces
def _presence(thinking: bool = False) -> str:
    st_ = brain.status()
    line = ("Thinking…" if thinking else
            "Here, and I remember you." if st_["mode"] == "ai" else "Lite mode: I follow simple commands.")
    return (f'<div class="presence">{avatar.orb_html(clock.now().hour, 46, "thinking" if thinking else "idle")}'
            f'<div><h1>Raveena</h1><div class="status">{esc(line)}</div></div></div>')


def _fresh(c: dict) -> dict:
    """Receipts remember an action id; show what became of it (approved, declined, undone)."""
    a = actions.get(c["action_id"]) if c.get("action_id") else None
    if not a:
        return c
    c = dict(c)
    if a["status"] == "done":
        c["status"], c["summary"] = "done", a["summary"] or c.get("summary")
    elif a["status"] in ("undone", "rejected"):
        c["status"], c["summary"] = "muted", ("Undone: " if a["status"] == "undone" else "Declined: ") + (a["summary"] or "")
    return c


def _render_history(limit: int) -> None:
    msgs = conversation.recent(limit)
    if conversation.count() > len(msgs):
        if st.button("Show earlier messages", key="more_msgs", type="tertiary"):
            st.session_state["chat_limit"] = limit + 40
            st.rerun()
    if not msgs:
        common.html(hello(clock.now().hour, settings.display_name()))
        return
    last_ai = max((i for i, m in enumerate(msgs) if m["role"] == "assistant" and m["meta"].get("actions")), default=-1)
    for i, m in enumerate(msgs):
        meta = m["meta"]
        if meta.get("kind") == "note":
            st.caption(m["content"])
            continue
        if m["role"] == "user":
            with st.chat_message("user", avatar=common.user_avatar()):
                st.markdown(m["content"])
            continue
        with st.chat_message("assistant", avatar=common.assistant_avatar()):
            st.markdown(m["content"])
            acts = [_fresh(a) for a in (meta.get("actions") or [])]
            if acts:
                common.html(receipts(acts))
            if i == last_ai and meta.get("turn") and any(a.get("undoable") and a.get("status") == "done" for a in acts):
                live = [a for a in actions.for_turn(meta["turn"]) if a["can_undo"]]
                if live and st.button("Undo these changes", icon=":material/undo:", key=f"undo-{meta['turn']}",
                                      type="tertiary"):
                    n = actions.undo_turn(meta["turn"])
                    conversation.add("assistant", f"Undone ({n} change{'s' if n != 1 else ''}).", {"kind": "note"})
                    st.rerun()


def _approvals() -> None:
    for a in actions.pending():
        with st.container(key=f"row-approve-{a['id']}"):
            common.html(f'<div class="approve"><b>Waiting for your OK</b><br>{esc(a["summary"])}</div>')
            c1, c2, _ = st.columns([1.3, 1.3, 5])
            if c1.button("Approve", key=f"ap-{a['id']}", type="primary"):
                try:
                    out = tools.approve(a["id"])
                    conversation.add("assistant", f"Done: {out.summary}", {"kind": "note"})
                except Exception as e:                                  # noqa: BLE001
                    st.toast(str(e), icon=":material/error:")
                st.rerun()
            if c2.button("Not now", key=f"no-{a['id']}"):
                tools.decline(a["id"])
                conversation.add("assistant", "Okay, I left it alone.", {"kind": "note"})
                st.rerun()


# --------------------------------------------------------------------------- the day beside the chat
def _quick(tool_name: str, **args) -> None:
    """A one-tap action from the side panel. Logged and undoable like everything else (see Settings > Activity);
    the chat page is locked to the viewport, so feedback is a toast rather than a banner row."""
    out = common.run(tool_name, quiet=True, **args)
    st.toast(out.summary if out.ok else out.text, icon=":material/check:" if out.ok else ":material/error:")
    st.rerun()


def _side() -> None:
    now = clock.now()
    today = now.date()
    cfg = settings.all()

    checks = planner.pending_checkins(now)
    if checks:
        common.html(section("Did these happen?"))
        for b in checks[-2:]:
            with st.container(key=f"row-chk-{b['id']}"):
                common.html(f'<div class="title-line">{esc(b["title"])}</div>'
                        f'<div class="note">{esc(fmt.span(b["start"], b["end"]))}, {esc(fmt.day(b["date"]).lower())}</div>')
                c1, c2, _ = st.columns([1, 1, 1.4])
                if c1.button("Done", key=f"chk-done-{b['id']}", icon=":material/check:"):
                    _quick("session_done", block_id=b["id"])
                if c2.button("Missed", key=f"chk-miss-{b['id']}"):
                    _quick("session_missed", block_id=b["id"])

    cur, nxt = planner.current_and_next(now)
    focus = cur or nxt
    if focus:
        label = "Right now" if cur else "Next up"
        with st.container(key="row-nextup"):
            common.html(section(label) + f'<div class="title-line">{esc(focus["title"])}</div>'
                    f'<div class="note">{esc(fmt.span(focus["start"], focus["end"]))}</div>')
            if st.button("Done", key="nextup-done", icon=":material/check:"):
                _quick("session_done", block_id=focus["id"])

    items = planner.agenda(today)
    common.html(section("Today", fmt.long_date(today)))
    common.html(rail(items, today, now, clock.hm_to_min(cfg["day_start"]), clock.hm_to_min(cfg["day_end"])))

    water = next((t for t in trackers.list_trackers() if t["name"].lower() == "water"), None)
    if water:
        p = trackers.progress(water)
        c1, c2 = st.columns([1, 2.3], vertical_alignment="center")
        common.html(ring(p["pct"], water["color"], size=52, stroke=6), c1)
        common.html(f'<div class="title-line">Water</div><div class="note">{esc(trackers.format_value(water, p["total"]))} '
                f'of {esc(trackers.format_value(water, water["target"]))}</div>', c2)
        b1, b2 = st.columns(2)
        for col, ml in ((b1, 250), (b2, 500)):
            if col.button(f"+{ml} ml", key=f"water-{ml}"):
                _quick("log_activity", tracker="water", value=ml)

    common.html(section("How are you feeling?"))
    cols = st.columns(5)
    for i, col in enumerate(cols, start=1):
        if col.button("", icon=f":material/{MOOD_ICONS[i - 1]}:", key=f"mood-{i}", help=MOOD_WORDS[i - 1],
                      use_container_width=True):
            st.session_state["mood_logged"] = i
            _quick("log_mood", mood=i, explicit=True)
    logged = st.session_state.get("mood_logged")
    if logged:
        if logged <= 2:
            st.caption("Thank you for telling me. Want me to go lighter on today?")
            if st.button("Lighten today", key="lighten", icon=":material/spa:"):
                st.session_state.pop("mood_logged", None)
                _quick("plan_schedule", scope="today", gentle=True)
        else:
            st.caption(f"Noted: {MOOD_WORDS[logged - 1].lower()}.")

    common.html(section("Ask me"))
    with st.container(key="quick"):
        for q in QUICK:
            if st.button(q, key=f"q-{q}", type="tertiary"):
                st.session_state["queued_prompt"] = q
                st.rerun()


# --------------------------------------------------------------------------- page
def render() -> None:
    limit = st.session_state.get("chat_limit", 40)
    left, right = st.columns([1.75, 1], gap="large")
    with left:
        presence = st.empty()
        common.html(_presence(), presence)
        # two panes that scroll on their own, like a real app (heights are set in the stylesheet)
        thread = st.container(height=520, border=False, key="thread", autoscroll=True)
        with thread:
            _render_history(limit)
            _approvals()
    with right:
        with st.container(height=520, border=False, key="rail-wrap"):
            _side()

    prompt = st.chat_input("Message Raveena") or st.session_state.pop("queued_prompt", None)
    if not prompt:
        return

    conversation.add("user", prompt)
    history = conversation.history_for_model()
    turn = brain.Turn()
    engine = brain.get_brain()
    common.html(_presence(thinking=True), presence)
    with thread:
        with st.chat_message("user", avatar=common.user_avatar()):
            st.markdown(prompt)
        with st.chat_message("assistant", avatar=common.assistant_avatar()):
            try:
                text = st.write_stream(engine.reply(history, turn))
            except Exception:                                           # noqa: BLE001 - never lose the conversation
                log.exception("reply failed")
                text = "Something went wrong on my side. Nothing was lost; could you try that again?"
                st.markdown(text)
            if turn.actions:
                common.html(receipts(turn.actions))
    conversation.add("assistant", text if isinstance(text, str) else "".join(map(str, text)),
                     {"turn": turn.id, "actions": turn.actions, "mode": turn.mode})
    st.rerun()
