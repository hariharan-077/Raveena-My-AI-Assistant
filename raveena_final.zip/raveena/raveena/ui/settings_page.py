"""Settings: your rhythm, Raveena's brain and voice, the automation switches, the activity log, your data."""
from __future__ import annotations

import json
import zoneinfo
from datetime import datetime

import streamlit as st

from .. import actions, brain, clock, config, conversation, db, fmt, settings, tools
from . import common
from .components import chip, empty, esc, page_head, section

TZ_HERE = "This computer's time zone"
AUTOMATIONS = [
    ("auto_daily_plan", "Plan my day when I open the app",
     "If nothing is planned for today, I'll build a plan. You can undo it from the activity log."),
    ("auto_rollover", "Roll unfinished sessions forward",
     "Sessions from earlier days that nobody confirmed count as missed and get new time. Nothing is deleted."),
    ("morning_briefing", "Write a short briefing each day",
     "A few lines in the chat the first time you open the app: what's planned, and anything at risk."),
    ("auto_memory", "Remember things from our conversations",
     "I save goals, preferences and what helps you. Everything is listed under Memory, where you can edit or delete it."),
    ("auto_mood", "Note how I'm feeling from our conversations",
     "When you tell me how you feel, I log mood and energy so I can keep plans realistic and spot patterns."),
]
SOURCES = {"chat": "Raveena", "ui": "You", "automation": "Automation"}


def _t(hm: str):
    return datetime.strptime(hm, "%H:%M").time()


def _hm(t) -> str:
    return t.strftime("%H:%M")


# --------------------------------------------------------------------------- tabs
def _rhythm() -> None:
    cfg = settings.all()
    zones = [TZ_HERE] + sorted(zoneinfo.available_timezones())
    with st.form("rhythm", border=False):
        c1, c2, c3 = st.columns(3)
        name = c1.text_input("What should I call you?", value=cfg["name"])
        tfmt = c2.radio("Time format", ["12h", "24h"], index=0 if cfg["time_format"] == "12h" else 1, horizontal=True,
                        format_func=lambda v: "2:30 pm" if v == "12h" else "14:30")
        tz = c3.selectbox("Time zone", zones, index=zones.index(cfg["timezone"]) if cfg["timezone"] in zones else 0)
        common.html(section("Your rhythm"))
        a, b, c, d = st.columns(4)
        wake = a.time_input("Wake up", value=_t(cfg["wake_time"]), step=900)
        sleep = b.time_input("Go to sleep", value=_t(cfg["sleep_time"]), step=900)
        ds = c.time_input("Plan from", value=_t(cfg["day_start"]), step=900,
                          help="The earliest I'll place work.")
        de = d.time_input("Plan until", value=_t(cfg["day_end"]), step=900, help="The latest I'll place work.")
        e, f, _ = st.columns([1, 1, 2])
        ps = e.time_input("Best focus hours start", value=_t(cfg["peak_start"]), step=900,
                          help="Deep work is saved for this window.")
        pe = f.time_input("and end", value=_t(cfg["peak_end"]), step=900)
        common.html(section("How much to plan"))
        g1, g2 = st.columns(2)
        cap = g1.slider("Most task time to plan on a weekday (hours)", 1.0, 12.0, cfg["max_focus_minutes"] / 60, 0.5)
        wk = g2.slider("Weekends are this much of a weekday", 10, 100, int(cfg["weekend_load"] * 100), 5, format="%d%%")
        h1, h2, h3 = st.columns(3)
        bmax = h1.slider("Longest single session (minutes)", 30, 180, int(cfg["block_max"]), 5)
        bmin = h2.slider("Shortest useful session (minutes)", 10, 60, int(cfg["block_min"]), 5)
        brk = h3.slider("Break after long sessions (minutes)", 0, 30, int(cfg["break_minutes"]), 5)
        contact = st.text_input("If you're ever struggling, who or what should I point you to?",
                                value=cfg["crisis_contact"], placeholder="For example: my sister Meera, or my counsellor",
                                help="Optional. I'll only mention it if you seem to be having a hard time.")
        if st.form_submit_button("Save", type="primary"):
            if _m(ds) >= _m(de):
                st.error("The plan window needs to start before it ends.")
            elif _m(ps) >= _m(pe):
                st.error("Your focus window needs to start before it ends.")
            else:
                settings.update({
                    "name": name.strip(), "time_format": tfmt, "timezone": "" if tz == TZ_HERE else tz,
                    "wake_time": _hm(wake), "sleep_time": _hm(sleep), "day_start": _hm(ds), "day_end": _hm(de),
                    "peak_start": _hm(ps), "peak_end": _hm(pe), "max_focus_minutes": int(cap * 60),
                    "weekend_load": wk / 100, "block_max": bmax, "block_min": min(bmin, bmax), "break_minutes": brk,
                    "crisis_contact": contact.strip()})
                st.toast("Saved. I'll plan around that from now on.", icon=":material/check:")


def _m(t) -> int:
    return t.hour * 60 + t.minute


def _ai() -> None:
    cfg = settings.all()
    status = brain.status()
    if status["mode"] == "ai":
        common.html(f'<div class="approve" style="background:var(--peacock-wash);border-color:var(--peacock);color:var(--peacock-ink)">'
                    f'<b>Connected.</b> I\'m thinking with {esc(status["model"])}.</div>')
    else:
        common.html(f'<div class="approve"><b>Lite mode.</b> {esc(status["reason"])} I still handle tasks, plans and '
                    "habits from simple commands. Connect Gemini to talk naturally.</div>")
    common.html(section("Connect Gemini"))
    key = st.text_input("Gemini API key", type="password", placeholder="AIza…", key="api_key_input",
                        help="Get a free one at aistudio.google.com/apikey. It stays on this computer.")
    a, b, _ = st.columns([1.3, 1.9, 3])
    if a.button("Use for now", key="key-now", disabled=not key.strip()):
        config.set_api_key(key)
        st.toast("Connected for this session.", icon=":material/check:")
        st.rerun()
    if b.button("Remember on this computer", key="key-save", disabled=not key.strip(),
                help="Saved to a local .env file (plain text, owner-only permissions)."):
        config.set_api_key(key)
        p = config.save_api_key_to_env(key)
        st.toast(f"Saved to {p.name}.", icon=":material/check:")
        st.rerun()

    common.html(section("How I think"))
    models = list(config.MODEL_CHOICES)
    cur = cfg["model"] if cfg["model"] in models else "custom"
    c1, c2 = st.columns(2)
    choice = c1.selectbox("Model", models + ["custom"], index=(models + ["custom"]).index(cur),
                          format_func=lambda m: config.MODEL_CHOICES.get(m, "Another model ID…"))
    custom = c1.text_input("Model ID", value=cfg["model"] if cur == "custom" else "", disabled=choice != "custom",
                           placeholder="gemini-flash-latest")
    effort = c2.select_slider("Depth", options=list(config.EFFORT_CHOICES), value=cfg["effort"],
                              format_func=config.EFFORT_CHOICES.get,
                              help="How much I think before answering. Quick is snappiest; Thoughtful is slower and deeper.")
    use_ai = c2.toggle("Use Gemini when it's connected", value=cfg["use_ai"])
    common.html(section("How I sound"))
    tone = st.radio("Tone", ["warm", "coach", "concise"], index=["warm", "coach", "concise"].index(cfg["tone"]), horizontal=True,
                    format_func={"warm": "Warm and gentle", "coach": "Direct, like a coach", "concise": "Brief and to the point"}.get)
    share = st.toggle("Include my mood notes when Gemini reads my context", value=cfg["share_mood_notes"],
                      help="Your tasks, schedule, habits and memories are sent to Gemini with each message so I know you. "
                           "Switch this off to keep the free-text notes on your mood check-ins out of it.")
    s1, s2, _ = st.columns([1, 1.4, 3])
    if s1.button("Save", type="primary", key="ai-save"):
        settings.update({"model": (custom.strip() or cfg["model"]) if choice == "custom" else choice, "effort": effort,
                         "use_ai": use_ai, "tone": tone, "share_mood_notes": share})
        st.toast("Saved.", icon=":material/check:")
        st.rerun()
    if s2.button("Test the connection", key="ai-test", disabled=status["mode"] != "ai"):
        with st.spinner("Saying hello…"):
            try:
                text = brain.GeminiBrain().complete("Reply with a friendly greeting of at most six words.",
                                                       system="You are a connection test.", max_tokens=400)
                st.success(f"It works: “{text[:80]}”")
            except brain.BrainError as e:
                st.error(e.user_message)
            except Exception as e:                                     # noqa: BLE001
                st.error(f"Couldn't connect: {str(e)[:160]}")
    st.caption("When Gemini is connected, each message sends it your recent conversation plus a summary of your tasks, "
               "schedule, habits and memories. Nothing else leaves this computer.")


def _automations() -> None:
    common.html(section("Things I do on my own", "all reversible, all logged"))
    cfg = settings.all()
    for key, label, help_ in AUTOMATIONS:
        st.toggle(label, value=cfg[key], key=f"auto-{key}", help=help_,
                  on_change=lambda k=key: settings.set(k, st.session_state[f"auto-{k}"]))
        st.caption(help_)
    common.html(section("Things I always ask about first"))
    common.html('<div class="note" style="max-width:42rem">Deleting a task, goal, habit, routine or event, and forgetting a memory '
                "never happen without your OK. Anything else I change for you appears in the activity log with an "
                "Undo button, so a wrong guess costs you one click.</div>")


def _activity() -> None:
    pend = actions.pending()
    if pend:
        common.html(section("Waiting for your OK"))
        for a in pend:
            with st.container(key=f"row-pend-{a['id']}"):
                c1, c2, c3 = st.columns([5, 1.2, 1.2], vertical_alignment="center")
                common.html(f'<div class="title-line">{esc(a["summary"])}</div>', c1)
                if c2.button("Approve", key=f"pa-{a['id']}", type="primary", use_container_width=True):
                    tools.approve(a["id"])
                    st.rerun()
                if c3.button("Decline", key=f"pd-{a['id']}", use_container_width=True):
                    tools.decline(a["id"])
                    st.rerun()
    common.html(section("Recent activity", "what I and you have changed"))
    rows = [a for a in actions.recent(60) if a["status"] != "pending"]
    if not rows:
        common.html(empty("Nothing yet. Every change I make shows up here."))
    for a in rows:
        kind = {"done": "ok", "failed": "warn"}.get(a["status"], "")
        with st.container(key=f"row-act-{a['id']}"):
            c1, c2, c3 = st.columns([5.4, 1.6, 1.2], vertical_alignment="center")
            common.html(f'<div class="title-line" style="font-weight:500">{esc(a["summary"] or a["tool"])}</div>'
                        f'<div class="note">{esc(SOURCES.get(a["source"], a["source"]))}, {esc(a["ts"][11:16])}'
                        f', {esc(fmt.day(a["ts"][:10]).lower())}</div>', c1)
            common.html(chip(a["status"].capitalize(), kind), c2)
            if a["can_undo"] and c3.button("Undo", key=f"au-{a['id']}", icon=":material/undo:", use_container_width=True):
                actions.undo(a["id"])
                st.toast("Undone.", icon=":material/undo:")
                st.rerun()


@st.dialog("Clear the conversation?")
def _clear_chat() -> None:
    st.write("This removes the chat history. Your tasks, habits and memories stay.")
    c1, c2 = st.columns(2)
    if c1.button("Clear it", type="primary", use_container_width=True):
        conversation.clear()
        st.rerun()
    if c2.button("Keep it", use_container_width=True):
        st.rerun()


def _data() -> None:
    common.html(section("Where everything lives"))
    st.code(str(db.path()), language=None)
    st.caption("One file on this computer. Copy it to back up or move Raveena.")
    common.html(section("Take it with you"))
    db.checkpoint()
    c1, c2, _ = st.columns([1.6, 1.6, 2])
    c1.download_button("Download as JSON", data=json.dumps(db.export_all(), indent=2, ensure_ascii=False, default=str),
                       file_name=f"raveena-{clock.today().isoformat()}.json", mime="application/json",
                       use_container_width=True, icon=":material/download:")
    c2.download_button("Download the database", data=db.path().read_bytes(), file_name="raveena.db",
                       mime="application/octet-stream", use_container_width=True, icon=":material/database:")
    common.html(section("Start over"))
    if st.button("Clear the conversation", icon=":material/chat_bubble_outline:", key="clear-chat"):
        _clear_chat()
    with st.expander("Erase everything"):
        st.warning("This permanently deletes all your tasks, habits, memories and conversations on this computer.")
        word = st.text_input("Type ERASE to confirm", key="erase_word")
        if st.button("Erase everything", type="primary", disabled=word.strip() != "ERASE", key="erase-go"):
            db.wipe_everything()
            for k in list(st.session_state):
                del st.session_state[k]
            st.rerun()


def render() -> None:
    common.html(page_head("Settings", "Tune Raveena to your day, decide what she does on her own, and see everything she's done."))
    t1, t2, t3, t4, t5 = st.tabs(["You and your day", "Raveena", "Automations and safety", "Activity", "Your data"])
    with t1:
        _rhythm()
    with t2:
        _ai()
    with t3:
        _automations()
    with t4:
        _activity()
    with t5:
        _data()
