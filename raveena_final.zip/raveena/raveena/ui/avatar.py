"""Raveena's presence: a light that follows the time of day.

The orb in the header and the little avatar beside her messages share one palette, which moves
from dawn through noon and dusk to night. It's the one decorative idea in the interface.
"""
from __future__ import annotations

import math
from pathlib import Path

from .. import config

# (name, o1 highlight, o2 body, o3 edge, glow)
SKIES = {
    "dawn": ("#FFE6C9", "#F6A9BA", "#A99BE0", "rgba(246,169,186,.55)"),
    "morning": ("#EAF7FF", "#8FD0F2", "#6FCBB1", "rgba(143,208,242,.55)"),
    "afternoon": ("#FFF3C9", "#FFC857", "#FF9877", "rgba(255,200,87,.55)"),
    "dusk": ("#FFD6BE", "#F2768B", "#6A4DB5", "rgba(242,118,139,.5)"),
    "night": ("#C3D2FF", "#6E7DE2", "#2B2B72", "rgba(110,125,226,.55)"),
}


def sky_name(hour: int) -> str:
    if 5 <= hour < 8:
        return "dawn"
    if 8 <= hour < 12:
        return "morning"
    if 12 <= hour < 17:
        return "afternoon"
    if 17 <= hour < 20:
        return "dusk"
    return "night"


def orb_html(hour: int, size: int = 44, state: str = "idle") -> str:
    o1, o2, o3, glow = SKIES[sky_name(hour)]
    return (f'<span class="orb {"is-thinking" if state == "thinking" else ""}" '
            f'style="--o1:{o1};--o2:{o2};--o3:{o3};--glow:{glow};--sz:{size}px" role="img" '
            f'aria-label="Raveena"></span>')


def _hex(c: str) -> tuple[int, int, int]:
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def orb_png(hour: int, size: int = 96) -> str:
    """Path to a PNG of the orb for this time of day (generated once, cached on disk)."""
    from PIL import Image

    name = sky_name(hour)
    path = Path(config.CACHE_DIR) / f"orb_{name}_{size}.png"
    if path.exists():
        return str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    s = size * 3                                   # supersample for smooth edges
    o1, o2, o3, _ = SKIES[name]
    c1, c2, c3 = _hex(o1), _hex(o2), _hex(o3)
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    px = img.load()
    cx = cy = (s - 1) / 2
    r = s / 2 - 2
    hx, hy = s * 0.34, s * 0.30                    # light source
    maxd = math.hypot(s - hx, s - hy)
    for y in range(s):
        for x in range(s):
            if math.hypot(x - cx, y - cy) > r:
                continue
            t = min(1.0, math.hypot(x - hx, y - hy) / maxd * 1.25)
            col = _mix(c1, c2, t / 0.48) if t < 0.48 else _mix(c2, c3, (t - 0.48) / 0.52)
            px[x, y] = (*col, 255)
    img = img.resize((size, size), Image.LANCZOS)
    img.save(path)
    return str(path)


def initial_png(letter: str, size: int = 96) -> str:
    """A calm monogram avatar for you."""
    from PIL import Image, ImageDraw, ImageFont

    letter = (letter or "?").strip()[:1].upper() or "?"
    path = Path(config.CACHE_DIR) / f"initial_{ord(letter)}_{size}.png"
    if path.exists():
        return str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    s = size * 3
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((2, 2, s - 3, s - 3), fill=(225, 232, 244, 255))
    try:
        font = ImageFont.load_default(size=int(s * 0.46))
    except TypeError:                              # very old Pillow
        font = ImageFont.load_default()
    d.text((s / 2, s / 2), letter, fill=(24, 33, 58, 255), font=font, anchor="mm")
    img.resize((size, size), Image.LANCZOS).save(path)
    return str(path)
