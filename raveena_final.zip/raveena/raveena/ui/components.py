"""Small HTML/SVG builders. Everything user-supplied is escaped here, once."""
from __future__ import annotations

import html
import math
from datetime import date, datetime

from .. import clock, fmt
from . import avatar
from .icons import svg
from .theme import category_color


def esc(s) -> str:
    return html.escape(str(s if s is not None else ""), quote=True).replace("\n", " ")


# --------------------------------------------------------------------------- text blocks
def page_head(title: str, sub: str = "") -> str:
    return f'<div class="page-head"><h1>{esc(title)}</h1>' + (f"<p>{esc(sub)}</p>" if sub else "") + "</div>"


def section(title: str, small: str = "") -> str:
    return f'<div class="h-section">{esc(title)}' + (f"<small>{esc(small)}</small>" if small else "") + "</div>"


def empty(message_html: str) -> str:
    return f'<div class="empty">{message_html}</div>'


def chip(text: str, kind: str = "", *, cat: str | None = None, icon: str | None = None) -> str:
    style = f' style="--c:{category_color(cat)}"' if cat else ""
    cls = f"chip {kind}".strip() + (" cat" if cat else "")
    return f'<span class="{cls}"{style}>' + (svg(icon, 12) if icon else "") + f"{esc(text)}</span>"


def chips(*items: str) -> str:
    return '<div class="chips">' + "".join(i for i in items if i) + "</div>"


def receipts(actions: list[dict]) -> str:
    """The little receipts under a message: what Raveena actually did."""
    if not actions:
        return ""
    out = []
    for a in actions:
        kind = {"pending": "pending", "failed": "failed", "muted": "muted"}.get(a.get("status"), "")
        icon = {"pending": "hourglass", "failed": "alert", "muted": "undo"}.get(a.get("status"), "check")
        out.append(f'<span class="receipt {kind}">{svg(icon, 14)}{esc(a.get("summary") or a.get("tool"))}</span>')
    return '<div class="receipts">' + "".join(out) + "</div>"


def hello(hour: int, name: str) -> str:
    return (f'<div class="hello">{avatar.orb_html(hour, 64)}<h2>{esc(fmt.greeting(hour))}, {esc(name)}.</h2>'
            "<p>Tell me what's on your plate or how your day is going. I can plan it, keep track of it, "
            "and I'll remember it for next time.</p></div>")


# --------------------------------------------------------------------------- progress
def ring(pct: float, color: str, *, size: int = 56, stroke: int = 6, center: str = "") -> str:
    r = (size - stroke) / 2
    c = 2 * math.pi * r
    pct = max(0.0, min(1.0, pct))
    return (f'<span class="ring" style="width:{size}px;height:{size}px">'
            f'<svg class="bg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">'
            f'<circle cx="{size / 2}" cy="{size / 2}" r="{r}" fill="none" stroke="var(--line2)" stroke-width="{stroke}"/>'
            f'<circle cx="{size / 2}" cy="{size / 2}" r="{r}" fill="none" stroke="{color}" stroke-width="{stroke}" '
            f'stroke-linecap="round" stroke-dasharray="{c * pct:.1f} {c:.1f}"/></svg>'
            f'<span class="c">{center}</span></span>')


def bar(pct: float, color: str = "var(--peacock)", thin: bool = False) -> str:
    return (f'<div class="bar{" thin" if thin else ""}" style="--c:{color}">'
            f'<i style="width:{max(0.0, min(1.0, pct)) * 100:.0f}%"></i></div>')


def dots(history: list[tuple[date, float]], target: float, color: str, today: date | None = None) -> str:
    today = today or clock.today()
    out = []
    for d, v in history:
        cls = "on" if v >= target - 1e-9 else "part" if v > 0 else ""
        if d == today:
            cls += " today"
        out.append(f'<i class="{cls.strip()}" title="{fmt.wdm(d)}"></i>')
    return f'<div class="dots" style="--c:{color}">' + "".join(out) + "</div>"


# --------------------------------------------------------------------------- day rail & week grid
def _m(hm: str) -> int:
    return clock.hm_to_min(hm)


def _item_html(it: dict, ws: int, we: int, px: float, compact_under: int, show_time: bool = True) -> str:
    s, e = max(ws, _m(it["start"])), min(we, _m(it["end"]))
    if e <= s:
        return ""
    top = (s - ws) / 60 * px
    height = max(15.0, (e - s) / 60 * px - 2)
    fixed = it["kind"] in ("routine", "event")
    cat = it.get("category") if not fixed else ("Event" if it["kind"] == "event" else "Routine")
    cls = ["rail-item"]
    if fixed:
        cls.append("fixed")
    elif it["status"] in ("done", "missed", "skipped"):
        cls.append("done" if it["status"] == "done" else "missed")
    if (e - s) < compact_under:
        cls.append("compact")
    lock = svg("lock", 10) if it.get("locked") else ""
    time_txt = f"{fmt.time(it['start'])} to {fmt.time(it['end'])}"
    return (f'<div class="{" ".join(cls)}" style="top:{top:.1f}px;height:{height:.1f}px;--c:{category_color(cat or "General")}" '
            f'title="{esc(it["title"])}, {esc(time_txt)}"><span class="t">{lock}{esc(it["title"])}</span>'
            + (f"<small>{esc(time_txt)}</small>" if show_time else "") + "</div>")


def hour_ticks(ws: int, we: int, px: float, labels: bool = True) -> str:
    out = []
    first = math.ceil(ws / 60)
    for h in range(first, we // 60 + 1):
        y = (h * 60 - ws) / 60 * px
        out.append(f'<div class="rail-grid" style="top:{y:.1f}px"></div>')
        if labels:
            out.append(f'<div class="rail-hour" style="top:{y:.1f}px">{esc(fmt.time(f"{h % 24:02d}:00"))}</div>')
    return "".join(out)


def now_marker(now: datetime, ws: int, we: int, px: float) -> str:
    m = clock.minutes_of(now)
    if not ws <= m <= we:
        return ""
    return (f'<div class="rail-now" style="top:{(m - ws) / 60 * px:.1f}px"><span>{esc(fmt.time(now.strftime("%H:%M")))}</span></div>')


def rail(items: list[dict], d: date, now: datetime, ws: int, we: int, px: float = 34.0) -> str:
    height = (we - ws) / 60 * px
    body = hour_ticks(ws, we, px) + "".join(_item_html(i, ws, we, px, 38) for i in items)
    if d == now.date():
        body += now_marker(now, ws, we, px)
    return f'<div class="rail" style="height:{height:.0f}px">{body}</div>'


def _short_hour(h: int) -> str:
    """'10a', '2p', or '14' for 24-hour clocks: short enough for the week grid's narrow label column."""
    t = fmt.time(f"{h % 24:02d}:00")
    return t.replace(" am", "a").replace(" pm", "p")


def week_grid(days: list[tuple[date, list[dict]]], now: datetime, ws: int, we: int, px: float = 30.0) -> str:
    height = (we - ws) / 60 * px
    heads = '<div></div>' + "".join(
        f'<div class="head{" today" if d == now.date() else ""}">{esc(d.strftime("%a"))}<b>{d.day}</b></div>' for d, _ in days)
    labels = f'<div class="hours" style="height:{height:.0f}px">' + "".join(
        f'<div class="rail-hour" style="top:{(h * 60 - ws) / 60 * px:.1f}px;left:0;width:2.1rem">{esc(_short_hour(h))}</div>'
        for h in range(math.ceil(ws / 60), we // 60 + 1)) + "</div>"
    cols = ""
    for d, items in days:
        inner = hour_ticks(ws, we, px, labels=False) + "".join(_item_html(i, ws, we, px, 45, show_time=False) for i in items)
        if d == now.date():
            inner += now_marker(now, ws, we, px).replace(f"<span>{esc(fmt.time(now.strftime('%H:%M')))}</span>", "")
        cols += f'<div class="col{" today" if d == now.date() else ""}" style="height:{height:.0f}px">{inner}</div>'
    return f'<div class="week">{heads}{labels}{cols}</div>'


# --------------------------------------------------------------------------- charts
def bars(values: list[float], labels: list[str], *, color: str = "var(--peacock)", height: int = 150,
         goal: float | None = None, value_fmt=lambda v: f"{v:g}", highlight_last: bool = True) -> str:
    W, pad_b, pad_t = 560, 22, 16
    n = max(1, len(values))
    maxv = max(max(values or [0]), goal or 0, 1e-9)
    slot = W / n
    bw = slot * 0.62
    plot_h = height - pad_b - pad_t
    out = [f'<svg class="chart" viewBox="0 0 {W} {height}" width="100%" role="img">',
           f'<line class="grid" x1="0" x2="{W}" y1="{height - pad_b}" y2="{height - pad_b}"/>']
    if goal:
        gy = height - pad_b - goal / maxv * plot_h
        out.append(f'<line x1="0" x2="{W}" y1="{gy:.1f}" y2="{gy:.1f}" stroke="var(--faint)" stroke-dasharray="3 4" stroke-width="1"/>')
    every = max(1, math.ceil(n / 14))
    for i, v in enumerate(values):
        h = v / maxv * plot_h
        x = i * slot + (slot - bw) / 2
        op = 1 if (not highlight_last or i == n - 1 or n <= 7) else 0.55
        out.append(f'<rect x="{x:.1f}" y="{height - pad_b - h:.1f}" width="{bw:.1f}" height="{max(h, 0):.1f}" rx="4" fill="{color}" opacity="{op}"/>')
        if n <= 8 and v:
            out.append(f'<text x="{x + bw / 2:.1f}" y="{height - pad_b - h - 5:.1f}" text-anchor="middle">{esc(value_fmt(v))}</text>')
        if i % every == 0 or i == n - 1:
            out.append(f'<text x="{x + bw / 2:.1f}" y="{height - 6}" text-anchor="middle">{esc(labels[i])}</text>')
    out.append("</svg>")
    return "".join(out)


def line(points: list[float | None], labels: list[str], *, ymin: float = 1, ymax: float = 5,
         color: str = "var(--peacock)", height: int = 140, y_labels: dict[int, str] | None = None) -> str:
    W, pad_b, pad_t, pad_x = 560, 22, 10, (44 if y_labels else 14)
    n = max(1, len(points))
    plot_h = height - pad_b - pad_t
    step = (W - pad_x * 2) / max(1, n - 1)

    def xy(i: int, v: float) -> tuple[float, float]:
        return pad_x + i * step, pad_t + (1 - (v - ymin) / (ymax - ymin)) * plot_h

    out = [f'<svg class="chart" viewBox="0 0 {W} {height}" width="100%" role="img">']
    for v in range(int(ymin), int(ymax) + 1):
        y = xy(0, v)[1]
        out.append(f'<line class="grid" x1="0" x2="{W}" y1="{y:.1f}" y2="{y:.1f}"/>')
        if y_labels and v in y_labels:
            out.append(f'<text x="0" y="{y + 3.5:.1f}">{esc(y_labels[v])}</text>')
    seg: list[str] = []
    for i, v in enumerate(points):
        if v is None:
            if len(seg) > 1:
                out.append(f'<polyline points="{" ".join(seg)}" fill="none" stroke="{color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>')
            seg = []
            continue
        x, y = xy(i, v)
        seg.append(f"{x:.1f},{y:.1f}")
    if len(seg) > 1:
        out.append(f'<polyline points="{" ".join(seg)}" fill="none" stroke="{color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>')
    every = max(1, math.ceil(n / 10))
    for i, v in enumerate(points):
        if v is not None:
            x, y = xy(i, v)
            out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.4" fill="var(--paper)" stroke="{color}" stroke-width="2"/>')
        if i % every == 0 or i == n - 1:
            out.append(f'<text x="{pad_x + i * step:.1f}" y="{height - 6}" text-anchor="middle">{esc(labels[i])}</text>')
    out.append("</svg>")
    return "".join(out)
