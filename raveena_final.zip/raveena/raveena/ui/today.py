"""My day: today's plan with one-tap controls, the week at a glance, and your fixed commitments."""
from __future__ import annotations

from datetime import date, datetime, timedelta

import streamlit as st

from .. import clock, db, fmt, focus, planner, settings
from .. import tasks as T
from .. import timeparse as tp
from . import common
from .components import chip, chips, empty, esc, page_head, rail, section, week_grid
from .icons import svg

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _hm(t) -> str:
    return t.strftime("%H:%M")


def _take(today: date) -> str:
    sm = planner.day_summary(today)
    if not sm["blocks"]:
        return "Nothing is planned yet. Plan the day and I'll fit your tasks around everything fixed."
    if not sm["remaining"]:
        return f"All {sm['blocks']} sessions are done. Well played."
    done_txt = f", {fmt.duration(sm['done'])} done" if sm["done"] else ""
    return (f"{fmt.plural(sm['blocks'], 'focus session')} today, {fmt.duration(sm['planned'])} planned{done_txt}. "
            f"{sm['remaining']} to go.")


# --------------------------------------------------------------------------- header
def _controls(now: datetime) -> None:
    has_plan = bool(planner.day_summary(now.date())["blocks"])
    c1, c2, c3, _ = st.columns([1.35, 1.25, 1.25, 4])
    if c1.button("Replan from now" if has_plan else "Plan my day", type="primary", icon=":material/auto_awesome:",
                 help="Fits your open tasks around routines and events. Sessions nobody confirmed count as missed."):
        common.run("plan_schedule", scope="today")
        st.rerun()
    if c2.button("Plan the week", icon=":material/date_range:"):
        common.run("plan_schedule", scope="week")
        st.rerun()
    if c3.button("A lighter day", icon=":material/spa:", help="Same priorities, about 60% of the load."):
        common.run("plan_schedule", scope="today", gentle=True)
        st.rerun()


def _heads_up(now: datetime) -> None:
    for r in planner.deadline_watch(now, days=3)[:3]:
        label = fmt.due(r["task"]["due_date"]).lower()
        common.html(f'<div class="heads">{svg("alert", 16)}<span><b>{esc(r["task"]["title"])}</b> is {esc(label)} and still '
                    f'needs about {esc(fmt.duration(r["short"]))} that I can\'t fit yet.</span></div>')


# --------------------------------------------------------------------------- agenda rows
def _task_row(it: dict, now: datetime) -> None:
    bid, today = it["id"], now.date().isoformat()
    s_dt, e_dt = planner._at(today, it["start"]), planner._at(today, it["end"])
    planned_mins = planner._m(it["end"]) - planner._m(it["start"])
    status = it["status"]
    ended = e_dt <= now
    running = s_dt <= now < e_dt
    with st.container(key=f"row-blk-{bid}"):
        c_time, c_main, c_act = st.columns([1.1, 3.4, 2.7], vertical_alignment="center")
        with c_time:
            common.html(f'<div class="time">{esc(fmt.time(it["start"]))}<small>{esc(fmt.time(it["end"]))}</small></div>')
        with c_main:
            cls = "title-line done" if status == "done" else "title-line"
            lock = svg("lock", 12) + " " if it.get("locked") else ""
            tags = [chip(it["category"], cat=it["category"])]
            if it["priority"] <= 2:
                tags.append(chip("Urgent" if it["priority"] == 1 else "High", "warn" if it["priority"] == 1 else ""))
            if status == "done":
                tags.append(chip("Done", "ok", icon="check"))
            elif status in ("missed", "skipped"):
                tags.append(chip(status.capitalize(), "warn"))
            elif running:
                tags.append(chip("Now", "now"))
            elif ended:
                tags.append(chip("Did it happen?", "now"))
            common.html(f'<div class="{cls}">{lock}{esc(it["title"])}</div>' + chips(*tags))
        with c_act:
            if status == "planned":
                _planned_actions(it, planned_mins)
            elif status in ("missed", "skipped"):
                if st.button("Actually done", key=f"ad-{bid}", icon=":material/check:", type="tertiary"):
                    common.run("session_done", block_id=bid)
                    st.rerun()


def _planned_actions(it: dict, planned_mins: int) -> None:
    bid = it["id"]
    a = st.columns(5)
    if a[0].button("", icon=":material/check:", key=f"bd-{bid}", help="Done, as planned", use_container_width=True):
        common.run("session_done", block_id=bid)
        st.rerun()
    with a[1].popover("", icon=":material/timer:", type="tertiary", help="It took a different amount of time", use_container_width=True):
        mins = st.number_input("Minutes it really took", min_value=5, max_value=600, value=int(planned_mins), step=5,
                               key=f"len-{bid}")
        fin = st.checkbox("The whole task is finished", value=False, key=f"fin-{bid}")
        if st.button("Log it", key=f"log-{bid}", type="primary"):
            common.run("session_done", block_id=bid, actual_minutes=int(mins), finished=bool(fin))
            st.rerun()
    if a[2].button("", icon=":material/redo:", key=f"sk-{bid}", type="tertiary", help="Skip it and find another time",
                   use_container_width=True):
        common.run("session_missed", block_id=bid, skipped=True)
        st.rerun()
    if a[3].button("", icon=":material/play_arrow:", key=f"fo-{bid}", type="tertiary", help="Start a focus timer",
                   disabled=bool(focus.active()), use_container_width=True):
        common.run("focus_start", task=str(it["task_id"]), block_id=bid)
        st.rerun()
    with a[4].popover("", icon=":material/event:", type="tertiary", help="Move to another time", use_container_width=True):
        d = st.date_input("Day", value=clock.today(), min_value=clock.today(), key=f"mvd-{bid}")
        t = st.time_input("Start", value=datetime.strptime(it["start"], "%H:%M").time(), step=900, key=f"mvt-{bid}")
        if st.button("Move it", key=f"mv-{bid}", type="primary"):
            out = common.run("move_block", block_id=bid, date=d.isoformat(), start_time=_hm(t))
            if out.ok:
                st.rerun()


def _fixed_row(it: dict) -> None:
    kind = "event" if it["kind"] == "event" else "routine"
    common.html(f'<div class="fixed-row"><span class="time">{esc(fmt.time(it["start"]))}</span>'
                f'<span>{esc(it["title"])} {chip(kind.capitalize())}</span></div>')


def _gap_row(g: dict) -> None:
    common.html(f'<div class="gap-row">Free, {esc(fmt.time(g["start"]))} to {esc(fmt.time(g["end"]))} '
                f'({esc(fmt.duration(g["minutes"]))})</div>')


# --------------------------------------------------------------------------- focus timer
@st.fragment(run_every="1s")
def _timer() -> None:
    secs = focus.elapsed_seconds()
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    common.html(f'<div class="timer">{h}:{m:02d}:{s:02d}</div>' if h else f'<div class="timer">{m:02d}:{s:02d}</div>')


def _focus_panel() -> None:
    f = focus.active()
    if not f:
        return
    t = db.get("tasks", f["task_id"])
    if not t:
        focus.cancel()
        return
    with st.container(key="panel-focus"):
        common.html(section("Focusing") + f'<div class="title-line">{esc(t["title"])}</div>')
        _timer()
        c1, c2 = st.columns(2)
        if c1.button("Stop and log", key="focus-stop", icon=":material/stop:", use_container_width=True):
            common.run("focus_stop", complete=False)
            st.rerun()
        if c2.button("Finished", key="focus-finish", icon=":material/check:", type="primary", use_container_width=True):
            common.run("focus_stop", complete=True)
            st.rerun()


# --------------------------------------------------------------------------- day view
def _day(now: datetime) -> None:
    today = now.date()
    cfg = settings.all()
    left, right = st.columns([1.65, 1], gap="large")
    entries = planner.agenda(today)
    with left:
        common.html(section("Today's plan"))
        if not any(i["kind"] == "task" for i in entries):
            common.html(empty("Nothing scheduled. <b>Plan my day</b> will place your open tasks around your routines, "
                              "or tell me what's on your mind in the chat."))
        merged = sorted(entries + planner.day_gaps(today, entries, now),
                        key=lambda i: (planner._m(i["start"]), 0 if i["kind"] != "gap" else 1))
        for it in merged:
            if it["kind"] == "task":
                _task_row(it, now)
            elif it["kind"] == "gap":
                _gap_row(it)
            else:
                _fixed_row(it)
    with right:
        _focus_panel()
        common.html(section("The shape of the day"))
        common.html(rail(entries, today, now, clock.hm_to_min(cfg["day_start"]), clock.hm_to_min(cfg["day_end"])))


# --------------------------------------------------------------------------- week view
def _week(now: datetime) -> None:
    cfg = settings.all()
    offset = st.session_state.get("week_offset", 0)
    start = clock.monday_of(now.date()) + timedelta(weeks=offset)
    c1, c2, c3, c4 = st.columns([0.55, 0.55, 1.1, 5], vertical_alignment="center")
    if c1.button("", icon=":material/chevron_left:", key="wk-prev", help="Previous week"):
        st.session_state["week_offset"] = offset - 1
        st.rerun()
    if c2.button("", icon=":material/chevron_right:", key="wk-next", help="Next week"):
        st.session_state["week_offset"] = offset + 1
        st.rerun()
    if c3.button("This week", key="wk-now", disabled=offset == 0):
        st.session_state["week_offset"] = 0
        st.rerun()
    with c4:
        common.html(f'<div class="h-section" style="margin:0">{esc(fmt.week_range(start))}</div>')
    days = [(start + timedelta(days=i), planner.agenda(start + timedelta(days=i))) for i in range(7)]
    common.html(week_grid(days, now, clock.hm_to_min(cfg["day_start"]), clock.hm_to_min(cfg["day_end"])))

    waiting = planner.unscheduled(now)
    if waiting:
        common.html(section("Waiting for a slot", "open work with no time planned yet"))
        for r in waiting[:8]:
            t = r["task"]
            overdue = (t["due_date"] or "9999") < now.date().isoformat()
            common.html(f'<div class="fixed-row"><span class="time" style="min-width:4.6rem">{esc(fmt.duration(r["short"]))}</span>'
                        f'<span>{esc(t["title"])} {chip(fmt.due(t["due_date"]), "warn" if overdue else "")}</span></div>')
        if len(waiting) > 8:
            st.caption(f"and {len(waiting) - 8} more")


# --------------------------------------------------------------------------- routines & events
@st.dialog("Remove this?")
def _confirm_remove(kind: str, item_id: int, title: str) -> None:
    st.write(f"Remove **{title}**? Raveena will stop planning around it.")
    c1, c2 = st.columns(2)
    if c1.button("Remove", type="primary", use_container_width=True):
        common.run("delete_calendar_item", kind=kind, id=item_id)
        st.rerun()
    if c2.button("Keep it", use_container_width=True):
        st.rerun()


def _routines(now: datetime) -> None:
    left, right = st.columns([1.3, 1], gap="large")
    with left:
        common.html(section("Weekly routines", "I plan around these every week"))
        routines = T.list_routines()
        if not routines:
            common.html(empty("No routines yet. Add classes, work hours, meals or the gym and I'll never schedule over them."))
        for r in routines:
            with st.container(key=f"row-rt-{r['id']}"):
                c1, c2 = st.columns([6, 1], vertical_alignment="center")
                with c1:
                    common.html(f'<div class="title-line">{esc(r["title"])}</div><div class="note">'
                                f'{esc(tp.days_label(r["day_list"]))}, {esc(fmt.span(r["start"], r["end"]))}</div>')
                if c2.button("", icon=":material/delete:", key=f"rt-del-{r['id']}", type="tertiary", help="Remove"):
                    _confirm_remove("routine", r["id"], r["title"])
        common.html(section("Coming up", "one-off events in the next month"))
        events = T.events_between(now.date(), now.date() + timedelta(days=30))
        if not events:
            common.html(empty("No events in the next month."))
        for e in events:
            with st.container(key=f"row-ev-{e['id']}"):
                c1, c2 = st.columns([6, 1], vertical_alignment="center")
                with c1:
                    common.html(f'<div class="title-line">{esc(e["title"])}</div><div class="note">'
                                f'{esc(fmt.day(e["date"]))}, {esc(fmt.span(e["start"], e["end"]))}</div>')
                if c2.button("", icon=":material/delete:", key=f"ev-del-{e['id']}", type="tertiary", help="Remove"):
                    _confirm_remove("event", e["id"], e["title"])
    with right:
        with st.form("add_routine", clear_on_submit=True):
            st.markdown("**Add a routine**")
            title = st.text_input("What is it?", placeholder="Gym")
            days = st.multiselect("Which days?", DAYS, default=["Mon", "Wed", "Fri"])
            c1, c2 = st.columns(2)
            start = c1.time_input("From", value=datetime.strptime("18:00", "%H:%M").time(), step=900)
            end = c2.time_input("To", value=datetime.strptime("19:00", "%H:%M").time(), step=900)
            if st.form_submit_button("Add routine", use_container_width=True):
                out = common.run("add_routine", title=title, days=[DAYS.index(d) for d in days],
                                 start_time=_hm(start), end_time=_hm(end))
                if out.ok:
                    st.rerun()
        with st.form("add_event", clear_on_submit=True):
            st.markdown("**Add a one-off event**")
            title = st.text_input("What is it?", placeholder="Dentist", key="ev_title")
            on = st.date_input("Day", value=now.date() + timedelta(days=1), min_value=now.date())
            c1, c2 = st.columns(2)
            start = c1.time_input("From", value=datetime.strptime("15:00", "%H:%M").time(), step=900, key="ev_from")
            end = c2.time_input("To", value=datetime.strptime("16:00", "%H:%M").time(), step=900, key="ev_to")
            if st.form_submit_button("Add event", use_container_width=True):
                out = common.run("add_event", title=title, date=on.isoformat(), start_time=_hm(start),
                                 end_time=_hm(end))
                if out.ok:
                    st.rerun()


# --------------------------------------------------------------------------- page
def render() -> None:
    now = clock.now()
    common.html(page_head(fmt.long_date(now.date()), _take(now.date())))
    _controls(now)
    _heads_up(now)
    view = st.segmented_control("View", ["Day", "Week", "Routines"], default="Day", key="today_view",
                                label_visibility="collapsed") or "Day"
    if view == "Day":
        _day(now)
    elif view == "Week":
        _week(now)
    else:
        _routines(now)
