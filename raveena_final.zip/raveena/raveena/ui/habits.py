"""Habits: gentle daily tracking for water, study, sleep, or anything you choose. Plus mood check-ins."""
from __future__ import annotations

from datetime import timedelta

import streamlit as st

from .. import clock, mood, trackers
from .. import tasks as T
from . import common
from .components import bar, chip, chips, dots, empty, esc, line, page_head, section
from .icons import svg

MOODS = [(1, "Very low", "sentiment_very_dissatisfied"), (2, "Low", "sentiment_dissatisfied"), (3, "Okay", "sentiment_neutral"),
         (4, "Good", "sentiment_satisfied"), (5, "Great", "sentiment_very_satisfied")]


# --------------------------------------------------------------------------- mood
def _mood_section() -> None:
    common.html(section("How are you feeling?", "a ten-second check-in"))
    last = mood.latest()
    c1, c2 = st.columns([1, 2])
    energy = c1.select_slider("Energy", options=[1, 2, 3, 4, 5], value=3, format_func=lambda v: mood.ENERGY_LABELS[v],
                              key="mood_energy")
    note = c2.text_input("Anything you'd like to note?", placeholder="Optional, just for you and Raveena", key="mood_note")
    cols = st.columns(5)
    for (score, word, icon), col in zip(MOODS, cols):
        if col.button(word, icon=f":material/{icon}:", key=f"hm-{score}", use_container_width=True):
            common.run("log_mood", mood=score, energy=energy, note=note, explicit=True)
            st.session_state["mood_logged"] = score
            st.rerun()
    logged = st.session_state.get("mood_logged")
    if logged and logged <= 2:
        common.html('<div class="note" style="margin:.6rem 0">Thank you for telling me. Hard days count too.</div>')
        a, b, _ = st.columns([1.5, 1.5, 3])
        if a.button("Lighten today", icon=":material/spa:", key="hm-lighten"):
            common.run("plan_schedule", scope="today", gentle=True)
            st.session_state.pop("mood_logged", None)
            st.rerun()
        if b.button("Talk to Raveena", icon=":material/chat_bubble:", key="hm-talk"):
            st.session_state.pop("mood_logged", None)
            common.queue_prompt("I'm having a hard day and I'd like to talk.")
    elif last:
        age = clock.now() - clock.parse_iso(last["ts"])
        ago = f"{int(age.total_seconds() // 3600)} h ago" if age >= timedelta(hours=1) else "just now"
        st.caption(f"Last check-in: {mood.MOOD_LABELS[last['mood']].lower()}"
                   + (f", energy {mood.ENERGY_LABELS[last['energy']].lower()}" if last["energy"] else "") + f", {ago}.")

    daily = mood.daily_averages(14)
    if len(daily) >= 2:
        days = [clock.today() - timedelta(days=13 - i) for i in range(14)]
        common.html('<div class="chart-wrap">' + line([daily[d][0] if d in daily else None for d in days],
                    [str(d.day) for d in days], y_labels={1: "Low", 3: "Okay", 5: "Great"}) + "</div>")
        ms = mood.summary(7)
        if ms["avg_mood"] is not None:
            delta = ""
            if ms["delta"] is not None and abs(ms["delta"]) >= 0.3:
                delta = f", {'up' if ms['delta'] > 0 else 'down'} {abs(ms['delta']):.1f} on the week before"
            st.caption(f"This week your mood averaged {ms['avg_mood']:.1f} out of 5{delta}.")


# --------------------------------------------------------------------------- trackers
@st.dialog("Edit habit")
def _edit(tid: int) -> None:
    t = trackers.get_tracker(tid)
    if not t:
        return
    name = st.text_input("Name", value=t["name"])
    c1, c2, c3 = st.columns(3)
    unit = c1.text_input("Unit", value=t["unit"] or "")
    target = c2.number_input("Daily goal", min_value=0.1, value=float(t["target"]), step=float(t["step"] or 1))
    step = c3.number_input("Per tap", min_value=0.1, value=float(t["step"] or 1), step=0.5)
    icon = st.segmented_control("Icon", trackers.ICONS, default=t["icon"], format_func=lambda k: k, key=f"ic-{tid}") or t["icon"]
    b1, b2, _ = st.columns([1.2, 1.2, 2])
    if b1.button("Save", type="primary", use_container_width=True):
        trackers.update_tracker(tid, name=name.strip() or t["name"], unit=unit, target=target, step=step, icon=icon)
        st.rerun()
    if b2.button("Delete", use_container_width=True):
        st.session_state[f"confirm-trk-{tid}"] = True
    if st.session_state.get(f"confirm-trk-{tid}"):
        st.warning(f"This deletes {t['name']} and all its history. You can undo it straight after.")
        if st.button("Yes, delete it", key=f"trk-yes-{tid}", type="primary"):
            common.run("delete_tracker", tracker=str(tid))
            st.session_state.pop(f"confirm-trk-{tid}", None)
            st.rerun()


def _row(t: dict) -> None:
    p = trackers.progress(t)
    streak = trackers.streak(t)
    hist = trackers.history(t, 14)
    color = t["color"]
    with st.container(key=f"row-trk-{t['id']}"):
        c1, c2, c3 = st.columns([2.5, 3.1, 3.4], vertical_alignment="center")
        with c1:
            tags = []
            if streak >= 2:
                tags.append(chip(f"{streak}-day streak", "ok", icon="spark"))
            if p["met"]:
                tags.append(chip("Goal met", "ok", icon="check"))
            common.html(f'<div style="display:flex;gap:.8rem;align-items:center"><span class="trk-ico" style="--c:{color}">'
                        f'{svg(t["icon"], 18)}</span><div><div class="title-line">{esc(t["name"])}</div>{chips(*tags)}</div></div>')
        with c2:
            if t["kind"] == "check":
                state = "Done today" if p["met"] else "Not yet today"
                common.html(f'<div class="note">{state}</div>{dots(hist, t["target"], color)}')
            else:
                common.html(f'<div class="note"><b style="color:var(--ink)">{esc(trackers.format_value(t, p["total"]))}</b> of '
                            f'{esc(trackers.format_value(t, t["target"]))}</div>'
                            f'<div style="margin:.35rem 0 .1rem">{bar(p["pct"], color)}</div>{dots(hist, t["target"], color)}')
        with c3:
            _actions(t, p)


def _actions(t: dict, p: dict) -> None:
    tid, kind = t["id"], t["kind"]
    if kind == "check":
        a, b = st.columns([3, 0.7], vertical_alignment="center")
        if a.button("Done today" if p["met"] else "Mark done", key=f"ck-{tid}", icon=":material/check:",
                    type="secondary" if p["met"] else "primary", use_container_width=True):
            trackers.toggle_check(t)
            st.rerun()
    elif kind == "once":
        a, b = st.columns([3, 0.7], vertical_alignment="center")
        with a.popover("Log it", icon=":material/edit_note:", use_container_width=True):
            v = st.number_input(f"{t['name']} ({t['unit'] or 'units'})", min_value=0.0, max_value=1000.0,
                                value=float(p["total"] or t["target"]), step=float(t["step"] or 0.5), key=f"once-{tid}")
            if st.button("Save", key=f"once-go-{tid}", type="primary"):
                common.run("log_activity", tracker=t["name"], value=v, quiet=True)
                st.rerun()
    else:
        step = float(t["step"] or 1)
        a, b, c, d, e = st.columns([1.3, 1.3, 0.62, 0.62, 0.62], vertical_alignment="center")
        for col, mult in ((a, 1), (b, 2)):
            amount = step * mult
            label = "+" + trackers.format_value(t, amount)
            if col.button(label, key=f"add-{tid}-{mult}", use_container_width=True):
                common.run("log_activity", tracker=t["name"], value=amount, quiet=True)
                st.rerun()
        with c.popover("", icon=":material/edit:", type="tertiary", help="Log another amount", use_container_width=True):
            v = st.number_input(f"How much ({t['unit'] or 'units'})?", min_value=0.0, max_value=100000.0, value=step,
                                step=step, key=f"cust-{tid}")
            if st.button("Add", key=f"cust-go-{tid}", type="primary"):
                common.run("log_activity", tracker=t["name"], value=v, quiet=True)
                st.rerun()
        if d.button("", icon=":material/undo:", key=f"un-{tid}", type="tertiary", help="Undo the last entry",
                    use_container_width=True, disabled=p["total"] <= 0):
            trackers.undo_last(t)
            st.rerun()
        b = e
    if b.button("", icon=":material/tune:", key=f"ed-{tid}", type="tertiary", help="Edit this habit", use_container_width=True):
        _edit(tid)


def _add_form() -> None:
    with st.expander("Track something new"):
        with st.form("new_tracker", clear_on_submit=True, border=False):
            c1, c2 = st.columns([2, 1])
            name = c1.text_input("Name", placeholder="Reading")
            kind = c2.selectbox("Kind", list(trackers.KINDS), format_func=lambda k: {"sum": "Adds up", "once": "One value a day", "check": "Done or not"}[k])
            d1, d2, d3 = st.columns(3)
            unit = d1.text_input("Unit", placeholder="pages, min, ml")
            target = d2.number_input("Daily goal", min_value=0.1, value=20.0, step=1.0)
            step = d3.number_input("Per tap", min_value=0.1, value=5.0, step=1.0)
            icon = st.segmented_control("Icon", trackers.ICONS, default="spark", key="new_icon") or "spark"
            src = st.selectbox("Count time logged on tasks of this category (optional)", ["None"] + T.CATEGORIES)
            if st.form_submit_button("Start tracking", type="primary"):
                out = common.run("create_tracker", name=name, kind=kind, unit=unit, target=target, step=step,
                                 count_time_from_category=None if src == "None" else src)
                if out.ok:
                    t = trackers.find_tracker(name)
                    trackers.update_tracker(t["id"], icon=icon)
                    st.rerun()


def render() -> None:
    common.html(page_head("Habits", "Small things, counted gently. A streak is a bonus, never a debt."))
    _mood_section()
    ts = trackers.list_trackers()
    common.html(section("Today"))
    if not ts:
        common.html(empty("Nothing tracked yet. Add water, study time, sleep or anything else below."))
    for t in ts:
        _row(t)
    _add_form()
