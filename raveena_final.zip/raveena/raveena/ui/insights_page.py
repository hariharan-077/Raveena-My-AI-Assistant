"""Insights: what Raveena has noticed, and what she'd suggest you do about it."""
from __future__ import annotations

from datetime import timedelta

import streamlit as st

from .. import brain, clock, fmt, insights, memory, settings, trackers
from . import common
from .components import bar, bars, empty, esc, page_head, section


def _suggestions() -> None:
    sugs = insights.suggestions(14)
    common.html(section("What I'd suggest"))
    if not sugs:
        common.html(empty("Nothing to flag right now. Keep going, and I'll speak up when I notice something."))
    for i, s in enumerate(sugs):
        with st.container(key=f"row-sug-{i}"):
            a, b = st.columns([5, 1.7], vertical_alignment="center")
            common.html(f'<div class="sug"><h4><span class="tag {esc(s.tone)}"></span>{esc(s.title)}</h4><p>{esc(s.detail)}</p></div>', a)
            if s.action and s.action.get("label"):
                if b.button(s.action["label"], key=f"sa-{i}", type="primary" if s.tone == "tip" else "secondary",
                            use_container_width=True):
                    if s.action["type"] == "chat":
                        common.queue_prompt(s.action["prompt"])
                    else:
                        st.toast(insights.apply(s), icon=":material/check:")
                        st.rerun()


def _review() -> None:
    common.html(section("Weekly review", "a short, honest look back"))
    rv = st.session_state.get("review")
    if rv:
        paras = "".join(f"<p>{esc(p)}</p>" for p in rv["text"].split("\n\n") if p.strip())
        common.html(f'<div class="review">{paras}</div>')
        a, b, _ = st.columns([1.5, 1.2, 4])
        if a.button("Keep in my memory", key="keep-review", icon=":material/bookmark:"):
            memory.remember(f"Weekly review {fmt.dm(clock.today())}: " + rv["text"].replace("\n", " ")[:340],
                            "reflection", 2, source="raveena")
            st.toast("Saved as a reflection.", icon=":material/check:")
        if b.button("Write a new one", key="new-review", type="tertiary"):
            st.session_state.pop("review")
            st.rerun()
        st.caption("Written with Gemini." if rv["mode"] == "ai" else "Written by Lite mode. Connect Gemini for a more personal review.")
    else:
        if st.button("Write my weekly review", icon=":material/edit_note:", key="make-review"):
            with st.spinner("Looking back over your week…"):
                text, mode = brain.weekly_review()
            st.session_state["review"] = {"text": text, "mode": mode}
            st.rerun()


def _charts() -> None:
    cfg = settings.all()
    st_ = insights.stats(14)
    common.html(section("The last two weeks"))
    left, right = st.columns(2, gap="large")
    days = [clock.today() - timedelta(days=13 - i) for i in range(14)]
    with left:
        st.markdown("**Focused time each day**")
        vals = [round(st_["focus_by_day"].get(d.isoformat(), 0) / 60, 1) for d in days]
        if any(vals):
            common.html(bars(vals, [str(d.day) for d in days], goal=cfg["max_focus_minutes"] / 60,
                             value_fmt=lambda v: f"{v:g}h"))
            st.caption(f"{fmt.duration(st_['focus_minutes'])} in total. The dashed line is your daily plan limit.")
        else:
            common.html(empty("Time you log on tasks shows up here."))
    with right:
        st.markdown("**Follow-through by time of day**")
        parts = st_["parts"]
        if any(v["ended"] for v in parts.values()):
            rows = ""
            for name, v in parts.items():
                pct = v["done"] / v["ended"] if v["ended"] else 0
                rows += (f'<div style="margin:.6rem 0"><div class="note" style="display:flex;justify-content:space-between">'
                         f'<span>{name.capitalize()}</span><span>{v["done"]} of {v["ended"]}</span></div>'
                         f'<div style="margin-top:.25rem">{bar(pct, "var(--peacock)")}</div></div>')
            common.html(rows)
        else:
            common.html(empty("Once you've ticked off or missed a few sessions, you'll see when you follow through best."))
    l2, r2 = st.columns(2, gap="large")
    with l2:
        st.markdown("**Habits (days goal was met, out of 14)**")
        rows = ""
        for t in trackers.list_trackers():
            met = sum(1 for _, v in trackers.history(t, 14) if trackers.met(t, v))
            rows += (f'<div style="margin:.6rem 0"><div class="note" style="display:flex;justify-content:space-between">'
                     f'<span>{esc(t["name"])}</span><span>{met} of 14</span></div><div style="margin-top:.25rem">'
                     f'{bar(met / 14, t["color"])}</div></div>')
        common.html(rows or empty("No habits tracked yet."))
    with r2:
        st.markdown("**What I've learned about you**")
        lines = []
        for cat, f in insights.pace().items():
            if cat != "*" and abs(f - 1) >= 0.08:
                lines.append(f"<b>{esc(cat)}</b> tasks take you about {f:.1f}x your estimates.")
        lp = insights.learned_peak()
        if lp:
            lines.append(f"Your best focus hours are around <b>{insights._fmt_h(lp[0])} to {insights._fmt_h(lp[1])}</b>.")
        mems = len(memory.list_all())
        lines.append(f"I remember <b>{mems}</b> things about you.")
        common.html("".join(f'<div class="note" style="margin:.5rem 0">{x}</div>' for x in lines))


def render() -> None:
    common.html(page_head("Insights", insights.week_sentence(7)))
    _review()
    _suggestions()
    _charts()
