"""Forgiving parsing of dates, times, durations, priorities and weekdays from plain English.

Used by the offline ("Lite") brain, the quick-add box and as a safety net for tool
arguments. Every ``extract_*`` function returns ``(value, remaining_text)`` so callers can
strip the matched phrase out of a task title.

Dates are read day-first (15/10 means 15 October).
"""
from __future__ import annotations

import calendar
import re
from datetime import date, timedelta

WEEKDAYS = {
    "monday": 0, "mon": 0, "tuesday": 1, "tues": 1, "tue": 1, "wednesday": 2, "wed": 2,
    "thursday": 3, "thurs": 3, "thur": 3, "thu": 3, "friday": 4, "fri": 4,
    "saturday": 5, "sat": 5, "sunday": 6, "sun": 6,
}
MONTHS = {
    "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3, "april": 4, "apr": 4,
    "may": 5, "june": 6, "jun": 6, "july": 7, "jul": 7, "august": 8, "aug": 8,
    "september": 9, "sept": 9, "sep": 9, "october": 10, "oct": 10, "november": 11, "nov": 11,
    "december": 12, "dec": 12,
}
NUMBER_WORDS = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}

_WD = "|".join(sorted(WEEKDAYS, key=len, reverse=True))
_MO = "|".join(sorted(MONTHS, key=len, reverse=True))
_NUMW = "|".join(NUMBER_WORDS)
_PREP = r"(?:\b(?P<prep>by|on|before|until|till|due|for)\s+)?"
_FLAGS = re.IGNORECASE


def _clean(s: str) -> str:
    s = re.sub(r"\s+", " ", s).strip(" ,;:-–—")
    return s.strip()


def _cut(text: str, m: re.Match) -> str:
    return _clean(text[: m.start()] + " " + text[m.end():])


# ---------------------------------------------------------------------------- dates
def _add_months(d: date, n: int) -> date:
    month = d.month - 1 + n
    year = d.year + month // 12
    month = month % 12 + 1
    return date(year, month, min(d.day, calendar.monthrange(year, month)[1]))


def _safe_date(y: int, m: int, d: int) -> date | None:
    try:
        return date(y, m, d)
    except ValueError:
        return None


def _future_year(today: date, m: int, d: int, y: int | None) -> date | None:
    if y is not None:
        if y < 100:
            y += 2000
        return _safe_date(y, m, d)
    cand = _safe_date(today.year, m, d)
    if cand and cand < today:
        cand = _safe_date(today.year + 1, m, d)
    return cand


def _weekday_date(today: date, target: int, mod: str | None, prep: str | None) -> date:
    delta = (target - today.weekday()) % 7
    if delta == 0:
        by_like = (prep or "").lower() in {"by", "before", "until", "till", "due"}
        delta = 0 if (by_like or (mod or "").lower() == "this") else 7
    d = today + timedelta(days=delta)
    if (mod or "").lower() == "next" and (d - today).days < 7 and d.weekday() >= today.weekday():
        d += timedelta(days=7)
    return d


def _date_rules(today: date):
    def num(s: str) -> int:
        return int(s) if s.isdigit() else NUMBER_WORDS[s.lower()]

    def iso(m):
        return _safe_date(int(m["y"]), int(m["m"]), int(m["d"]))

    def in_n(m):
        n, unit = num(m["n"]), m["unit"].lower()
        if unit.startswith("day"):
            return today + timedelta(days=n)
        if unit.startswith("week"):
            return today + timedelta(weeks=n)
        return _add_months(today, n)

    def next_week(_m):
        return today + timedelta(days=7 - today.weekday())

    def weekend(_m):
        return today + timedelta(days=(5 - today.weekday()) % 7)

    def eow(_m):
        return today + timedelta(days=max(0, 4 - today.weekday()))

    def eom(_m):
        return date(today.year, today.month, calendar.monthrange(today.year, today.month)[1])

    def wd(m):
        return _weekday_date(today, WEEKDAYS[m["wd"].lower()], m["mod"], m["prep"])

    def d_mon(m):
        return _future_year(today, MONTHS[m["mo"].lower()], int(m["d"]), int(m["y"]) if m["y"] else None)

    def slash(m):
        a, b = int(m["a"]), int(m["b"])
        day, mon = (a, b) if b <= 12 else (b, a)
        if mon > 12 or day > 31:
            return None
        return _future_year(today, mon, day, int(m["y"]) if m["y"] else None)

    return [
        (rf"{_PREP}\b(?P<y>\d{{4}})-(?P<m>\d{{1,2}})-(?P<d>\d{{1,2}})\b", iso),
        (rf"{_PREP}\bday after tomorrow\b", lambda m: today + timedelta(days=2)),
        (rf"{_PREP}\b(?:tomorrow|tmrw|tmr)\b", lambda m: today + timedelta(days=1)),
        (rf"{_PREP}\b(?:today|tonight|this (?:morning|afternoon|evening))\b", lambda m: today),
        (rf"{_PREP}\bin (?P<n>\d+|{_NUMW}) (?P<unit>days?|weeks?|months?)\b", in_n),
        (rf"{_PREP}\bnext week\b", next_week),
        (rf"{_PREP}\b(?:this )?weekend\b", weekend),
        (rf"{_PREP}\bend of (?:the |this )?week\b", eow),
        (rf"{_PREP}\bend of (?:the |this )?month\b", eom),
        (rf"{_PREP}\b(?:(?P<mod>next|this|coming)\s+)?(?P<wd>{_WD})\b", wd),
        (rf"{_PREP}\b(?P<d>\d{{1,2}})(?:st|nd|rd|th)?\s+(?:of\s+)?(?P<mo>{_MO})\b(?:,?\s+(?P<y>\d{{4}}))?", d_mon),
        (rf"{_PREP}\b(?P<mo>{_MO})\.?\s+(?P<d>\d{{1,2}})(?:st|nd|rd|th)?\b(?:,?\s+(?P<y>\d{{4}}))?", d_mon),
        (rf"{_PREP}\b(?P<a>\d{{1,2}})[/.](?P<b>\d{{1,2}})(?:[/.](?P<y>\d{{2,4}}))?\b", slash),
    ]


def extract_date(text: str, today: date | None = None) -> tuple[date | None, str]:
    """Find the earliest date phrase. Returns (date, text-with-phrase-removed)."""
    from . import clock
    today = today or clock.today()
    best: tuple[int, re.Match, date] | None = None
    for pattern, resolve in _date_rules(today):
        m = re.search(pattern, text, _FLAGS)
        if not m:
            continue
        value = resolve(m)
        if value is None:
            continue
        if best is None or m.start() < best[0]:
            best = (m.start(), m, value)
    if best is None:
        return None, _clean(text)
    return best[2], _cut(text, best[1])


def parse_date(text: str, today: date | None = None) -> date | None:
    return extract_date(text, today)[0]


# ---------------------------------------------------------------------------- times
def _to_24(h: int, ap: str | None) -> int:
    ap = (ap or "").lower().replace(".", "")
    if ap == "pm" and h < 12:
        return h + 12
    if ap == "am" and h == 12:
        return 0
    return h


_TIME_RE = re.compile(
    r"(?:\b(?:at|by|from|until|till|@)\s*)?"
    r"(?:\b(?P<h>\d{1,2})(?::(?P<m>\d{2}))?\s*(?P<ap>a\.?m\.?|p\.?m\.?)(?![a-z])"
    r"|\b(?P<h24>[01]?\d|2[0-3]):(?P<m24>[0-5]\d)\b"
    r"|\b(?P<word>noon|midnight)\b)", _FLAGS)


def extract_time(text: str) -> tuple[str | None, str]:
    m = _TIME_RE.search(text)
    if not m:
        return None, _clean(text)
    if m["word"]:
        hm = "12:00" if m["word"].lower() == "noon" else "00:00"
    elif m["h"]:
        h = int(m["h"])
        if not 1 <= h <= 12:
            return None, _clean(text)
        hm = f"{_to_24(h, m['ap']):02d}:{int(m['m'] or 0):02d}"
    else:
        hm = f"{int(m['h24']):02d}:{m['m24']}"
    return hm, _cut(text, m)


def parse_time(text: str) -> str | None:
    return extract_time(text)[0]


_RANGE_RE = re.compile(
    r"(?:\b(?:from|between)\s+)?"
    r"\b(?P<h1>\d{1,2})(?::(?P<m1>\d{2}))?\s*(?P<ap1>a\.?m\.?|p\.?m\.?)?"
    r"\s*(?:-|–|—|to|until|till|and)\s*"
    r"(?P<h2>\d{1,2})(?::(?P<m2>\d{2}))?\s*(?P<ap2>a\.?m\.?|p\.?m\.?)?(?![a-z0-9])", _FLAGS)


def extract_time_range(text: str) -> tuple[tuple[str, str] | None, str]:
    """'6-7pm', '9am to 11am', '18:00-19:30' -> ('18:00','19:00') etc."""
    for m in _RANGE_RE.finditer(text):
        h1, h2 = int(m["h1"]), int(m["h2"])
        ap1, ap2 = m["ap1"], m["ap2"]
        has_colon = bool(m["m1"] or m["m2"])
        if not (ap1 or ap2 or has_colon):
            continue                      # "5-6" alone is too ambiguous
        if not ap1 and not ap2:           # 24h clock like 18:00-19:30
            s, e = h1, h2
        else:
            if ap1 and not ap2:
                ap2 = ap1 if (h2 % 12) >= (h1 % 12) or h2 == 12 else ("pm" if ap1.lower().startswith("a") else "am")
            elif ap2 and not ap1:
                ap1 = ap2 if (h1 % 12) <= (h2 % 12) or h1 == 12 else ("am" if ap2.lower().startswith("p") else "pm")
            if not (1 <= h1 <= 12 and 1 <= h2 <= 12):
                continue
            s, e = _to_24(h1, ap1), _to_24(h2, ap2)
        if not (0 <= s <= 23 and 0 <= e <= 24):
            continue
        a = f"{s:02d}:{int(m['m1'] or 0):02d}"
        b = f"{e:02d}:{int(m['m2'] or 0):02d}"
        if a < b:
            return (a, b), _cut(text, m)
    return None, _clean(text)


def normalize_time(value: str | None) -> str | None:
    """Accept '9', '9am', '9:30 pm', '21:00', 'noon' and return 'HH:MM' (or None)."""
    if value is None:
        return None
    v = str(value).strip().lower()
    if not v:
        return None
    hm, rest = extract_time(v)
    if hm and not rest:
        return hm
    m = re.fullmatch(r"(\d{1,2})(?::(\d{2}))?", v)
    if m and 0 <= int(m[1]) <= 23 and int(m[2] or 0) < 60:
        return f"{int(m[1]):02d}:{int(m[2] or 0):02d}"
    return hm


# ---------------------------------------------------------------------------- durations
_DUR_RULES = [
    # specific phrases first so "half an hour" isn't read as "an hour"
    (re.compile(r"(?:\bfor\s+)?\bhalf an hour\b|\bhalf hour\b", _FLAGS), lambda m: 30),
    (re.compile(r"(?:\bfor\s+)?\ba quarter of an hour\b|\bquarter hour\b", _FLAGS), lambda m: 15),
    (re.compile(r"(?:\bfor\s+)?\b(?:an|one)\s+hour\b", _FLAGS), lambda m: 60),
    (re.compile(r"(?:\bfor\s+)?\b(?P<h>\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours)\s*(?:and\s*)?(?P<m>\d{1,2})\s*(?:m|min|mins|minute|minutes)?\b", _FLAGS),
     lambda m: float(m["h"]) * 60 + int(m["m"])),
    (re.compile(r"(?:\bfor\s+)?\b(?P<h>\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours)\b", _FLAGS),
     lambda m: float(m["h"]) * 60),
    (re.compile(r"(?:\bfor\s+)?\b(?P<m>\d{1,3})\s*(?:m|min|mins|minute|minutes)\b", _FLAGS),
     lambda m: int(m["m"])),
]


def extract_duration(text: str) -> tuple[int | None, str]:
    for rx, to_minutes in _DUR_RULES:
        m = rx.search(text)
        if not m:
            continue
        mins = int(round(to_minutes(m)))
        if 1 <= mins <= 12 * 60:
            return mins, _cut(text, m)
    return None, _clean(text)


def parse_duration(text: str) -> int | None:
    return extract_duration(text)[0]


# ---------------------------------------------------------------------------- priority
_PRIORITY_RULES = [
    (re.compile(r"\bp([1-4])\b", _FLAGS), None),
    (re.compile(r"\b(?:urgent(?:ly)?|asap|critical|top priority|emergency)\b", _FLAGS), 1),
    (re.compile(r"\b(?:high[- ]priority|important|high priority)\b", _FLAGS), 2),
    (re.compile(r"\b(?:low[- ]priority|no rush|whenever|someday|not urgent|when i can)\b", _FLAGS), 4),
    (re.compile(r"\b(?:medium|normal)[- ]priority\b", _FLAGS), 3),
]


def extract_priority(text: str) -> tuple[int | None, str]:
    for rx, value in _PRIORITY_RULES:
        m = rx.search(text)
        if m:
            return (int(m.group(1)) if value is None else value), _cut(text, m)
    return None, _clean(text)


# ---------------------------------------------------------------------------- weekdays
_DAY_NAME = rf"(?:{_WD})s?"


def parse_days(text: str) -> list[int] | None:
    """'mon wed fri', 'weekdays', 'every day', 'tuesdays and thursdays', 'mon-thu'."""
    t = text.lower()
    if re.search(r"\b(?:every ?day|daily|each day|all week|7 days)\b", t):
        return list(range(7))
    if re.search(r"\bweekdays?\b", t):
        return list(range(5))
    if re.search(r"\bweekends?\b", t):
        return [5, 6]
    m = re.search(rf"\b({_WD})s?\s*(?:-|–|to|through|thru)\s*({_WD})s?\b", t)
    if m:
        a, b = WEEKDAYS[m[1]], WEEKDAYS[m[2]]
        days = list(range(a, b + 1)) if a <= b else list(range(a, 7)) + list(range(0, b + 1))
        return sorted(set(days))
    found = sorted({WEEKDAYS[x.rstrip("s") if x.rstrip("s") in WEEKDAYS else x]
                    for x in re.findall(rf"\b({_DAY_NAME})\b", t)})
    return found or None


DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def days_label(days: list[int]) -> str:
    days = sorted(days)
    if days == list(range(7)):
        return "Every day"
    if days == list(range(5)):
        return "Weekdays"
    if days == [5, 6]:
        return "Weekends"
    return ", ".join(DAY_NAMES[d] for d in days)
