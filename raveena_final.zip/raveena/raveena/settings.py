"""User settings: your rhythm, Raveena's behaviour, and the automation switches."""
from __future__ import annotations

from typing import Any

from . import clock, config, db

DEFAULTS: dict[str, Any] = {
    # you
    "onboarded": False,
    "name": "",
    "timezone": "",              # "" = this computer's zone
    "time_format": "12h",        # "12h" | "24h"
    "crisis_contact": "",        # someone / somewhere Raveena may point you to if you're struggling
    # your rhythm
    "wake_time": "07:00",
    "sleep_time": "23:00",
    "day_start": "08:00",        # planner window
    "day_end": "22:00",
    "peak_start": "09:00",       # best hours for deep focus
    "peak_end": "12:00",
    "max_focus_minutes": 300,    # most task time to plan on a weekday
    "weekend_load": 0.5,         # share of that on Sat/Sun
    "block_max": 90,
    "block_min": 25,
    "break_minutes": 10,
    # Raveena
    "tone": "warm",              # warm | coach | concise
    "use_ai": True,
    "model": config.DEFAULT_MODEL,
    "effort": "low",
    "share_mood_notes": True,    # include your mood notes in what the AI model sees
    # automations (all reversible, all logged)
    "auto_daily_plan": True,
    "auto_rollover": True,
    "morning_briefing": True,
    "auto_memory": True,
    "auto_mood": True,
}

TIME_KEYS = {"wake_time", "sleep_time", "day_start", "day_end", "peak_start", "peak_end"}


def get(key: str) -> Any:
    raw = db.scalar("SELECT value FROM settings WHERE key=?", (key,))
    if raw is None:
        return DEFAULTS.get(key)
    return db.loads(raw, DEFAULTS.get(key))


def all() -> dict[str, Any]:
    out = dict(DEFAULTS)
    for r in db.rows("SELECT key,value FROM settings"):
        if r["key"] in DEFAULTS:
            out[r["key"]] = db.loads(r["value"], DEFAULTS[r["key"]])
    return out


def set(key: str, value: Any) -> None:  # noqa: A001 - mirrors dict-style API
    old = db.scalar("SELECT value FROM settings WHERE key=?", (key,))
    db.log_setting_change(key, old)
    db.run("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)", (key, db.dumps(value)))
    if key == "timezone":
        clock.set_timezone(value)


def update(values: dict[str, Any]) -> None:
    with db.transaction():
        for k, v in values.items():
            set(k, v)


def apply_runtime() -> None:
    """Push stored settings into process-wide helpers (timezone)."""
    clock.set_timezone(get("timezone"))


def display_name() -> str:
    return (get("name") or "").strip() or "there"
