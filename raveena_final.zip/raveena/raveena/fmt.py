"""Human-friendly formatting for times, dates and durations."""
from __future__ import annotations

from datetime import date, timedelta

from . import clock, settings


# Portable date pieces: strftime's "%-d" (no leading zero) fails on Windows, so build them by hand.
def dm(d: date) -> str:
    return f"{d.day} {d.strftime('%b')}"


def wdm(d: date) -> str:
    return f"{d.strftime('%a')} {d.day} {d.strftime('%b')}"


def dmy(d: date) -> str:
    return f"{d.day} {d.strftime('%b %Y')}"


def full_date(d) -> str:
    return f"{d.strftime('%A')} {d.day} {d.strftime('%B %Y')}"


def time(hm: str | int | None) -> str:
    """'14:30' (or minutes since midnight) -> '2:30 pm' or '14:30' per the user's setting."""
    if hm is None or hm == "":
        return ""
    if isinstance(hm, int):
        hm = clock.min_to_hm(hm)
    h, m = (int(x) for x in str(hm).split(":")[:2])
    if settings.get("time_format") == "24h":
        return f"{h:02d}:{m:02d}"
    suffix = "am" if h < 12 else "pm"
    h12 = h % 12 or 12
    return f"{h12}:{m:02d} {suffix}" if m else f"{h12} {suffix}"


def span(start: str, end: str) -> str:
    return f"{time(start)} to {time(end)}"


def duration(minutes: int | float | None) -> str:
    if not minutes:
        return "0m"
    minutes = int(round(minutes))
    h, m = divmod(minutes, 60)
    if h and m:
        return f"{h}h {m}m"
    return f"{h}h" if h else f"{m}m"


def day(d: date | str, today: date | None = None) -> str:
    """'Today', 'Tomorrow', 'Fri 16 Oct', or '3 Nov' for farther dates."""
    if isinstance(d, str):
        d = date.fromisoformat(d)
    today = today or clock.today()
    delta = (d - today).days
    if delta == 0:
        return "Today"
    if delta == 1:
        return "Tomorrow"
    if delta == -1:
        return "Yesterday"
    if 0 < delta < 7:
        return wdm(d)
    return dm(d) if d.year == today.year else dmy(d)


def due(d: date | str | None, today: date | None = None) -> str:
    if not d:
        return "No date"
    if isinstance(d, str):
        d = date.fromisoformat(d)
    today = today or clock.today()
    delta = (d - today).days
    if delta < 0:
        n = -delta
        return f"Overdue by {n} day{'s' if n != 1 else ''}"
    if delta == 0:
        return "Due today"
    if delta == 1:
        return "Due tomorrow"
    return f"Due {day(d, today)}"


def long_date(d: date) -> str:
    return f"{d.strftime('%A')} {d.day} {d.strftime('%B')}"


def greeting(hour: int) -> str:
    if hour < 5:
        return "Still up"
    if hour < 12:
        return "Good morning"
    if hour < 17:
        return "Good afternoon"
    if hour < 21:
        return "Good evening"
    return "Good evening"


def week_range(start: date) -> str:
    end = start + timedelta(days=6)
    if start.month == end.month:
        return f"{start.day}–{dm(end)}"
    return f"{dm(start)} – {dm(end)}"


def plural(n: int, word: str, plural_word: str | None = None) -> str:
    return f"{n} {word if n == 1 else (plural_word or word + 's')}"


def day_phrase(d: date | str, today: date | None = None) -> str:
    """For use mid-sentence: 'today', 'tomorrow', but 'Fri 16 Oct' keeps its capitals."""
    label = day(d, today)
    return label.lower() if label in ("Today", "Tomorrow", "Yesterday") else label
