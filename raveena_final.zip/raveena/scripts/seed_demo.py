"""Fill a *separate* demo database so you can explore the interface with realistic data.

    RAVEENA_DATA_DIR=data-demo python scripts/seed_demo.py
    RAVEENA_DATA_DIR=data-demo streamlit run app.py

It never touches your real data (``data/``). Delete the ``data-demo`` folder to start over.
"""
from __future__ import annotations

import os
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

os.environ.setdefault("RAVEENA_DATA_DIR", "data-demo")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from raveena import clock, conversation, db, memory, mood, planner, settings, trackers  # noqa: E402
from raveena import tasks as T  # noqa: E402


def main() -> None:
    random.seed(7)
    db.init()
    if db.scalar("SELECT COUNT(*) FROM tasks", default=0):
        print("The demo database already has data. Delete the folder to reseed.")
        return
    now = clock.now()
    today = now.date()
    settings.update({"name": "Asha", "onboarded": True, "peak_start": "09:00", "peak_end": "12:00",
                     "crisis_contact": "your sister Meera"})

    # fixed commitments
    T.add_routine("Lectures", [0, 2, 4], "10:00", "12:00", "Study")
    T.add_routine("Lunch", list(range(7)), "13:00", "14:00", "Routine")
    T.add_routine("Gym", [0, 2, 4], "18:00", "19:00", "Health")
    T.add_routine("Wind down", list(range(7)), "21:30", "22:00", "Routine")
    T.add_event("Dentist", today + timedelta(days=2), "15:00", "16:00", "Health")

    # history: two weeks of finished work, slower than estimated for Study, mostly after 3 pm
    for back in range(14, 0, -1):
        d = today - timedelta(days=back)
        for k in range(random.choice([1, 2, 2, 3])):
            cat = random.choice(["Study", "Study", "Work", "Personal"])
            est = random.choice([30, 45, 60, 90])
            actual = int(est * (random.uniform(1.25, 1.55) if cat == "Study" else random.uniform(0.85, 1.1)))
            t, _ = T.add_task(f"{cat} task {back}-{k}", est_minutes=est, category=cat, due_date=d)
            start_h = random.choice([15, 16, 16, 17, 10, 21])
            db.update("tasks", t["id"], {"status": "done", "actual_minutes": actual,
                                         "completed_at": f"{d.isoformat()}T{start_h + 1:02d}:30:00"})
            db.insert("time_logs", dict(task_id=t["id"], date=d.isoformat(), start=f"{start_h:02d}:{random.choice([0, 15, 30]):02d}",
                                        minutes=actual, source="block"))
            status = "done" if random.random() < (0.9 if start_h < 12 else 0.7) else "missed"
            db.insert("blocks", dict(date=d.isoformat(), start=f"{start_h:02d}:00", end=f"{start_h + 1:02d}:00",
                                     task_id=t["id"], status=status, locked=0, source="auto", created_at=db.stamp()))
        water, study, sleep = (trackers.find_tracker(x) for x in ("water", "study", "sleep"))
        when = datetime.combine(d, datetime.min.time()).replace(hour=20)
        trackers.log(water, random.choice([1250, 1750, 2250, 2500, 2750]), when=when)
        trackers.log(sleep, random.choice([5.5, 6.5, 7, 7.5, 8]), when=when.replace(hour=8))
        if random.random() < 0.8:
            trackers.log("meditate", when=when)
        if random.random() < 0.6:
            trackers.log("exercise", random.choice([20, 30, 45]), when=when)
        mood.log_mood(random.choice([2, 3, 3, 4, 4, 5]), random.choice([2, 3, 3, 4]), when=when)

    # today and the days ahead
    T.add_task("Physics problem set 4", due_date=today + timedelta(days=2), est_minutes=120, priority=2,
               category="Study", notes="Chapters 6 and 7")
    T.add_task("Email Prof. Rao about the extension", due_date=today, est_minutes=10, priority=2, category="Study")
    T.add_task("Lab report", due_date=today + timedelta(days=4), est_minutes=180, priority=1, category="Study")
    T.add_task("Read networking chapter 7", due_date=today + timedelta(days=5), est_minutes=60, category="Study")
    T.add_task("Buy a birthday gift for Meera", due_date=today + timedelta(days=3), est_minutes=45, category="Personal")
    T.add_task("Draft blog post", est_minutes=90, category="Creative", priority=4)
    T.add_task("Renew library card", est_minutes=15, category="Personal", priority=4)
    g, _ = T.add_goal("Pass the networking exam", why="Needed for the placement season", target_date=today + timedelta(days=50),
                      category="Study")
    T.add_task("Practice exam 1", due_date=today + timedelta(days=9), est_minutes=120, category="Study", goal_id=g["id"],
               priority=2)
    T.add_goal("Run a 10k", target_date=today + timedelta(days=90), category="Health")
    planner.plan_week()

    for text, cat, imp in [
        ("Studies best in the morning, and loses focus after 8 pm", "preference", 5),
        ("Is working toward passing the networking exam", "goal", 4),
        ("Is working toward running a 10k", "goal", 4),
        ("Meera is Asha's older sister and her go-to person when things get heavy", "person", 4),
        ("Skips breakfast when stressed, which makes afternoons harder", "health", 3),
        ("Likes lo-fi music while studying, but not for writing", "preference", 2),
        ("Gym on Monday, Wednesday and Friday evenings is non-negotiable", "routine", 4),
        ("Finished a 5k without stopping last month", "win", 3),
    ]:
        memory.remember(text, cat, imp, source="raveena")

    # a short conversation so the chat has some history
    briefing = ("Good afternoon, Asha. For the rest of today you have 3 focus sessions planned, 3h in all. "
                "First up is “Physics problem set 4” at 2:30 pm. How has your day been?")
    conversation.add("assistant", briefing, {"kind": "briefing", "date": today.isoformat()})
    conversation.add("user", "ugh I'm exhausted today, barely slept. can you go easy on me?")
    conversation.add("assistant",
                     "That sounds draining. Running on a few hours of sleep makes everything harder, and it's worth "
                     "listening to. I've noted it and made this afternoon lighter: just the physics set and the email to "
                     "Prof. Rao, and everything else can wait.",
                     {"turn": "demo1", "mode": "ai", "actions": [
                         {"action_id": None, "status": "done", "summary": "Noted your mood: low", "tool": "log_mood"},
                         {"action_id": None, "status": "done", "summary": "Logged 5 h sleep (goal 7.5 h)", "tool": "log_activity"},
                         {"action_id": None, "status": "done", "summary": "Planned today: 3 blocks, 3h", "tool": "plan_schedule"}]})
    conversation.add("user", "thank you. also remind me I need to book the dentist follow-up")
    conversation.add("assistant",
                     "Of course. I've added it for this week. And rest when you can; the lab report isn't due until Friday.",
                     {"turn": "demo2", "mode": "ai", "actions": [
                         {"action_id": None, "status": "done", "summary": "Added “Book the dentist follow-up”, due Fri 16 Oct", "tool": "add_task"}]})
    print("Demo database ready in", db.path())


if __name__ == "__main__":
    main()
