"""Things that work on macOS/Linux but break on Windows."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_no_platform_specific_strftime_directives():
    bad = []
    for path in list((ROOT / "raveena").rglob("*.py")) + [ROOT / "app.py"] + list((ROOT / "scripts").glob("*.py")):
        for m in re.finditer(r"strftime\(\s*f?[\"']([^\"']*)[\"']", path.read_text(encoding="utf-8")):
            if re.search(r"%-[a-zA-Z]|%#[a-zA-Z]", m.group(1)):
                bad.append((path.name, m.group(1)))
    assert not bad, f"%-d style directives fail on Windows: {bad}"


def test_files_are_written_as_utf8():
    for path in (ROOT / "raveena").rglob("*.py"):
        path.read_text(encoding="utf-8")
