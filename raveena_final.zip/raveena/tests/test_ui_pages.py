"""Run every page through Streamlit's headless AppTest with realistic data and real clicks."""
import os
import sys
from datetime import datetime
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

HARNESS = """
import sys
sys.path.insert(0, {root!r})
from raveena import db, settings
db.init(); settings.apply_runtime()
from raveena.ui import theme, common
theme.inject()
from raveena.ui import {module}
{module}.render()
"""


@pytest.fixture()
def demo(tmp_path):
    from raveena import clock, db
    db.close()
    db.init(tmp_path / "ui.db")
    clock.freeze(datetime(2026, 10, 12, 14, 20))
    import seed_demo
    seed_demo.main()
    yield
    clock.freeze(None)
    db.close()


def page(module: str) -> AppTest:
    at = AppTest.from_string(HARNESS.format(root=str(ROOT), module=module), default_timeout=40)
    return at.run()


@pytest.mark.parametrize("module", ["chat", "today", "tasks_page", "habits", "insights_page", "memory_page", "settings_page"])
def test_every_page_renders_cleanly(demo, module):
    at = page(module)
    assert not at.exception, [e.value for e in at.exception]


def test_today_views_and_replan(demo):
    from raveena import actions
    at = page("today")
    for view in ("Week", "Routines", "Day"):
        at.session_state["today_view"] = view
        at.run()
        assert not at.exception, (view, [e.value for e in at.exception])
    replan = next(b for b in at.button if b.label in ("Replan from now", "Plan my day"))
    replan.click().run()
    assert not at.exception
    assert any(a["tool"] == "plan_schedule" and a["source"] == "ui" for a in actions.recent(5))


def test_today_session_buttons(demo):
    from raveena import db
    at = page("today")
    done_btns = [b for b in at.button if b.key and b.key.startswith("bd-")]
    assert done_btns, "planned sessions should have a Done button"
    bid = int(done_btns[0].key.split("-")[1])
    done_btns[0].click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert db.get("blocks", bid)["status"] == "done"
    skip = next(b for b in at.button if b.key and b.key.startswith("sk-"))
    skip.click().run()
    assert not at.exception, [e.value for e in at.exception]


def test_tasks_quick_add_and_filters(demo):
    from raveena import db
    at = page("tasks_page")
    at.text_input(key="qa_text").set_value("Prepare slides friday 2h high priority")   # form values go up with the click
    next(b for b in at.button if b.label == "Add").click().run()
    assert not at.exception, [e.value for e in at.exception]
    t = db.row("SELECT * FROM tasks WHERE title LIKE 'Prepare slides%'")
    assert t and t["est_minutes"] == 120 and t["priority"] == 2 and t["due_date"]
    for view in ("Done", "Set aside", "Open"):
        at.session_state["task_view"] = view
        at.run()
        assert not at.exception, (view, [e.value for e in at.exception])


def test_habits_quick_log_and_mood(demo):
    from raveena import mood, trackers
    before = trackers.total(trackers.find_tracker("water"))
    at = page("habits")
    next(b for b in at.button if b.key and b.key.startswith("add-") and b.key.endswith("-1")).click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert trackers.total(trackers.find_tracker("water")) > before
    n = len(mood.history(1))
    next(b for b in at.button if b.key == "hm-2").click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(mood.history(1)) == n + 1


def test_memory_add_and_insights_review(demo):
    from raveena import memory
    at = page("memory_page")
    assert not at.exception
    at = page("insights_page")
    assert not at.exception
    next(b for b in at.button if b.key == "make-review").click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert at.session_state["review"]["text"]


def test_chat_in_lite_mode_does_real_work(demo, monkeypatch):
    from raveena import config, conversation, db, trackers
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    config.set_api_key(None)
    at = page("chat")
    at.chat_input[0].set_value("add task renew passport friday 45 min").run()
    assert not at.exception, [e.value for e in at.exception]
    assert db.row("SELECT * FROM tasks WHERE title LIKE 'Renew passport%'")
    last = conversation.recent(2)
    assert last[-1]["role"] == "assistant" and last[-1]["meta"]["actions"]
    at.chat_input[0].set_value("drank 2 glasses of water").run()
    assert not at.exception, [e.value for e in at.exception]
    assert trackers.total(trackers.find_tracker("water")) >= 500


def test_settings_actions_and_data_export(demo):
    at = page("settings_page")
    assert not at.exception
    import json
    from raveena import db
    data = db.export_all()
    json.dumps(data, default=str)
    assert data["tasks"] and data["settings"]["name"] == "Asha"


def test_chat_approval_card_approve_and_decline(demo):
    from raveena import actions, conversation, db, tools
    from raveena import tasks as T
    a = T.add_task("Disposable A")[0]
    b = T.add_task("Disposable B")[0]
    pa = tools.execute("delete_task", {"task": str(a["id"])}, source="chat")
    pb = tools.execute("delete_task", {"task": str(b["id"])}, source="chat")
    at = page("chat")
    assert not at.exception, [e.value for e in at.exception]
    next(x for x in at.button if x.key == f"ap-{pa.action_id}").click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert db.get("tasks", a["id"]) is None, "approving deletes it"
    assert actions.get(pa.action_id)["status"] == "done"
    next(x for x in at.button if x.key == f"no-{pb.action_id}").click().run()
    assert db.get("tasks", b["id"]) is not None, "declining leaves it alone"
    assert actions.get(pb.action_id)["status"] == "rejected"
    notes = [m["content"] for m in conversation.recent(5) if m["meta"].get("kind") == "note"]
    assert any("Done" in n for n in notes) and any("left it alone" in n for n in notes)


def test_chat_undo_button_reverses_the_turn(demo, monkeypatch):
    from raveena import config, db
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    config.set_api_key(None)
    at = page("chat")
    at.chat_input[0].set_value("add task water the plants tomorrow").run()
    assert db.row("SELECT * FROM tasks WHERE title LIKE 'Water the plants%'")
    undo = next(x for x in at.button if x.key and x.key.startswith("undo-"))
    undo.click().run()
    assert not at.exception, [e.value for e in at.exception]
    assert not db.row("SELECT * FROM tasks WHERE title LIKE 'Water the plants%'")


def test_whole_app_entry_point_and_passcode_gate(demo, monkeypatch):
    from raveena import config
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not at.exception, [e.value for e in at.exception]
    monkeypatch.setattr(config, "PASSCODE", "open-sesame")
    gated = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not gated.exception
    assert any("Unlock" == b.label for b in gated.button), "the gate asks for the passcode before showing anything"
    assert not any(b.key and b.key.startswith("bd-") for b in gated.button)
    gated.text_input[0].set_value("wrong")
    next(b for b in gated.button if b.label == "Unlock").click().run()
    assert any("not it" in e.value for e in gated.error)
    gated.text_input[0].set_value("open-sesame")
    next(b for b in gated.button if b.label == "Unlock").click().run()
    assert not any("Unlock" == b.label for b in gated.button)
