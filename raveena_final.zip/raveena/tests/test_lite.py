"""Lite mode, tested the way people actually talk."""
from datetime import date

import pytest

from raveena import actions, conversation, db, lite, mood, planner, settings, trackers
from raveena import tasks as T
from raveena.brain import Turn


def say(text):
    turn = Turn()
    reply = lite.respond(text, turn)
    conversation.add("user", text)
    conversation.add("assistant", reply, {"turn": turn.id, "actions": turn.actions})
    return reply, turn


def test_parse_task_text_variants(env):
    p = lite.parse_task_text
    s = p("write lab report by friday for 2 hours, high priority")
    assert (s["title"], s["due_date"], s["est_minutes"], s["priority"], s["category"]) == \
        ("Write lab report", "2026-10-16", 120, 2, "Study")
    s = p("call mom tomorrow 15 min")
    assert (s["title"], s["due_date"], s["est_minutes"], s["category"]) == ("Call mom", "2026-10-13", 15, "Personal")
    s = p("email the client about invoice urgent asap")
    assert s["priority"] == 1 and s["category"] == "Work"
    s = p("submit assignment friday 5pm")
    assert s["due_time"] == "17:00" and s["due_date"] == "2026-10-16" and s["title"] == "Submit assignment"
    assert p("buy groceries")["due_date"] is None


@pytest.mark.parametrize("phrase,title,due", [
    ("add task buy milk tomorrow", "Buy milk", "2026-10-13"),
    ("Add a task: renew passport by 25 oct", "Renew passport", "2026-10-25"),
    ("remind me to call the bank on friday", "Call the bank", "2026-10-16"),
    ("todo: finish slides next monday", "Finish slides", "2026-10-19"),
    ("I need to book the dentist in 3 days", "Book the dentist", "2026-10-15"),
    ("don't forget to pay rent", "Pay rent", None),
])
def test_adding_tasks_in_plain_english(env, phrase, title, due):
    reply, turn = say(phrase)
    rows = T.list_tasks()
    assert len(rows) == 1 and rows[0]["title"] == title and rows[0]["due_date"] == due, (reply, rows)
    assert turn.actions and "Added" in turn.actions[0]["summary"]


def test_quick_capture_without_a_verb(env):
    reply, _ = say("lab report friday 2h")
    t = T.list_tasks()[0]
    assert t["title"] == "Lab report" and t["est_minutes"] == 120 and "I took that as a task" in reply


def test_plan_complete_and_missed_flow(env, at):
    T.add_task("Physics problem set", est_minutes=60, priority=2, category="Study", due_date="2026-10-14")
    T.add_task("Read chapter 7", est_minutes=45, category="Study")
    reply, _ = say("plan my day")
    assert "today" in reply.lower() and db.rows("SELECT * FROM blocks WHERE date='2026-10-12'")
    at(11, 0)
    reply, turn = say("I finished the physics problem set, it took 90 minutes")
    t = db.row("SELECT * FROM tasks WHERE title LIKE 'Physics%'")
    assert t["status"] == "done" and t["actual_minutes"] == 90, reply
    reply, _ = say("I missed reading chapter 7")
    assert "moved it" in reply.lower()
    assert db.row("SELECT * FROM blocks WHERE status='missed'")


def test_done_with_no_task_name_uses_what_you_are_doing(env, at):
    T.add_task("Essay draft", est_minutes=60, category="Study", priority=2)
    planner.plan_today()
    start = db.rows("SELECT * FROM blocks")[0]["start"]
    h, m = map(int, start.split(":"))
    at(h, m + 10)
    reply, _ = say("done")
    assert db.row("SELECT * FROM tasks WHERE title='Essay draft'")["status"] == "done", reply


def test_ambiguous_task_asks_instead_of_guessing(env):
    T.add_task("Lab report physics")
    T.add_task("Lab report chemistry")
    reply, _ = say("done with lab report")
    assert "More than one" in reply and all(t["status"] == "todo" for t in T.list_tasks())


@pytest.mark.parametrize("phrase,tracker,expected", [
    ("drank 2 glasses of water", "water", 500),
    ("had a bottle of water", "water", 500),
    ("I drank 1.5 litres of water", "water", 1500),
    ("drank 750 ml water", "water", 750),
    ("slept 7.5 hours", "sleep", 7.5),
    ("I studied for 45 minutes", "study", 45),
    ("went for a run, 30 min", "exercise", 30),
])
def test_logging_activity_by_talking(env, phrase, tracker, expected):
    reply, turn = say(phrase)
    assert trackers.total(trackers.find_tracker(tracker)) == expected, reply


def test_meditation_and_unknown_duration(env):
    reply, _ = say("I meditated this morning")
    assert trackers.total(trackers.find_tracker("meditate")) == 1
    reply, _ = say("I studied")
    assert "How long" in reply


def test_feelings_are_logged_and_offer_help_then_follow_through(env):
    T.add_task("Report", est_minutes=60, priority=3)
    T.add_task("Other", est_minutes=60, priority=3)
    reply, turn = say("I'm so overwhelmed, there's too much to do")
    m = mood.latest()
    assert m and m["mood"] <= 2 and "overwhelm" in m["tags"]
    assert "lighten" in reply.lower() or "smaller" in reply.lower() or "cut it down" in reply.lower()
    reply, turn = say("yes please")
    assert "lighter" in reply.lower() and any("Planned" in a["summary"] for a in turn.actions)
    reply, _ = say("no")                                    # the offer was consumed; this is just chat
    assert reply


def test_declining_the_offer_is_respected(env):
    say("I'm exhausted today")
    reply, turn = say("no thanks")
    assert "here if you want" in reply.lower() and not turn.actions


@pytest.mark.parametrize("phrase,max_mood", [
    ("I'm really stressed about exams", 2), ("feeling sad today", 2), ("I'm so tired", 2),
    ("I feel anxious", 2), ("today was a rough day", 2), ("I'm not feeling great", 2),
])
def test_negative_feelings_detected(env, phrase, max_mood):
    say(phrase)
    assert mood.latest()["mood"] <= max_mood


@pytest.mark.parametrize("phrase,min_mood", [("I'm feeling great today!", 5), ("feeling good", 4), ("I'm not tired anymore", 3)])
def test_positive_and_negated_feelings(env, phrase, min_mood):
    say(phrase)
    assert mood.latest()["mood"] >= min_mood


def test_mood_logging_respects_the_switch(env):
    settings.set("auto_mood", False)
    reply, _ = say("I'm so stressed")
    assert mood.latest() is None and reply


def test_crisis_language_is_met_with_care_not_productivity(env):
    settings.set("crisis_contact", "my sister Meera")
    reply, turn = say("I don't want to be here anymore, I want to die")
    low = reply.lower()
    assert "emergency" in low or "crisis" in low
    assert "my sister Meera" in reply
    assert not turn.actions and not T.list_tasks() and not mood.latest(), "no tools, no bookkeeping, just presence"
    assert "can you tell me what's happening" in low
    assert "plan my day" not in low and "add" not in low.split("tell")[0]


def test_remember_forget_and_delete_need_care(env):
    from raveena import memory
    reply, _ = say("remember that I study best at night")
    m = memory.list_all()[0]
    assert "study best at night" in m["content"] and m["content"].startswith("Asha")
    reply, turn = say("forget I study best at night")
    assert turn.actions[0]["status"] == "pending" and memory.list_all()
    T.add_task("Old thing")
    reply, turn = say("delete old thing")
    assert turn.actions[0]["status"] == "pending" and T.list_tasks()


def test_routines_and_events_from_text(env):
    reply, turn = say("gym every mon wed fri 6-7pm")
    r = T.list_routines()[0]
    assert (r["title"], r["day_list"], r["start"], r["end"]) == ("Gym", [0, 2, 4], "18:00", "19:00"), reply
    reply, turn = say("dentist on 20 oct at 3pm")
    e = db.row("SELECT * FROM events")
    assert e and e["title"].lower().startswith("dentist") and e["date"] == "2026-10-20" and e["start"] == "15:00", reply


def test_deadline_phrases_stay_tasks_not_events(env):
    say("submit report by friday 5pm")
    assert not db.row("SELECT * FROM events") and T.list_tasks()[0]["due_time"] == "17:00"


def test_undo_reverses_the_last_reply(env):
    say("add task buy tea")
    assert T.list_tasks()
    reply, _ = say("undo")
    assert reply == "Undone." and not T.list_tasks()
    assert say("undo")[0].startswith("There's nothing")


def test_greeting_help_and_fallback(env):
    assert "How are you doing" in say("hello")[0]
    assert "Lite mode" in say("help")[0]
    assert "didn't quite catch" in say("blorp zibble quantum")[0]


def test_goal_and_insights_and_listing(env):
    reply, _ = say("goal: pass the networking exam by 1 dec")
    assert T.list_goals()[0]["target_date"] == "2026-12-01"
    T.add_task("Alpha")
    assert "Alpha" in say("what are my tasks")[0]
    assert say("how am I doing")[0]
