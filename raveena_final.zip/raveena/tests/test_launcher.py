"""The launcher is the first thing a new user touches, so it gets tests too."""
import socket
import subprocess
import sys

import start


def test_python_version_gate():
    assert start.python_ok((3, 12, 1)) and start.python_ok((3, 10)) and start.python_ok((3, 14, 0))
    assert not start.python_ok((3, 9, 18)) and not start.python_ok((3, 8))


def test_find_free_port_skips_busy_ports():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        s.listen(1)
        busy = s.getsockname()[1]
        free = start.find_free_port(busy, tries=5)
        assert free is not None and free != busy


def test_nothing_to_fix_in_a_working_install():
    assert start.diagnose() == []


def test_check_mode_reports_and_succeeds(capsys):
    assert start.main(["--check"]) == 0
    out = capsys.readouterr().out
    assert "Python:" in out and "Everything looks fine." in out


def test_old_python_is_explained_in_plain_words(monkeypatch):
    monkeypatch.setattr(start, "python_ok", lambda version=None: False)
    problems = start.diagnose()
    assert problems and "Python 3.10 or newer" in problems[0] and "python.org" in problems[0]


def test_a_crashed_server_is_detected_quickly():
    proc = subprocess.Popen([sys.executable, "-c", "pass"])
    proc.wait()
    assert start.wait_for_server(proc, 9, timeout=2) is False
