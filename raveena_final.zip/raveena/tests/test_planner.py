from datetime import date, datetime, timedelta

import pytest

from raveena import clock, db, mood, planner, settings
from raveena import tasks as T

MON = date(2026, 10, 12)
TUE = date(2026, 10, 13)


def mins(b):
    return clock.hm_to_min(b["end"]) - clock.hm_to_min(b["start"])


def blocks(d=MON, status=None):
    sql = "SELECT * FROM blocks WHERE date=?" + (" AND status=?" if status else "") + " ORDER BY start"
    return db.rows(sql, (d.isoformat(), status) if status else (d.isoformat(),))


def assert_no_overlap(bs):
    bs = sorted(bs, key=lambda b: b["start"])
    for a, b in zip(bs, bs[1:]):
        assert a["end"] <= b["start"], f"{a} overlaps {b}"


def test_urgent_before_unscheduled(env):
    a, _ = T.add_task("Pay fees", due_date=MON, priority=1, est_minutes=30, category="Personal")
    b, _ = T.add_task("Tidy desk", est_minutes=30, priority=4)
    c, _ = T.add_task("Write essay", due_date="2026-10-16", est_minutes=90, priority=2, category="Study")
    res = planner.plan_today()
    bs = blocks()
    assert bs, "something should be planned"
    assert_no_overlap(bs)
    first = min(bs, key=lambda x: x["start"])
    assert first["task_id"] in (a["id"], c["id"]), "urgent/high priority work comes before low priority"
    assert all(b["start"] >= "08:00" and b["end"] <= "22:00" for b in bs)
    assert not res.at_risk


def test_never_places_before_now(env, at):
    at(14, 7)
    T.add_task("Read chapter", est_minutes=60)
    planner.plan_today()
    bs = blocks()
    assert bs and all(b["start"] >= "14:10" for b in bs), bs   # rounded up to the next 5 minutes


def test_routines_and_events_are_respected(env):
    T.add_routine("Lectures", [0, 1, 2, 3, 4], "09:00", "13:00")
    T.add_event("Dentist", MON, "15:00", "16:00")
    for i in range(5):
        T.add_task(f"Task {i}", est_minutes=60, priority=2)
    planner.plan_today()
    for b in blocks():
        assert b["end"] <= "09:00" or b["start"] >= "13:00"
        assert b["end"] <= "15:00" or b["start"] >= "16:00"


def test_deep_work_goes_to_peak_window_light_to_the_rest(env):
    settings.set("peak_start", "09:00")
    settings.set("peak_end", "12:00")
    deep, _ = T.add_task("Write thesis chapter", est_minutes=60, category="Study")
    light, _ = T.add_task("Reply to emails", est_minutes=30, category="Work")
    T.add_routine("Breakfast", [0], "08:00", "09:00")
    planner.plan_today()
    by = {b["task_id"]: b for b in blocks()}
    assert "09:00" <= by[deep["id"]]["start"] < "12:00"
    assert by[light["id"]]["start"] >= "12:00" or by[light["id"]]["start"] > by[deep["id"]]["start"]


def test_daily_capacity_is_respected_but_urgent_can_stretch(env):
    settings.set("max_focus_minutes", 120)
    for i in range(6):
        T.add_task(f"Backlog {i}", est_minutes=60, priority=3)
    res = planner.plan([MON], spill=[], now=clock.now())
    assert sum(mins(b) for b in blocks()) <= 120
    assert res.backlog

    T.add_task("Due today", due_date=MON, est_minutes=120, priority=1)
    planner.plan([MON], spill=[], now=clock.now())
    total = sum(mins(b) for b in blocks())
    assert total <= 180                      # hard cap = 1.5x
    assert any(b["task_id"] for b in blocks())


def test_deadline_that_cannot_fit_is_flagged_at_risk(env):
    big, _ = T.add_task("Huge report", due_date=MON, est_minutes=600, priority=1)
    res = planner.plan_today()
    assert any(r["task"]["id"] == big["id"] for r in res.at_risk)
    assert "AT RISK" in res.text()


def test_overflow_spills_into_next_days_before_due_date(env):
    settings.set("max_focus_minutes", 120)
    t, _ = T.add_task("Study for exam", est_minutes=300, due_date="2026-10-16", category="Study", priority=2)
    res = planner.plan_today()
    days = {b["date"] for b in res.placed}
    assert len(days) >= 2, "a 5h task with a 2h/day cap needs several days"
    assert max(days) <= "2026-10-16"
    assert sum(mins(b) for b in res.placed) >= 295
    assert not res.at_risk


def test_task_with_due_time_ends_before_it(env):
    T.add_task("Submit form", due_date=MON, due_time="10:00", est_minutes=45, priority=1, category="Personal")
    planner.plan_today()
    bs = blocks()
    assert bs and all(b["end"] <= "10:00" for b in bs)


def test_missed_blocks_are_rescheduled_later(env, at):
    t, _ = T.add_task("Physics problem set", est_minutes=90, priority=2, category="Study", due_date="2026-10-14")
    planner.plan_today()
    first = blocks()[0]
    assert first["start"] < "12:00"
    at(15, 0)                                   # the morning passes with no check-in
    res = planner.plan_today()
    assert res.missed >= 1
    assert db.get("blocks", first["id"])["status"] == "missed"
    fresh = [b for b in blocks(status="planned") if b["task_id"] == t["id"]]
    assert fresh and all(b["start"] >= "15:00" for b in fresh)
    assert db.get("tasks", t["id"])["postponed"] >= 1


def test_locked_blocks_survive_replanning(env):
    t, _ = T.add_task("Piano practice", est_minutes=45, category="Creative")
    b = planner.schedule_task(t["id"], MON, "18:30")
    T.add_task("Other", est_minutes=60)
    planner.plan_today()
    planner.plan_week()
    assert db.get("blocks", b["id"])["start"] == "18:30"
    assert db.get("blocks", b["id"])["locked"] == 1


def test_scheduling_over_a_commitment_is_refused(env):
    T.add_routine("Gym", [0], "18:00", "19:00")
    t, _ = T.add_task("Piano", est_minutes=45)
    with pytest.raises(T.UserError):
        planner.schedule_task(t["id"], MON, "18:30")


def test_complete_block_logs_time_and_finishes_task(env):
    t, _ = T.add_task("Quick email", est_minutes=30, category="Work")
    planner.plan_today()
    b = blocks()[0]
    out = planner.complete_block(b["id"])
    assert out["finished"] is True
    assert db.get("tasks", t["id"])["status"] == "done"
    assert db.get("tasks", t["id"])["actual_minutes"] == 30
    assert db.get("blocks", b["id"])["status"] == "done"


def test_overrun_replans_the_rest_of_today(env, at):
    a, _ = T.add_task("Lab report", est_minutes=60, priority=2, category="Study")
    b, _ = T.add_task("Read paper", est_minutes=60, priority=3, category="Study")
    planner.plan_today()
    first = blocks()[0]
    at(11, 0)                                       # it took 3h instead of 1h
    out = planner.complete_block(first["id"], actual_minutes=180)
    assert out["overrun"] == 120
    assert out["replanned"] is not None
    future = [x for x in blocks(status="planned") if x["end"] > "11:00"]
    assert future and all(x["start"] >= "11:00" for x in future)
    # blocks from earlier that nobody confirmed stay open as check-ins (not silently "missed")
    assert all(x["status"] != "missed" for x in blocks())
    assert_no_overlap(future)


def test_partial_session_keeps_task_open_and_finds_more_time(env):
    t, _ = T.add_task("Big project", est_minutes=240, priority=2, category="Work")
    planner.plan_today()
    first = blocks()[0]
    out = planner.complete_block(first["id"])
    assert out["finished"] is False
    assert out["left"] > 0
    assert db.get("tasks", t["id"])["status"] == "doing"


def test_estimates_scale_with_how_long_you_really_take(env):
    for i in range(4):
        t, _ = T.add_task(f"Essay part {i}", est_minutes=60, category="Study")
        T.complete_task(t["id"], actual_minutes=90)
    f = T.estimation_factors()
    assert f["Study"] > 1.2
    fresh, _ = T.add_task("New essay", est_minutes=60, category="Study")
    assert T.effective_estimate(fresh, f) >= 75
    planner.plan_today()
    planned = sum(mins(b) for b in db.rows("SELECT * FROM blocks WHERE task_id=?", (fresh["id"],)))
    assert planned >= 75


def test_low_mood_makes_today_lighter(env):
    for i in range(6):
        T.add_task(f"Chore {i}", est_minutes=60, priority=3)
    planner.plan([MON], spill=[], now=clock.now())
    normal = sum(mins(b) for b in blocks())
    db.delete_where("blocks", "1=1")
    mood.log_mood(2, 2, "tired and flat")
    res = planner.plan([MON], spill=[], now=clock.now())
    light = sum(mins(b) for b in blocks())
    assert light < normal
    assert res.load < 1 and "low" in (res.load_reason or "")


def test_done_tasks_are_not_replanned_and_dropped_ones_lose_blocks(env):
    a, _ = T.add_task("Alpha", est_minutes=30)
    b, _ = T.add_task("Beta", est_minutes=30)
    planner.plan_today()
    T.complete_task(a["id"])
    T.update_task(b["id"], status="dropped")
    assert not db.rows("SELECT * FROM blocks WHERE status='planned' AND task_id IN (?,?)", (a["id"], b["id"]))
    planner.plan_week()
    assert not db.rows("SELECT * FROM blocks WHERE task_id IN (?,?)", (a["id"], b["id"]))


def test_week_plan_has_no_overlaps_and_stays_in_window(env):
    T.add_routine("Class", [0, 1, 2, 3, 4], "10:00", "12:00")
    for i in range(10):
        T.add_task(f"Work {i}", est_minutes=75, priority=1 + i % 4, due_date=MON + timedelta(days=i % 6))
    planner.plan_week()
    for d in range(7):
        bs = blocks(MON + timedelta(days=d))
        assert_no_overlap(bs)
        for b in bs:
            assert b["start"] >= "08:00" and b["end"] <= "22:00"
            if (MON + timedelta(days=d)).weekday() < 5:
                assert b["end"] <= "10:00" or b["start"] >= "12:00"


def test_check_in_list_and_ensure_plan(env, at):
    T.add_task("Morning thing", est_minutes=30)
    assert planner.ensure_today_plan() is not None
    assert planner.ensure_today_plan() is None            # already planned
    at(21, 0)
    assert planner.pending_checkins(), "ended-but-unconfirmed blocks show up as check-ins"


def test_day_summary_ignores_missed_sessions(env, at):
    T.add_task("Alpha", est_minutes=60, priority=2)
    planner.plan_today()
    first = blocks()[0]
    at(15, 0)
    planner.miss_block(first["id"])
    sm = planner.day_summary(MON)
    assert sm["missed"] == 1 and sm["blocks"] == sm["remaining"] + (1 if sm["done"] else 0)
    assert all(b["status"] != "missed" for b in blocks() if b["id"] != first["id"])
