"""The stylesheet is injected through st.html, whose sanitizer silently drops a <style> element
if its text contains anything that looks like a tag. Guard against that."""
from raveena.ui import theme


def test_stylesheet_has_no_angle_brackets():
    css = theme._CSS.template
    assert "<" not in css, "a '<' in the CSS makes Streamlit's sanitizer drop the whole stylesheet"


def test_both_palettes_fill_every_token():
    for palette in (theme.LIGHT, theme.DARK):
        out = theme._CSS.substitute(palette)
        assert "$" not in out
    assert set(theme.LIGHT) == set(theme.DARK)
