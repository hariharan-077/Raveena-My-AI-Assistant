import sys
from datetime import datetime
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Monday 12 Oct 2026, 08:00 - a predictable "now" for every test.
MONDAY_8AM = datetime(2026, 10, 12, 8, 0)


@pytest.fixture()
def env(tmp_path):
    from raveena import clock, db, settings
    db.close()
    db.init(tmp_path / "test.db")
    settings.set("onboarded", True)
    settings.set("name", "Asha")
    clock.freeze(MONDAY_8AM)
    yield
    clock.freeze(None)
    db.close()


@pytest.fixture()
def at():
    """Move the frozen clock: at(hour, minute=0, day=12)."""
    from raveena import clock

    def _at(hour, minute=0, day=12):
        clock.freeze(datetime(2026, 10, day, hour, minute))
    return _at
