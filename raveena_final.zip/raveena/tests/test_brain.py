"""The Gemini integration, tested with a fake client built from the real SDK types."""
import copy

import pytest
from google.genai import errors, types

from raveena import actions, brain, config, conversation, db, persona, settings, tools
from raveena import tasks as T


def part(t=None, *, call=None, thought=False, sig=None):
    if call:
        return types.Part(function_call=types.FunctionCall(name=call[0], args=call[1], id=f"call_{call[0]}"),
                          thought_signature=sig)
    return types.Part(text=t, thought=thought or None, thought_signature=sig)


def reply(*parts, finish="STOP", block=None):
    cand = types.Candidate(content=types.Content(role="model", parts=list(parts)), finish_reason=finish)
    return types.GenerateContentResponse(candidates=[cand])


def use(name, **inp):
    return part(call=(name, inp))


class FakeModels:
    def __init__(self, script):
        self.script, self.calls = list(script), []

    def generate_content_stream(self, *, model, contents, config):
        self.calls.append(dict(model=model, contents=copy.deepcopy(contents), config=config))
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        # stream the text in small pieces, the way the API does
        chunks = []
        for p in item.candidates[0].content.parts:
            if p.text and not p.thought:
                for i in range(0, len(p.text), 7):
                    chunks.append(reply(types.Part(text=p.text[i:i + 7])))
            else:
                chunks.append(reply(p))
        chunks[-1].candidates[0].finish_reason = item.candidates[0].finish_reason
        return iter(chunks)


class FakeClient:
    def __init__(self, script):
        self.models = FakeModels(script)

    @property
    def calls(self):
        return self.models.calls


def api_error(cls, status, message="boom"):
    return cls(status, {"error": {"code": status, "message": message, "status": "X"}})


def run(b, user_text="hi"):
    turn = brain.Turn()
    out = "".join(b.reply([{"role": "user", "content": user_text}], turn))
    return out, turn


def test_tool_loop_runs_tools_and_streams_text_around_them(env):
    client = FakeClient([
        reply(part("Let me add that."), use("add_task", title="Buy milk", due_date="2026-10-13")),
        reply(part("Done. It's on your list for tomorrow.")),
    ])
    out, turn = run(brain.GeminiBrain(client=client), "remind me to buy milk tomorrow")
    assert out == "Let me add that.\n\nDone. It's on your list for tomorrow."
    assert T.list_tasks()[0]["title"] == "Buy milk"
    assert [a["summary"] for a in turn.actions] == ["Added “Buy milk”, due Tomorrow"]
    second = client.calls[1]["contents"]
    assert second[-1].role == "user" and second[-1].parts[0].function_response.name == "add_task"
    assert second[-2].role == "model" and second[-2].parts[-1].function_call.name == "add_task"


def test_thought_signatures_are_passed_back_unchanged(env):
    client = FakeClient([reply(part(call=("list_tasks", {}), sig=b"sig-abc")), reply(part("Nothing open."))])
    run(brain.GeminiBrain(client=client))
    model_turn = client.calls[1]["contents"][-2]
    assert model_turn.parts[0].thought_signature == b"sig-abc"


def test_thought_text_is_not_shown(env):
    client = FakeClient([reply(part("secret reasoning", thought=True), part("Hello!"))])
    out, _ = run(brain.GeminiBrain(client=client))
    assert out == "Hello!"


def test_request_shape(env):
    client = FakeClient([reply(part("hi"))])
    run(brain.GeminiBrain(model="gemini-2.5-flash", effort="low", client=client))
    call = client.calls[0]
    cfg = call["config"]
    assert call["model"] == "gemini-2.5-flash"
    assert cfg.thinking_config.thinking_budget == 0
    assert cfg.automatic_function_calling.disable is True
    assert "Raveena" in cfg.system_instruction
    names = {d.name for d in cfg.tools[0].function_declarations}
    assert "add_task" in names and "rollover" not in names and "focus_start" not in names
    first = call["contents"][0]
    assert first.role == "user" and first.parts[0].text == "hi"


def test_gemini_3_uses_thinking_levels_and_unknown_models_none(env):
    c3 = FakeClient([reply(part("hi"))])
    run(brain.GeminiBrain(model="gemini-3-flash-preview", effort="high", client=c3))
    assert str(c3.calls[0]["config"].thinking_config.thinking_level).lower().endswith("high")
    cx = FakeClient([reply(part("hi"))])
    run(brain.GeminiBrain(model="gemma-3-27b-it", client=cx))
    assert cx.calls[0]["config"].thinking_config is None


def test_thinking_rejection_retries_once_without_it(env):
    client = FakeClient([api_error(errors.ClientError, 400, "Thinking is not supported for this model"),
                         reply(part("hello there"))])
    out, _ = run(brain.GeminiBrain(model="gemini-2.5-flash", client=client))
    assert out == "hello there"
    assert client.calls[0]["config"].thinking_config is not None
    assert client.calls[1]["config"].thinking_config is None


@pytest.mark.parametrize("cls,status,needle", [
    (errors.ClientError, 401, "API key"),
    (errors.ClientError, 403, "API key"),
    (errors.ClientError, 429, "rate limited"),
    (errors.ClientError, 404, "model"),
    (errors.ServerError, 500, "busy"),
])
def test_api_errors_become_friendly_messages(env, cls, status, needle):
    b = brain.GeminiBrain(client=FakeClient([api_error(cls, status)] * 3))
    with pytest.raises(brain.BrainError) as e:
        run(b)
    assert needle.lower() in e.value.user_message.lower()


def test_missing_model_retries_with_latest_alias(env):
    client = FakeClient([api_error(errors.ClientError, 404, "models/gemini-old is not found"), reply(part("hi there"))])
    b = brain.GeminiBrain(model="gemini-old", client=client)
    out, _ = run(b)
    assert out == "hi there" and b.model == "gemini-flash-latest"
    assert client.calls[1]["model"] == "gemini-flash-latest"
    assert settings.get("model") == "gemini-flash-latest"


def test_smart_brain_falls_back_to_lite_when_gemini_fails_first(env):
    client = FakeClient([api_error(errors.ClientError, 401)])
    smart = brain.SmartBrain(brain.GeminiBrain(client=client))
    out, turn = run(smart, "add task buy tea tomorrow")
    assert "API key" in out and "Lite mode" in out
    assert turn.mode == "lite" and turn.note
    assert any(t["title"] == "Buy tea" for t in T.list_tasks())        # it still did the work


def test_smart_brain_does_not_replay_after_tools_ran(env):
    client = FakeClient([
        reply(use("add_task", title="Once only")),
        api_error(errors.ClientError, 429),
    ])
    smart = brain.SmartBrain(brain.GeminiBrain(client=client))
    out, turn = run(smart, "add task once only")
    assert len(T.list_tasks()) == 1, "falling back must never repeat actions that already happened"
    assert "rate limited" in out.lower()


def test_runaway_tool_loops_are_capped(env):
    client = FakeClient([reply(use("list_tasks")) for _ in range(brain.MAX_ROUNDS + 2)])
    out, _ = run(brain.GeminiBrain(client=client))
    assert "tangled" in out
    assert len(client.calls) == brain.MAX_ROUNDS


def test_high_risk_tools_surface_as_pending_not_done(env):
    t, _ = T.add_task("Old task")
    client = FakeClient([reply(use("delete_task", task=str(t["id"]))), reply(part("Waiting on your OK."))])
    out, turn = run(brain.GeminiBrain(client=client))
    assert db.get("tasks", t["id"]) is not None
    assert turn.actions[0]["status"] == "pending"
    resp = client.calls[1]["contents"][-1].parts[0].function_response.response
    assert "NOT DONE YET" in resp["result"]
    assert actions.pending()


def test_tool_errors_are_reported_to_the_model_not_raised(env):
    client = FakeClient([reply(use("complete_task", task="ghost")), reply(part("I couldn't find it."))])
    out, turn = run(brain.GeminiBrain(client=client))
    resp = client.calls[1]["contents"][-1].parts[0].function_response.response
    assert "error" in resp and "couldn't find" in resp["error"].lower()
    assert out.endswith("I couldn't find it.")


def test_blocked_reply_is_handled(env):
    client = FakeClient([reply(part("I can't"), finish="SAFETY")])
    out, _ = run(brain.GeminiBrain(client=client))
    assert "not able to help" in out


def test_one_shot_complete_for_reviews(env):
    client = FakeClient([reply(part("A calm week. One thing to try: mornings."))])
    out = brain.GeminiBrain(client=client).complete("review please")
    assert out.startswith("A calm week")
    assert not client.calls[0]["config"].tools


# ------------------------------------------------------------------ what the model is told about you
def test_system_prompt_and_snapshot_carry_your_world(env):
    from raveena import memory, planner, trackers
    T.add_task("Write lab report", due_date="2026-10-14", est_minutes=90, priority=2, category="Study")
    memory.remember("Studies best in the morning", "preference", 5)
    T.add_goal("Pass the networking exam")
    planner.plan_today()
    trackers.log("water", 500)
    sp = persona.system_prompt()
    assert "Asha" in sp and "Raveena" in sp and "report_session" in sp
    snap = persona.snapshot("how is my study going")
    for needle in ("2026-10-12", "Write lab report", "Studies best in the morning", "Pass the networking exam",
                   "Water 500 ml of 2.5 L", "Best focus hours"):
        assert needle in snap, needle


def test_tone_changes_the_system_prompt(env):
    settings.set("tone", "coach")
    assert "coach" in persona.system_prompt().lower()


def test_status_and_selection(env, monkeypatch):
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
    config.set_api_key(None)
    assert brain.status()["mode"] == "lite" and brain.get_brain().primary is None
    config.set_api_key("sk-test")
    assert brain.status()["mode"] == "ai" and brain.get_brain().primary is not None
    settings.set("use_ai", False)
    assert brain.status()["mode"] == "lite"
    config.set_api_key(None)


def test_history_for_model_alternates_and_starts_with_user(env):
    conversation.add("assistant", "Good morning")                 # a briefing, no user message before it
    conversation.add("user", "hi")
    conversation.add("user", "also this")
    conversation.add("assistant", "ok", {"kind": "note"})        # UI-only notices are skipped
    conversation.add("assistant", "sure")
    h = conversation.history_for_model()
    assert [m["role"] for m in h] == ["user", "assistant"]
    assert h[0]["content"] == "hi\n\nalso this"
