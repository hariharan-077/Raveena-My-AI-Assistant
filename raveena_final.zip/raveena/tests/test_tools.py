import json
from datetime import date

import pytest

from raveena import actions, clock, db, memory, planner, settings, tools, trackers
from raveena import tasks as T

MON = date(2026, 10, 12)


def run(name, **args):
    return tools.execute(name, args, source="chat", turn="t1")


def test_schemas_are_wellformed():
    schemas = tools.schemas()
    assert len(schemas) >= 20
    names = set()
    for s in schemas:
        assert s["name"] not in names
        names.add(s["name"])
        assert s["description"] and s["input_schema"]["type"] == "object"
        props = s["input_schema"]["properties"]
        assert set(s["input_schema"]["required"]) <= set(props), s["name"]
        for p in props.values():
            assert p["type"] in {"string", "integer", "number", "boolean", "array", "object"}
            if p["type"] == "array":
                assert "items" in p, s["name"]
    json.dumps(schemas)


def test_add_task_logs_action_and_can_be_undone(env):
    out = run("add_task", title="Write lab report", due_date="2026-10-15", est_minutes=90, category="study")
    assert out.status == "done" and out.undoable and out.action_id
    assert "Added" in out.summary
    assert T.list_tasks(status="todo")[0]["category"] == "Study"
    assert actions.recent(1)[0]["tool"] == "add_task"
    actions.undo(out.action_id)
    assert T.list_tasks() == []
    assert actions.get(out.action_id)["status"] == "undone"


def test_duplicate_tasks_are_not_created_twice(env):
    run("add_task", title="Buy gift", due_date="2026-10-20")
    out = run("add_task", title="buy gift", due_date="2026-10-20")
    assert "already" in out.text.lower()
    assert len(T.list_tasks()) == 1


def test_high_risk_actions_wait_for_approval(env):
    t, _ = T.add_task("Old task", est_minutes=30)
    planner.plan_today()
    out = run("delete_task", task=str(t["id"]))
    assert out.status == "pending" and out.action_id
    assert "NOT DONE" in out.text
    assert db.get("tasks", t["id"]) is not None, "nothing may be deleted before approval"
    assert actions.pending()[0]["id"] == out.action_id

    again = run("delete_task", task=str(t["id"]))
    assert again.action_id == out.action_id, "repeating the request must not stack up approval cards"
    assert len(actions.pending()) == 1

    done = tools.approve(out.action_id)
    assert done.status == "done"
    assert db.get("tasks", t["id"]) is None
    assert not db.rows("SELECT * FROM blocks WHERE task_id=?", (t["id"],))

    # even an approved deletion can be undone, with its scheduled time restored
    actions.undo(out.action_id)
    assert db.get("tasks", t["id"]) is not None
    assert db.rows("SELECT * FROM blocks WHERE task_id=?", (t["id"],))


def test_declining_leaves_everything_untouched(env):
    t, _ = T.add_task("Keep me", est_minutes=30)
    out = run("delete_task", task=str(t["id"]))
    tools.decline(out.action_id)
    assert actions.get(out.action_id)["status"] == "rejected"
    assert db.get("tasks", t["id"]) is not None
    with pytest.raises(T.UserError):
        tools.approve(out.action_id)


def test_forget_needs_approval_and_can_be_undone(env):
    m, _ = memory.remember("Prefers studying in the morning", "preference")
    out = run("forget", memory=str(m["id"]))
    assert out.status == "pending" and memory.get(m["id"])
    tools.approve(out.action_id)
    assert memory.get(m["id"]) is None
    actions.undo(out.action_id)
    assert memory.get(m["id"])["content"].startswith("Prefers")


def test_plan_schedule_is_undoable(env):
    T.add_task("Alpha", est_minutes=60, priority=2)
    first = run("plan_schedule", scope="today")
    before = db.rows("SELECT id,start FROM blocks ORDER BY id")
    assert before
    T.add_task("Beta", est_minutes=60, priority=1, due_date="2026-10-12")
    second = run("plan_schedule", scope="today")
    assert second.undoable
    actions.undo(second.action_id)
    assert db.rows("SELECT id,start FROM blocks ORDER BY id") == before


def test_undo_turn_reverses_everything_from_one_message(env):
    run("add_task", title="One")
    run("add_task", title="Two")
    run("log_activity", tracker="water", value=500)
    assert actions.undo_turn("t1") == 3
    assert T.list_tasks() == [] and trackers.total(trackers.find_tracker("water")) == 0


def test_log_activity_and_summaries(env):
    out = run("log_activity", tracker="drank", value=500)
    assert out.status == "done" and "500 ml" in out.summary
    out = run("log_activity", tracker="water", value=1000)
    assert trackers.total(trackers.find_tracker("Water")) == 1500
    assert "1.5 L" in out.text
    out = run("log_activity", tracker="meditate")
    again = run("log_activity", tracker="meditate")
    assert "already" in again.text.lower()
    bad = run("log_activity", tracker="underwater basket weaving")
    assert bad.status == "failed" and "Your trackers" in bad.text


def test_memory_and_mood_respect_automation_switches(env):
    settings.set("auto_memory", False)
    settings.set("auto_mood", False)
    assert run("remember", content="Likes tea").status == "failed"
    assert run("remember", content="Likes tea", explicit=True).status == "done"
    assert run("log_mood", mood=2).status == "failed"
    assert run("log_mood", mood=2, explicit=True).status == "done"


def test_report_session_missed_replans_and_done_adapts(env, at):
    t, _ = T.add_task("Physics set", est_minutes=60, priority=2, category="Study", due_date="2026-10-14")
    run("plan_schedule", scope="today")
    first = db.rows("SELECT * FROM blocks ORDER BY start")[0]
    at(12, 0)
    out = run("report_session", task="physics", outcome="missed")
    assert out.status == "done"
    assert db.get("blocks", first["id"])["status"] == "missed"
    assert any(b["start"] >= "12:00" for b in db.rows("SELECT * FROM blocks WHERE status='planned'"))
    out = run("report_session", task="physics", outcome="done", actual_minutes=100)
    assert out.status == "done"
    assert db.get("tasks", t["id"])["actual_minutes"] >= 100


def test_errors_never_raise_and_readonly_tools_leave_no_trace(env):
    assert run("nope").status == "failed"
    assert run("complete_task", task="ghost").status == "failed"
    assert run("add_task").status == "failed"                        # missing required title
    assert run("add_task", title="x", due_date="not a date").status == "failed"
    before = len(actions.recent(100))
    assert run("list_tasks").status == "done"
    assert run("get_schedule").status == "done"
    assert run("search_memory", query="anything").status == "done"
    assert len(actions.recent(100)) == before


def test_routine_and_event_and_calendar_delete(env):
    r = run("add_routine", title="Gym", days=[0, 2, 4], start_time="18:00", end_time="19:00")
    assert r.status == "done"
    e = run("add_event", title="Dentist", date="2026-10-14", start_time="15:00", end_time="16:00")
    assert e.status == "done"
    bad = run("add_event", title="Backwards", date="2026-10-14", start_time="16:00", end_time="15:00")
    assert bad.status == "failed"
    rid = T.list_routines()[0]["id"]
    pend = run("delete_calendar_item", kind="routine", id=rid)
    assert pend.status == "pending" and T.list_routines()


def test_create_goal_with_tasks_and_progress(env):
    out = run("create_goal", title="Pass networking exam", target_date="2026-12-01", category="study",
              tasks=[{"title": "Read chapters 1-3", "est_minutes": 120, "due_date": "2026-10-20"},
                     {"title": "Practice exam 1", "est_minutes": 90}])
    assert out.status == "done"
    g = T.list_goals()[0]
    assert T.goal_progress(g)[2] == 2
    T.complete_task(T.list_tasks(goal_id=g["id"])[0]["id"])
    assert T.goal_progress(g)[0] == 50


def test_update_preferences_validates(env):
    assert run("update_preferences", setting="peak_start", value="2pm").status == "done"
    assert settings.get("peak_start") == "14:00"
    assert run("update_preferences", setting="max_focus_minutes", value="9999").status == "failed"
    assert run("update_preferences", setting="tone", value="sarcastic").status == "failed"
    a = actions.recent(5)
    undo_target = [x for x in a if x["tool"] == "update_preferences" and x["status"] == "done"][0]
    actions.undo(undo_target["id"])
    assert settings.get("peak_start") == "09:00"


def test_deleting_a_goal_needs_approval_keeps_tasks_and_is_undoable(env):
    g, _ = T.add_goal("Run a 10k")
    t, _ = T.add_task("Run 3 km", goal_id=g["id"])
    out = run("delete_goal", goal="10k")
    assert out.status == "pending" and T.list_goals()
    tools.approve(out.action_id)
    assert not T.list_goals() and db.get("tasks", t["id"])["goal_id"] is None
    actions.undo(out.action_id)
    assert T.list_goals() and db.get("tasks", t["id"])["goal_id"] == g["id"]
