@echo off
rem Starts Raveena on Windows. Just double-click this file.
rem The first run sets things up (needs internet, about a minute).
setlocal
cd /d "%~dp0"
title Raveena
echo.
echo   Raveena is starting. The first time takes a minute or two.
echo.

if not exist "app.py" (
  echo   I can't find app.py. If you opened this from inside the zip, close this window,
  echo   right-click raveena.zip, choose Extract All, and run run.bat from the new folder.
  echo.
  pause
  exit /b 1
)

rem Find a Python that is 3.10 or newer.
set "PY="
call :try "py -3.13"
call :try "py -3.12"
call :try "py -3.11"
call :try "py -3.10"
call :try "py -3"
call :try "python"
call :try "python3"
if not defined PY goto :nopython
goto :havepython

:try
if defined PY goto :eof
%~1 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if not errorlevel 1 set "PY=%~1"
goto :eof

:nopython
echo   Raveena needs Python 3.10 or newer, and I couldn't find it on this computer.
echo.
echo     1. Go to https://www.python.org/downloads/ and download the newest Python.
echo     2. Run the installer. On its FIRST screen, tick the box "Add python.exe to PATH".
echo     3. When it finishes, double-click run.bat again.
echo.
pause
exit /b 1

:havepython
if not exist ".venv\Scripts\python.exe" (
  echo   Setting up a private Python environment for Raveena...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo.
    echo   I couldn't create the environment. Please send me the message above.
    pause
    exit /b 1
  )
)

echo   Checking Raveena's packages. The first time this needs internet.
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
  echo.
  echo   Installing the packages failed. Check your internet connection and try again.
  echo   If it keeps failing, send me the red text above.
  pause
  exit /b 1
)

".venv\Scripts\python.exe" start.py
echo.
echo   Raveena has stopped. You can close this window.
pause
